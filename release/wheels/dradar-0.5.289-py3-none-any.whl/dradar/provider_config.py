"""Local provider setup, including explicit imports of existing credentials."""

from __future__ import annotations

import getpass
import hashlib
import json
import os
import platform
import shutil
import ssl
import stat
import subprocess
import sys
import tarfile
import tempfile
import urllib.request
from datetime import datetime
from pathlib import Path
from urllib.parse import urlsplit

import certifi
import httpx

from .codebuddy_provider import (
    CODEBUDDY_CLI_VERSION,
    CODEBUDDY_CONTAINER_IMAGE,
    CODEBUDDY_MODEL,
    codebuddy_executable,
    codebuddy_host_cli_status,
    codebuddy_runtime_image_error,
    codebuddy_subscription_session,
    ensure_codebuddy_runtime_image,
    import_host_login,
    managed_codebuddy_home,
)
from .credential_files import (
    atomic_private_credential,
    claude_config_payload,
    credential_json,
    private_directory,
    read_private_credential,
    is_claude_metered_auth,
)
from .codebuddy_provider import (
    credential_status as codebuddy_credential_status,
)
from .providers import (
    ANTIGRAVITY_CLI_VERSION,
    ANTIGRAVITY_LINUX_ARTIFACTS,
    ANTIGRAVITY_MODEL_RUNTIME_MODELS,
    ANTIGRAVITY_RUNTIME_MODELS,
    CLAUDE_API_KEY_ENVS,
    CLAUDE_CLI_VERSION,
    CLAUDE_MODELS,
    CLAUDE_SUPPORTED_EFFORTS,
    DEEPSEEK_API_FLASH_MODEL,
    DEEPSEEK_API_KEY_ENV,
    DEEPSEEK_FLASH_MODEL,
    GROK_API_KEY_ENV,
    GROK_CLI_VERSION,
    GROK_MODEL,
    KIMI_API_KEY_ENVS,
    KIMI_BINARY_BASE_URL,
    KIMI_BINARY_SHA256,
    KIMI_CLI_VERSION,
    ZCODE_MODELS,
    ZCODE_OFFICIAL_DOWNLOAD_PAGE,
    antigravity_auth_path,
    antigravity_auth_error,
    antigravity_home,
    antigravity_ready_path,
    claude_config_path,
    claude_cli_path,
    claude_subscription_error,
    claude_subscription_path,
    deepseek_api_key,
    deepseek_credential_source,
    deepseek_secret_error,
    deepseek_secret_path,
    grok_auth_error,
    grok_auth_path,
    grok_cli_path,
    grok_home,
    grok_live_error,
    kimi_auth_error,
    kimi_auth_path,
    kimi_cli_path,
    kimi_home,
    kimi_live_error,
    managed_grok_cli_path,
    managed_kimi_cli_path,
    mark_antigravity_ready,
    parse_grok_cli_version,
    parse_kimi_cli_version,
    parse_zcode_cli_version,
    prepare_antigravity_auth,
    privatize_antigravity_home,
    provider_subprocess_env,
    restore_antigravity_settings,
    store_deepseek_api_key,
    store_claude_oauth_token,
    store_grok_auth,
    store_zcode_api_key,
    store_zcode_cli,
    zcode_api_key,
    zcode_cli_error,
    zcode_cli_path,
    zcode_cli_version_is_compatible,
    zcode_credential_source,
    zcode_secret_error,
    zcode_secret_path,
)

_DEEPSEEK_MODELS_URL = "https://api.deepseek.com/models"
_ZCODE_MODELS_URL = "https://open.bigmodel.cn/api/coding/paas/v4/models"
_GROK_INSTALLER_URL = "https://x.ai/cli/install.sh"
_ANTIGRAVITY_SETUP_IMAGE = "debian:bookworm-slim"
_ANTIGRAVITY_CA_BUNDLE_TARGET = "/tmp/dradar-ca-certificates.crt"


def _private_directory(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name != "nt":
        os.chmod(path, 0o700)


def _provider_proxy_for_url(url: str, env: dict[str, str]) -> str | None:
    """Resolve shell/macOS proxy settings while respecting NO_PROXY."""

    parsed = urlsplit(url)
    host = parsed.hostname or ""
    no_proxy = env.get("NO_PROXY") or env.get("no_proxy")
    if no_proxy and urllib.request.proxy_bypass_environment(
        host, {"no": no_proxy},
    ):
        return None
    prefix = parsed.scheme.upper()
    value = (
        env.get(f"{prefix}_PROXY")
        or env.get(f"{prefix.lower()}_proxy")
        or env.get("ALL_PROXY")
        or env.get("all_proxy")
    )
    if isinstance(value, str) and value.lower().startswith("socks://"):
        value = "socks5://" + value[len("socks://"):]
    return value or None


def _provider_httpx_get(url: str, **kwargs):
    """GET through the same explicit/OS proxy contract as provider CLIs."""

    env = provider_subprocess_env()
    proxy = _provider_proxy_for_url(url, env)
    timeout = kwargs.pop("timeout", 10.0)
    follow_redirects = kwargs.pop("follow_redirects", False)
    with httpx.Client(
        proxy=proxy,
        trust_env=False,
        timeout=timeout,
        follow_redirects=follow_redirects,
    ) as client:
        return client.get(url, **kwargs)


def _grok_cli_version(executable: str | Path) -> str | None:
    try:
        result = subprocess.run(
            [str(executable), "--version"],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    return parse_grok_cli_version(result.stdout + "\n" + result.stderr)


def _kimi_cli_version(executable: str | Path) -> str | None:
    try:
        result = subprocess.run(
            [str(executable), "--version"],
            capture_output=True,
            text=True,
            timeout=15,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    return parse_kimi_cli_version(result.stdout + "\n" + result.stderr)


def _install_managed_grok_cli() -> str | None:
    """Install DRadar's required Grok release into its private runtime slot."""

    bash = shutil.which("bash")
    if not bash:
        print(
            "Could not auto-install Grok: bash is unavailable. Install Git Bash "
            "on Windows, or bash on Linux/macOS, then retry."
        )
        return None
    target = managed_grok_cli_path()
    runtime = target.parent.parent
    _private_directory(runtime)
    _private_directory(target.parent)
    try:
        response = _provider_httpx_get(
            _GROK_INSTALLER_URL, timeout=30.0, follow_redirects=True,
        )
    except httpx.HTTPError as exc:
        print(f"Could not download the official Grok installer: {type(exc).__name__}.")
        return None
    if response.status_code != 200 or not response.content.startswith(b"#!"):
        print(
            "Could not download the official Grok installer "
            f"(HTTP {response.status_code})."
        )
        return None
    try:
        with tempfile.TemporaryDirectory(prefix=".install-", dir=runtime) as name:
            script = Path(name) / "install.sh"
            script.write_bytes(response.content)
            if os.name != "nt":
                script.chmod(0o700)
            installer_home = runtime / "installer-home"
            _private_directory(installer_home)
            env = provider_subprocess_env()
            env["HOME"] = str(installer_home)
            env["GROK_BIN_DIR"] = str(target.parent)
            env["GROK_CHANNEL"] = "stable"
            for key in ("GROK_DEPLOYMENT_KEY", GROK_API_KEY_ENV):
                env.pop(key, None)
            print(f"Installing official Grok CLI {GROK_CLI_VERSION} for DRadar...")
            result = subprocess.run(
                [bash, str(script), GROK_CLI_VERSION], env=env, check=False,
            )
    except OSError as exc:
        print(f"Could not install Grok CLI: {exc}")
        return None
    if result.returncode != 0 or _grok_cli_version(target) != GROK_CLI_VERSION:
        print("The official Grok installer completed without a usable DRadar runtime.")
        return None
    return str(target)


def _install_managed_kimi_cli() -> str | None:
    """Install the reviewed official Kimi Code native bundle privately."""

    system = platform.system().lower()
    system = {
        "windows": "win32", "darwin": "darwin", "linux": "linux",
    }.get(system, system)
    machine = platform.machine().lower()
    if machine in {"aarch64", "arm64"}:
        arch = "arm64"
    elif machine in {"x86_64", "amd64"}:
        arch = "x64"
    else:
        arch = ""
    artifact = f"{system}-{arch}" if arch else ""
    expected = KIMI_BINARY_SHA256.get(artifact)
    if expected is None:
        print(f"Could not auto-install Kimi Code on {system}/{machine}.")
        return None
    target = managed_kimi_cli_path()
    runtime = target.parent.parent
    _private_directory(runtime)
    _private_directory(target.parent)
    print(f"Installing official Kimi Code CLI {KIMI_CLI_VERSION} for DRadar...")
    try:
        suffix = ".exe" if system == "win32" else ""
        response = _provider_httpx_get(
            f"{KIMI_BINARY_BASE_URL}/kimi-code-{artifact}{suffix}",
            timeout=60.0,
            follow_redirects=True,
        )
    except httpx.HTTPError as exc:
        print(f"Could not download official Kimi Code CLI: {type(exc).__name__}.")
        return None
    if response.status_code != 200:
        print(f"Could not download official Kimi Code CLI (HTTP {response.status_code}).")
        return None
    if hashlib.sha256(response.content).hexdigest() != expected:
        print("Official Kimi Code binary checksum mismatch; refusing to install it.")
        return None
    temp_name: str | None = None
    try:
        fd, temp_name = tempfile.mkstemp(prefix=".kimi-", dir=target.parent)
        with os.fdopen(fd, "wb") as handle:
            handle.write(response.content)
            handle.flush()
            os.fsync(handle.fileno())
        temp = Path(temp_name)
        if os.name != "nt":
            temp.chmod(0o700)
        os.replace(temp, target)
    except OSError as exc:
        print(f"Could not install Kimi Code CLI: {exc}")
        if temp_name is not None:
            try:
                Path(temp_name).unlink()
            except OSError:
                pass
        return None
    if _kimi_cli_version(target) != KIMI_CLI_VERSION:
        print("The official Kimi installer completed without a usable DRadar runtime.")
        return None
    return str(target)


def _ensure_grok_cli() -> str | None:
    executable = grok_cli_path()
    found = _grok_cli_version(executable) if executable else None
    if found == GROK_CLI_VERSION:
        return executable
    if executable:
        print(
            f"Found Grok CLI {found or 'unknown'}; preparing current DRadar "
            f"runtime {GROK_CLI_VERSION} without changing the global install."
        )
    return _install_managed_grok_cli()


def _ensure_kimi_cli() -> str | None:
    executable = kimi_cli_path()
    found = _kimi_cli_version(executable) if executable else None
    if found == KIMI_CLI_VERSION:
        return executable
    if executable:
        print(
            f"Found Kimi Code CLI {found or 'unknown'}; preparing current DRadar "
            f"runtime {KIMI_CLI_VERSION} without changing the global install."
        )
    return _install_managed_kimi_cli()


def _antigravity_docker_arch(docker: str) -> str | None:
    try:
        result = subprocess.run(
            [docker, "info", "--format", "{{.Architecture}}"],
            capture_output=True, text=True, timeout=20, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    value = result.stdout.strip().lower()
    if value in {"amd64", "x86_64"}:
        return "x86_64"
    if value in {"arm64", "aarch64"}:
        return "aarch64"
    return None


def _managed_antigravity_linux_cli(arch: str) -> Path:
    return (
        antigravity_home() / "runtime" / ANTIGRAVITY_CLI_VERSION
        / arch / "antigravity"
    )


def _ensure_antigravity_linux_cli(docker: str) -> Path | None:
    """Download and verify Google's exact Linux artifact for Docker's arch."""

    arch = _antigravity_docker_arch(docker)
    artifact = ANTIGRAVITY_LINUX_ARTIFACTS.get(arch or "")
    if artifact is None:
        print("Antigravity setup needs a Docker Linux amd64 or arm64 engine.")
        return None
    target = _managed_antigravity_linux_cli(arch or "")
    if target.is_file():
        try:
            payload = target.read_bytes()
        except OSError:
            payload = b""
        # The manifest hash covers the tarball, not the extracted executable;
        # a small adjacent proof binds this cached runtime to that reviewed
        # archive without re-downloading it for every status check.
        proof = target.with_suffix(".sha512")
        try:
            proof_lines = proof.read_text(encoding="ascii").splitlines()
            expected_proof = [
                "archive=" + artifact["sha512"],
                "binary=" + hashlib.sha512(payload).hexdigest(),
            ]
            if proof_lines == expected_proof:
                if os.name != "nt":
                    target.chmod(0o700)
                if payload:
                    return target
        except OSError:
            pass
    _private_directory(target.parent)
    print(
        f"Downloading official Antigravity CLI {ANTIGRAVITY_CLI_VERSION} "
        f"for Docker {arch}..."
    )
    try:
        response = _provider_httpx_get(
            artifact["url"], timeout=120.0, follow_redirects=True,
        )
    except httpx.HTTPError as exc:
        print(f"Could not download official Antigravity CLI: {type(exc).__name__}.")
        return None
    if response.status_code != 200:
        print(
            "Could not download official Antigravity CLI "
            f"(HTTP {response.status_code})."
        )
        return None
    if hashlib.sha512(response.content).hexdigest() != artifact["sha512"]:
        print("Official Antigravity archive checksum mismatch; refusing to use it.")
        return None
    try:
        with tempfile.TemporaryDirectory(prefix=".agy-", dir=target.parent) as name:
            archive = Path(name) / "antigravity.tar.gz"
            archive.write_bytes(response.content)
            with tarfile.open(archive, mode="r:gz") as bundle:
                members = bundle.getmembers()
                if (
                    len(members) != 1
                    or members[0].name != "antigravity"
                    or not members[0].isfile()
                ):
                    print("Official Antigravity archive has an unexpected layout.")
                    return None
                source = bundle.extractfile(members[0])
                if source is None:
                    return None
                fd, temp_name = tempfile.mkstemp(prefix=".antigravity-", dir=target.parent)
                temp = Path(temp_name)
                try:
                    with os.fdopen(fd, "wb") as handle:
                        shutil.copyfileobj(source, handle)
                        handle.flush()
                        os.fsync(handle.fileno())
                    if os.name != "nt":
                        temp.chmod(0o700)
                    os.replace(temp, target)
                except BaseException:
                    try:
                        temp.unlink()
                    except OSError:
                        pass
                    raise
            proof = target.with_suffix(".sha512")
            installed = target.read_bytes()
            proof.write_text(
                "archive=" + artifact["sha512"] + "\n"
                "binary=" + hashlib.sha512(installed).hexdigest() + "\n",
                encoding="ascii",
            )
            if os.name != "nt":
                proof.chmod(0o600)
    except (OSError, tarfile.TarError) as exc:
        print(f"Could not install Antigravity CLI: {exc}")
        return None
    return target


def _antigravity_container_command(
    docker: str, executable: Path, arguments: list[str], *, interactive: bool,
) -> tuple[list[str], dict[str, str]]:
    auth = antigravity_auth_path()
    auth.mkdir(parents=True, exist_ok=True, mode=0o700)
    ca_bundle = _antigravity_ca_bundle()
    command = [docker, "run", "--rm"]
    if interactive:
        command.append("-i")
        if sys.stdin.isatty() and sys.stdout.isatty():
            command.append("-t")
    if hasattr(os, "getuid") and hasattr(os, "getgid"):
        command += ["--user", f"{os.getuid()}:{os.getgid()}"]
    command += [
        "--workdir", "/tmp",
        "--env", "HOME=/tmp/dradar-antigravity-user",
        "--env", "AGY_CLI_HIDE_LOGO=1",
        "--env", f"SSL_CERT_FILE={_ANTIGRAVITY_CA_BUNDLE_TARGET}",
        "--mount",
        f"type=bind,source={executable.resolve()},target=/opt/antigravity,readonly",
        "--mount",
        f"type=bind,source={auth.resolve()},target=/tmp/dradar-antigravity-user/.gemini",
        "--mount",
        (
            f"type=bind,source={ca_bundle},"
            f"target={_ANTIGRAVITY_CA_BUNDLE_TARGET},readonly"
        ),
    ]
    env = provider_subprocess_env()
    # A loopback proxy that is valid for the host points back at the setup
    # container itself. Honor DRadar's explicit, user-supplied Docker-side
    # endpoint when present; otherwise retain the existing host/OS fallback.
    if proxy := env.get("DRADAR_CONTAINER_HTTP_PROXY", "").strip():
        for name in (
            "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
            "http_proxy", "https_proxy", "all_proxy",
        ):
            env[name] = proxy
    if no_proxy := env.get("DRADAR_CONTAINER_NO_PROXY", "").strip():
        env["NO_PROXY"] = no_proxy
        env["no_proxy"] = no_proxy
    for name in (
        "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
        "http_proxy", "https_proxy", "all_proxy", "no_proxy",
    ):
        if env.get(name):
            command += ["--env", name]
    for name in (
        "GEMINI_API_KEY", "GOOGLE_API_KEY", "GOOGLE_APPLICATION_CREDENTIALS",
        "AGY_ADC_AUTH",
    ):
        env.pop(name, None)
    command += [_ANTIGRAVITY_SETUP_IMAGE, "/opt/antigravity", *arguments]
    return command, env


def _antigravity_ca_bundle() -> Path:
    """Return a canonical, non-empty CA bundle for the slim setup container."""

    try:
        bundle = Path(certifi.where()).resolve(strict=True)
        size = bundle.stat().st_size
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        raise ValueError("the trusted CA bundle is unavailable") from exc
    if not bundle.is_file() or size <= 0:
        raise ValueError("the trusted CA bundle is not a non-empty regular file")
    try:
        ssl.create_default_context(cafile=str(bundle))
    except (OSError, ssl.SSLError) as exc:
        raise ValueError("the trusted CA bundle is not valid PEM") from exc
    return bundle


def _antigravity_models_live(docker: str, executable: Path) -> str | None:
    try:
        command, env = _antigravity_container_command(
            docker, executable, ["models"], interactive=False,
        )
    except (OSError, ValueError) as exc:
        return f"could not prepare the official models check: {type(exc).__name__}"
    proc = None
    run_issue = None
    try:
        proc = subprocess.run(
            command, env=env, capture_output=True, text=True,
            timeout=120, check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        run_issue = f"could not run the official models check: {type(exc).__name__}"
    try:
        # Even read-only AGY commands currently normalize away explicit false
        # settings.  Restore the reviewed fail-closed policy after every live
        # check so status/setup never weakens or invalidates the paid runtime.
        restore_antigravity_settings()
    except (OSError, ValueError) as exc:
        return f"the official models check left unsafe local state: {type(exc).__name__}"
    if run_issue is not None:
        return run_issue
    assert proc is not None
    if proc.returncode != 0:
        output = (proc.stdout + "\n" + proc.stderr).lower()
        if "authentication" in output or "oauth" in output:
            return "the isolated Google OAuth session was rejected"
        return "the official models check failed; check Docker/network/proxy"
    available = {
        line.split()[0]
        for line in proc.stdout.splitlines()
        if line.strip()
    }
    verified = sorted({
        slug
        for group in ANTIGRAVITY_MODEL_RUNTIME_MODELS.values()
        if set(group.values()).issubset(available)
        for slug in group.values()
    })
    if not verified:
        return "the account has no complete supported Antigravity low/medium/high model group"
    try:
        mark_antigravity_ready(verified_models=verified)
    except (OSError, ValueError) as exc:
        return f"could not persist verified Antigravity models: {type(exc).__name__}"
    return None


def _setup_antigravity_subscription() -> int:
    docker = shutil.which("docker")
    if not docker:
        print("Antigravity setup needs Docker, which DRadar also uses for tasks.")
        return 1
    executable = _ensure_antigravity_linux_cli(docker)
    if executable is None:
        return 1
    prior_issue = prepare_antigravity_auth()
    if prior_issue in {
        None, "Antigravity readiness proof does not match this DRadar release",
    }:
        # Re-verify an older proof using the existing private OAuth state;
        # upgrading the CLI alone must not force a new login.
        issue = _antigravity_models_live(docker, executable)
        if issue is None:
            print(
                f"Antigravity subscription provider is already ready (CLI "
                f"{ANTIGRAVITY_CLI_VERSION}, available model groups verified)."
            )
            return 0
    if not sys.stdin.isatty():
        print(
            "Antigravity OAuth setup needs an interactive terminal. Run:\n"
            "  dradar provider setup antigravity\n"
            "This uses Google's official OAuth flow in a DRadar-owned container; "
            "no API key is accepted."
        )
        return 2
    try:
        restore_antigravity_settings()
        command, env = _antigravity_container_command(
            docker,
            executable,
            [
                "--new-project", "--print", "/usage",
                "--output-format", "json", "--print-timeout", "10m",
            ],
            interactive=True,
        )
        print(
            "Starting official Google OAuth for the dedicated DRadar "
            "Antigravity slot. Complete the browser/code prompt shown below."
        )
        proc = subprocess.run(command, env=env, check=False)
    except (OSError, ValueError) as exc:
        print(f"could not start Antigravity login: {exc}")
        return 1
    if proc.returncode != 0:
        try:
            # Even an interrupted official login creates logs and local state.
            # Restore the reviewed settings and owner-only permissions before
            # returning so a failed setup never leaves a broad credential tree.
            restore_antigravity_settings()
        except (OSError, ValueError) as exc:
            print(f"Antigravity OAuth cleanup found unsafe local state: {exc}")
            return 1
        print("Antigravity OAuth login did not complete successfully.")
        return proc.returncode or 1
    try:
        # Login may add presentation preferences.  Replace only settings.json;
        # credentials live in separate files below the same private tree.
        restore_antigravity_settings()
    except (OSError, ValueError) as exc:
        print(f"Antigravity login returned unsafe local state: {exc}")
        return 1
    live_issue = _antigravity_models_live(docker, executable)
    if live_issue is not None:
        print(f"Antigravity login completed, but live model verification failed: {live_issue}.")
        return 1
    try:
        # The live model check already persisted the exact verified groups.
        privatize_antigravity_home()
    except (OSError, ValueError) as exc:
        print(f"could not seal Antigravity readiness state: {exc}")
        return 1
    issue = prepare_antigravity_auth()
    if issue is not None:
        print(f"Antigravity provider is not ready: {issue}")
        return 1
    print(
        f"Antigravity subscription OAuth is ready at {antigravity_auth_path()} "
        f"(tokens hidden, CLI {ANTIGRAVITY_CLI_VERSION}, available Gemini Flash "
        "effort levels verified)."
    )
    return 0


def _status_antigravity_subscription(*, live: bool) -> int:
    issue = prepare_antigravity_auth()
    if issue is not None:
        print(f"Antigravity subscription provider not ready: {issue}")
        return 1
    if live:
        docker = shutil.which("docker")
        if not docker:
            print("Antigravity live status needs Docker.")
            return 1
        executable = _ensure_antigravity_linux_cli(docker)
        if executable is None:
            return 1
        issue = _antigravity_models_live(docker, executable)
        if issue is not None:
            print(f"Antigravity subscription provider not ready: {issue}.")
            return 1
    print(
        f"Antigravity subscription provider ready via {antigravity_auth_path()} "
        f"(OAuth tokens hidden, CLI {ANTIGRAVITY_CLI_VERSION}, "
        "available Gemini Flash low/medium/high groups, API keys disabled)."
    )
    return 0


def _claude_cli_version(executable: str | Path) -> str | None:
    try:
        result = subprocess.run(
            [str(executable), "--version"], capture_output=True, text=True,
            timeout=15, check=False,
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    first = (result.stdout + "\n" + result.stderr).strip().split(" ", 1)[0]
    return first if first.count(".") == 2 else None


def _setup_claude_subscription() -> int:
    """Import an official Claude.ai setup token into DRadar's private store."""

    configured = claude_config_path()
    if configured.exists() or configured.is_symlink():
        # Re-running setup must not silently select a different legacy login.
        return _status_claude_subscription(live=False)
    executable = claude_cli_path()
    version = _claude_cli_version(executable) if executable else None
    if not executable or version != CLAUDE_CLI_VERSION:
        print(
            f"Claude Code {CLAUDE_CLI_VERSION} is required; found "
            f"{version or 'none'}. Run `claude install latest`, then retry."
        )
        return 1
    if not sys.stdin.isatty():
        print(
            "Claude setup needs an interactive Terminal. First sign in with "
            "`claude auth login --claudeai`, then run:\n"
            "  dradar provider setup claude\n"
            "Only the subscription OAuth token is accepted; API keys are rejected."
        )
        return 2
    print(
        "Claude Code will now create an official Claude.ai subscription setup "
        "token. Complete its browser prompt, then copy the token once."
    )
    setup_env = provider_subprocess_env()
    for key in (*CLAUDE_API_KEY_ENVS, "CLAUDE_CODE_OAUTH_TOKEN"):
        setup_env.pop(key, None)
    result = subprocess.run(
        [executable, "setup-token"],
        env=setup_env,
        check=False,
    )
    if result.returncode != 0:
        print("Claude Code did not complete subscription setup-token OAuth.")
        return 1
    token = getpass.getpass("Paste the setup token (input hidden): ")
    try:
        path = store_claude_oauth_token(token)
    except (OSError, ValueError) as exc:
        print(f"could not save Claude subscription OAuth: {exc}")
        return 1
    print(
        f"Claude subscription OAuth saved locally at {path} (value hidden).\n"
        "It is never sent to the DRadar server and no Anthropic API key is used."
    )
    return 0


def _status_claude_subscription(*, live: bool) -> int:
    path = claude_subscription_path()
    issue = claude_subscription_error()
    if issue is not None:
        print(
            f"Claude Code provider not ready: {issue}. Run "
            "`dradar provider setup claude`."
        )
        return 1
    executable = claude_cli_path()
    version = _claude_cli_version(executable) if executable else None
    if version != CLAUDE_CLI_VERSION:
        print(
            f"Claude Code provider not ready: CLI {CLAUDE_CLI_VERSION} "
            f"required, found {version or 'none'}."
        )
        return 1
    print(
        f"Claude Code provider ready via {path} (OAuth value hidden, CLI "
        f"{CLAUDE_CLI_VERSION}, models {', '.join(sorted(CLAUDE_MODELS))}, "
        "API keys disabled)."
    )
    return _live_claude_status(executable, path) if live else 0


def _live_claude_status(executable: str, path: Path) -> int:
    base_env = provider_subprocess_env()
    for name in list(base_env):
        if is_claude_metered_auth(name) or name in {"CLAUDE_CODE_OAUTH_TOKEN", "CLAUDE_CONFIG_DIR"}:
            base_env.pop(name, None)
    if path.name == ".credentials.json":
        claude_config_payload(read_private_credential(path))
        base_env["CLAUDE_CONFIG_DIR"] = str(path.parent)
    else:
        base_env["CLAUDE_CODE_OAUTH_TOKEN"] = path.read_text(encoding="utf-8").strip()
    for model in sorted(CLAUDE_MODELS):
        command = [
            executable, "-p", "--safe-mode", "--disable-slash-commands",
            "--no-session-persistence", "--tools", "", "--max-turns", "1",
            "--model", model, "--effort", "low", "--output-format", "json",
            "Reply with exactly DRADAR_CLAUDE_AUTH_OK.",
        ]
        try:
            probe = subprocess.run(
                command, env=base_env, capture_output=True, text=True,
                timeout=180, check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            print(f"Claude {model} live probe failed: {type(exc).__name__}.")
            return 1
        if probe.returncode != 0 or "DRADAR_CLAUDE_AUTH_OK" not in probe.stdout:
            print(
                f"Claude subscription login could not access {model}; raw "
                "provider output and credentials were not displayed."
            )
            return 1
    print(
        "Claude subscription access verified live for Sonnet 5, Opus 5, "
        "and Opus 5.5; this check consumed three minimal provider requests."
    )
    return 0


def _owned_source_directory(path: Path) -> None:
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode):
        raise ValueError("OAuth source directory must not be a symlink")
    if os.name != "nt" and info.st_uid != os.getuid():
        raise ValueError("OAuth source directory must be owned by you")


def _import_zcode_key(source: Path) -> int:
    if source.resolve() == zcode_secret_path().resolve():
        raise ValueError("import source must be separate from managed credentials")
    key = read_private_credential(source).decode("utf-8").strip()
    if not key or any(character.isspace() for character in key):
        raise ValueError("Coding Plan key must be one non-empty line")
    cli = zcode_cli_path()
    if zcode_cli_error(cli) is not None:
        print("A compatible official ZCode runtime is required before import; previous credentials were preserved.")
        return 1
    # Verify the explicit Coding Plan endpoint before changing any credential.
    # Never fall back to a general, metered BigModel API endpoint.
    if _live_zcode_status(key) != 0:
        print("Coding Plan validation failed; previous credentials were preserved.")
        return 1
    target = zcode_secret_path()
    if target.exists() or target.is_symlink():
        read_private_credential(target)
    store_zcode_cli(cli)
    atomic_private_credential(target, (key + "\n").encode())
    print("Existing Coding Plan key imported privately; source unchanged, no model request made.")
    return 0


def _import_claude_config(source: Path) -> int:
    _owned_source_directory(source)
    if source.resolve() == claude_config_path().parent.resolve():
        raise ValueError("import source must be separate from managed credentials")
    payload = claude_config_payload(read_private_credential(source / ".credentials.json"))
    target = claude_config_path()
    atomic_private_credential(target, json.dumps(payload, separators=(",", ":")).encode())
    print("Native Claude subscription OAuth configuration imported privately; source unchanged.")
    print("No setup-token conversion, login, or model request was performed; verify runtime readiness with provider status.")
    return 0


def _import_antigravity_config(source: Path) -> int:
    _owned_source_directory(source)
    _owned_source_directory(source / "antigravity-cli")
    content = read_private_credential(source / "antigravity-cli" / "antigravity-oauth-token")
    payload = credential_json(content)
    token = payload.get("token")
    if (
        payload.get("auth_method") != "consumer" or not isinstance(token, dict)
        or not all(isinstance(token.get(key), str) and token[key].strip()
                   for key in ("access_token", "refresh_token", "expiry"))
        or str(token.get("token_type", "")).lower() != "bearer"
    ):
        raise ValueError("existing official consumer OAuth credentials are required")
    try:
        expiry = datetime.fromisoformat(token["expiry"].replace("Z", "+00:00"))
        if expiry.tzinfo is None:
            raise ValueError
    except ValueError:
        raise ValueError("official OAuth expiry must include a timezone") from None
    # Retain only project selection, never source MCP commands, logs or history.
    project_config = None
    config_file = source / "config" / "config.json"
    if config_file.exists() or config_file.is_symlink():
        _owned_source_directory(config_file.parent)
        original = credential_json(read_private_credential(config_file))
        settings = original.get("userSettings", {})
        if not isinstance(settings, dict):
            raise ValueError("invalid official project configuration")
        project_config = {"userSettings": {
            key: settings[key] for key in ("projectId", "project_id", "defaultProjectId")
            if isinstance(settings.get(key), str)
        }}
    target = antigravity_auth_path()
    if source.resolve() == target.resolve():
        raise ValueError("source must be separate from the managed import target")
    if target.is_symlink() or (target.exists() and not target.is_dir()):
        raise ValueError("managed OAuth target must be a real directory")
    ready = antigravity_ready_path()
    old_ready = read_private_credential(ready) if ready.exists() or ready.is_symlink() else None
    docker = shutil.which("docker")
    if not docker or _ensure_antigravity_linux_cli(docker) is None:
        print("Antigravity runtime preparation failed; previous credentials were preserved.")
        return 1
    private_directory(target.parent)
    with tempfile.TemporaryDirectory(prefix=".oauth-import-", dir=target.parent) as temporary:
        staging_home = Path(temporary)
        staged = antigravity_auth_path(staging_home)
        atomic_private_credential(staged / "antigravity-cli" / "antigravity-oauth-token", content)
        if project_config is not None:
            atomic_private_credential(staged / "config" / "config.json", json.dumps(project_config).encode())
        restore_antigravity_settings(staging_home)
        mark_antigravity_ready(staging_home)
        if antigravity_auth_error(staging_home) is not None:
            raise ValueError("imported local OAuth state did not validate")
        backup = staging_home / "previous-auth"
        if target.exists():
            target.rename(backup)
        try:
            staged.rename(target)
            atomic_private_credential(ready, read_private_credential(antigravity_ready_path(staging_home)))
        except BaseException:
            if target.exists():
                shutil.rmtree(target)
            if backup.exists():
                backup.rename(target)
            if old_ready is not None:
                atomic_private_credential(ready, old_ready)
            else:
                ready.unlink(missing_ok=True)
            raise
    print("Existing Antigravity consumer OAuth imported privately; source unchanged.")
    print("No new OAuth login or live model check was performed; local readiness is not proof of model quota.")
    return 0


def cmd_provider_setup(args) -> int:
    """Read a DeepSeek key without echoing it or placing it in argv/history."""

    imports = (
        ("coding_plan_key_file", {"zcode"}, _import_zcode_key),
        ("claude_config_dir", {"claude", "claude-code"}, _import_claude_config),
        ("antigravity_oauth_dir", {"antigravity", "agy"}, _import_antigravity_config),
    )
    for option, providers, importer in imports:
        source = getattr(args, option, None)
        if source is None:
            continue
        if args.provider not in providers:
            print("The selected credential import option does not match this provider.")
            return 2
        try:
            return importer(Path(source).expanduser())
        except (OSError, ValueError) as exc:
            print(f"Existing credential import failed ({type(exc).__name__}); previous credentials were preserved.")
            return 1
    if args.provider in {"claude", "claude-code"}:
        return _setup_claude_subscription()
    if args.provider == "grok":
        return _setup_grok_subscription()
    if args.provider == "kimi":
        return _setup_kimi_subscription()
    if args.provider == "zcode":
        return _setup_zcode()
    if args.provider in {"agy", "antigravity"}:
        return _setup_antigravity_subscription()
    if args.provider in {"codebuddy", "hy4"}:
        return _setup_codebuddy_subscription()
    if args.provider != "deepseek":
        raise ValueError(f"unsupported provider: {args.provider}")
    if not sys.stdin.isatty():
        print(
            "DeepSeek setup needs an interactive terminal so the key can be "
            "entered with echo disabled. Open your own Terminal and run:\n"
            "  dradar provider setup deepseek\n"
            "Never paste the API key into Codex/chat or pass it as a command argument."
        )
        return 2
    key = getpass.getpass("DeepSeek API key (input hidden): ")
    try:
        path = store_deepseek_api_key(key)
    except (OSError, ValueError) as exc:
        print(f"could not save DeepSeek API key: {exc}")
        return 1
    print(
        f"DeepSeek API key saved locally at {path} (value hidden).\n"
        "It is not stored in config.json and is never sent to the DRadar server."
    )
    if _live_deepseek_status(key) != 0:
        print(
            "The credential remains saved, but it is not ready for a task yet. "
            "Fix the reported account/network issue, then run: "
            "dradar provider status deepseek --live"
        )
        return 1
    return 0


def cmd_provider_status(args) -> int:
    """Report credential readiness without printing secret material."""

    live = bool(getattr(args, "live", False))
    if args.provider in {"claude", "claude-code"}:
        return _status_claude_subscription(live=live)
    if args.provider == "grok":
        return _status_grok_subscription()
    if args.provider == "kimi":
        return _status_kimi_subscription(live=live)
    if args.provider == "zcode":
        return _status_zcode(live=live)
    if args.provider in {"agy", "antigravity"}:
        return _status_antigravity_subscription(live=live)
    if args.provider in {"codebuddy", "hy4"}:
        return _status_codebuddy_subscription(live=live)
    if args.provider != "deepseek":
        raise ValueError(f"unsupported provider: {args.provider}")
    path = deepseek_secret_path()
    error = deepseek_secret_error(path)
    if error is not None:
        print(f"DeepSeek provider not ready: {error}")
        return 1
    source = deepseek_credential_source()
    key = deepseek_api_key()
    if source == "environment" and key:
        print(f"DeepSeek provider configured via {DEEPSEEK_API_KEY_ENV} (value hidden).")
        return _live_deepseek_status(key) if live else 0
    if source == "file" and key:
        print(f"DeepSeek provider configured via {path} (value hidden).")
        return _live_deepseek_status(key) if live else 0
    print(
        "DeepSeek provider not configured. In your own interactive Terminal run:\n"
        "  dradar provider setup deepseek"
    )
    return 1


def _setup_codebuddy_subscription() -> int:
    executable = codebuddy_executable()
    cli_issue, host_version = codebuddy_host_cli_status(executable)
    if cli_issue is not None:
        detail = {
            "missing": "CodeBuddy is not installed",
            "unrecognized": "the installed CodeBuddy version could not be recognized",
            "incompatible": (
                f"CodeBuddy {host_version} is incompatible; install "
                f"{CODEBUDDY_CLI_VERSION} or newer within the 2.x series"
            ),
        }.get(cli_issue, "CodeBuddy is not ready")
        print(
            f"{detail}. The host CLI is used only as the login source; "
            f"benchmark tasks remain pinned to reviewed runtime "
            f"{CODEBUDDY_CLI_VERSION}. "
            "complete CodeBuddy login in your own interactive Terminal, then retry."
        )
        return 1
    try:
        target = import_host_login()
    except (OSError, ValueError) as exc:
        print(
            "CodeBuddy login could not be imported. Complete the official "
            "CodeBuddy login in your own interactive Terminal, then run "
            f"`dradar provider setup codebuddy` again: {exc}"
        )
        return 2
    ok, detail = codebuddy_credential_status()
    if not ok:
        print(f"CodeBuddy provider not ready: {detail}")
        return 1
    docker = shutil.which("docker")
    if not docker:
        print("CodeBuddy setup needs Docker, which DRadar also uses for tasks.")
        return 1
    try:
        image = ensure_codebuddy_runtime_image(docker)
    except ModuleNotFoundError as exc:
        missing = exc.name or "an installed component"
        print(
            "CodeBuddy login was imported, but runtime preparation is missing "
            f"{missing}. Reinstall or upgrade dradar, then run "
            "`dradar provider setup codebuddy` again."
        )
        return 1
    except ValueError as exc:
        print(f"CodeBuddy login was imported, but runtime preparation failed: {exc}")
        return 1
    print(
        f"CodeBuddy subscription login imported to {target} (values hidden).\n"
        f"Pinned Linux runtime ready as {image}; model {CODEBUDDY_MODEL}, "
        "isolated concurrent task sessions enabled."
    )
    print(
        "No provider request was made. To spend one minimal probe request and "
        "verify HY4 access, run: dradar provider status codebuddy --live"
    )
    return 0


def _status_codebuddy_subscription(*, live: bool) -> int:
    executable = codebuddy_executable()
    cli_issue, host_version = codebuddy_host_cli_status(executable)
    if cli_issue is not None:
        detail = {
            "missing": "CodeBuddy is not installed",
            "unrecognized": "the installed CodeBuddy version could not be recognized",
            "incompatible": (
                f"CodeBuddy {host_version} is incompatible; install "
                f"{CODEBUDDY_CLI_VERSION} or newer within the 2.x series"
            ),
        }.get(cli_issue, "CodeBuddy is not ready")
        print(
            f"CodeBuddy provider not ready: {detail}. The host CLI is used only "
            f"as the login source; benchmark tasks remain pinned to reviewed "
            f"runtime {CODEBUDDY_CLI_VERSION}."
        )
        return 1
    ok, detail = codebuddy_credential_status()
    if not ok:
        print(
            f"CodeBuddy provider not ready: {detail}. Run "
            "`dradar provider setup codebuddy` after completing official login."
        )
        return 1
    issue = codebuddy_runtime_image_error()
    if issue is not None:
        print(
            f"CodeBuddy provider not ready: {issue}. Run "
            "`dradar provider setup codebuddy` to rebuild the reviewed runtime."
        )
        return 1
    print(
        f"CodeBuddy provider ready via {managed_codebuddy_home()} "
        f"({detail}, host CLI {host_version} as login source, runtime CLI "
        f"{CODEBUDDY_CLI_VERSION}, model {CODEBUDDY_MODEL}, "
        "API keys disabled, concurrent task sessions enabled)."
    )
    return _live_codebuddy_status() if live else 0


def _live_codebuddy_status() -> int:
    """Spend one minimal, tool-free request to verify container HY4 access."""

    docker = shutil.which("docker")
    if not docker:
        print("CodeBuddy live status needs Docker.")
        return 1
    prompt = (
        "Reply with exactly DRADAR_CODEBUDDY_AUTH_OK and nothing else. "
        "Do not use tools."
    )
    script = r"""
set -euo pipefail
install -d -m 700 /tmp/codebuddy-config/local_storage /tmp/codebuddy-home
install -d -m 700 \
  /tmp/codebuddy-home/.local/share/CodeBuddyExtension/Data/Public/auth
cp /run/secrets/codebuddy-login/local_storage/entry_*.info \
  /tmp/codebuddy-config/local_storage/
cp /run/secrets/codebuddy-login/auth/*.info \
  /tmp/codebuddy-home/.local/share/CodeBuddyExtension/Data/Public/auth/
chmod 600 /tmp/codebuddy-config/local_storage/entry_*.info
chmod 600 /tmp/codebuddy-home/.local/share/CodeBuddyExtension/Data/Public/auth/*.info
printf '%s\n' '{"mcpServers":{}}' > /tmp/codebuddy-empty-mcp.json
export HOME=/tmp/codebuddy-home
export CODEBUDDY_CONFIG_DIR=/tmp/codebuddy-config
export CODEBUDDY_CODE_ENABLE_TELEMETRY=0
export CODEBUDDY_DISABLE_AUTO_MEMORY=1
export CODEBUDDY_CODE_DISABLE_AUTO_MEMORY=1
export CODEBUDDY_DISABLE_BACKGROUND_TASKS=1
export CODEBUDDY_CODE_DISABLE_BACKGROUND_TASKS=1
export CODEBUDDY_DISABLE_CRON=1
export CODEBUDDY_DISABLE_IDE=1
export CODEBUDDY_SKIP_BUILTIN_MARKETPLACE=1
export DISABLE_AUTOUPDATER=1
exec /opt/codebuddy/bin/codebuddy --print --output-format text \
  --model hy4-preview --effort minimal --permission-mode bypassPermissions \
  --tools "" --strict-mcp-config --mcp-config /tmp/codebuddy-empty-mcp.json \
  --setting-sources user --no-session-persistence --max-turns 1 "$1"
""".strip()
    print(
        "Starting one minimal CodeBuddy HY4 access probe "
        "(this consumes provider usage)..."
    )
    try:
        with tempfile.TemporaryDirectory(
            prefix="dradar-codebuddy-probe-",
        ) as temporary:
            with codebuddy_subscription_session(Path(temporary)) as login_root:
                command = [
                    docker, "run", "--rm", "--pull", "never",
                    "--mount",
                    "type=bind,source="
                    f"{login_root.resolve()},target=/run/secrets/codebuddy-login,"
                    "readonly",
                    CODEBUDDY_CONTAINER_IMAGE,
                    "/bin/bash", "-lc", script,
                    "dradar-codebuddy-probe", prompt,
                ]
                probed = subprocess.run(
                    command,
                    capture_output=True,
                    text=True,
                    timeout=300,
                    check=False,
                )
    except (OSError, subprocess.TimeoutExpired) as exc:
        print(f"CodeBuddy live probe failed: {type(exc).__name__}.")
        return 1
    except ValueError as exc:
        print(f"CodeBuddy live probe did not start: {exc}")
        return 1
    combined = probed.stdout + "\n" + probed.stderr
    if (
        probed.returncode != 0
        or probed.stdout.strip() != "DRADAR_CODEBUDDY_AUTH_OK"
    ):
        lowered = combined.lower()
        if any(
            marker in lowered
            for marker in ("unauthorized", "login", "token expired")
        ):
            category = "the imported login was rejected"
        elif any(
            marker in lowered
            for marker in ("quota", "usage limit", "rate limit")
        ):
            category = "the CodeBuddy usage window is unavailable"
        else:
            category = "the container could not complete the HY4 request"
        print(
            f"CodeBuddy live probe failed: {category}. Credentials and raw "
            "provider output were not displayed."
        )
        return 1
    print(
        f"CodeBuddy container authentication and {CODEBUDDY_MODEL} access verified "
        f"live with CLI {CODEBUDDY_CLI_VERSION}."
    )
    return 0


def _live_deepseek_status(key: str) -> int:
    """Verify auth and reachability without making a billable model request."""

    try:
        response = _provider_httpx_get(
            _DEEPSEEK_MODELS_URL,
            headers={"Authorization": f"Bearer {key}"},
            timeout=10.0,
            follow_redirects=False,
        )
    except httpx.HTTPError as exc:
        print(
            "DeepSeek live check failed before authentication completed: "
            f"{type(exc).__name__}. Check this machine's network/proxy, then retry."
        )
        return 1
    if response.status_code == 401:
        print(
            "DeepSeek live check rejected this API key (HTTP 401). Run "
            "`dradar provider setup deepseek` to replace it."
        )
        return 1
    if response.status_code != 200:
        print(
            "DeepSeek live check failed "
            f"(HTTP {response.status_code}); the saved key was not displayed."
        )
        return 1
    try:
        payload = response.json()
    except ValueError:
        print("DeepSeek live check returned an invalid models response.")
        return 1
    available = {
        item.get("id")
        for item in payload.get("data", [])
        if isinstance(item, dict)
    } if isinstance(payload, dict) else set()
    # DeepSeek retired the deepseek-v4-flash listing: accounts now expose the
    # Flash family only as deepseek-flash, and pro/vision entries never appear
    # in this list.  Gate on any Flash-family slug so both migrated and
    # not-yet-migrated accounts pass; request-time routing resolves both to
    # the slug the account actually serves.
    flash_witnesses = (DEEPSEEK_API_FLASH_MODEL, DEEPSEEK_FLASH_MODEL)
    if not any(slug in available for slug in flash_witnesses):
        listed = ", ".join(sorted(str(item) for item in available if item)) or "none"
        print(
            "DeepSeek authentication succeeded, but no Flash-family model "
            f"({DEEPSEEK_API_FLASH_MODEL}, or legacy {DEEPSEEK_FLASH_MODEL}) "
            "is listed for this account; models listed: " + listed
        )
        return 1
    print("DeepSeek API authentication and Flash model availability verified live.")
    return 0


def _setup_zcode() -> int:
    if not sys.stdin.isatty():
        print(
            "ZCode setup needs an interactive terminal so the Coding Plan key "
            "can be entered with echo disabled. Run:\n"
            "  dradar provider setup zcode\n"
            "The key stays in DRadar's owner-only secret directory."
        )
        return 2
    cli = zcode_cli_path()
    issue = zcode_cli_error(cli)
    if issue is not None:
        print(
            "ZCode setup could not find a compatible official "
            f"desktop runtime: {issue}\n"
            f"Install it from {ZCODE_OFFICIAL_DOWNLOAD_PAGE}, then retry. "
            "Advanced users may point ZCODE_CLI_PATH at "
            "Resources/glm/zcode.cjs; DRadar verifies its CLI version before use."
        )
        return 1
    try:
        imported_cli = store_zcode_cli(cli)
    except (OSError, ValueError) as exc:
        print(f"could not import the compatible ZCode runtime: {exc}")
        return 1
    key = getpass.getpass("BigModel Coding Plan API key (input hidden): ")
    try:
        path = store_zcode_api_key(key)
    except (OSError, ValueError) as exc:
        print(f"could not save ZCode Coding Plan API key: {exc}")
        return 1
    print(
        f"ZCode Coding Plan API key saved locally at {path} (value hidden).\n"
        f"Compatible ZCode runtime imported to {imported_cli}.\n"
        "It is never sent to the DRadar server."
    )
    if _live_zcode_status(key) != 0:
        print(
            "The credential remains saved, but it is not ready for a task yet. "
            "Fix the reported account/network issue, then run: "
            "dradar provider status zcode --live"
        )
        return 1
    return 0


def _status_zcode(*, live: bool) -> int:
    path = zcode_secret_path()
    issue = zcode_secret_error(path)
    key = zcode_api_key()
    if issue is not None:
        print(f"ZCode provider not ready: {issue}")
        return 1
    if key is None:
        print(
            "ZCode provider not configured. In your own interactive Terminal run:\n"
            "  dradar provider setup zcode"
        )
        return 1
    cli = zcode_cli_path()
    issue = zcode_cli_error(cli)
    if issue is not None:
        print(f"ZCode provider not ready: {issue}")
        return 1
    node = shutil.which("node")
    if not node:
        print("ZCode provider not ready: Node.js is not available on PATH.")
        return 1
    try:
        proc = subprocess.run(
            [node, str(cli), "version"],
            capture_output=True,
            text=True,
            timeout=15,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        print(f"ZCode provider not ready: could not verify the CLI: {exc}")
        return 1
    found = parse_zcode_cli_version(proc.stdout + "\n" + proc.stderr)
    if proc.returncode != 0 or not zcode_cli_version_is_compatible(found):
        print(
            "ZCode provider not ready: compatible CLI 0.16.x required, "
            f"found {found or 'unknown'}."
        )
        return 1
    source = zcode_credential_source()
    available_models = sorted(
        model for model in ZCODE_MODELS
        if zcode_cli_version_is_compatible(found, model=model)
    )
    print(
        f"ZCode provider ready via {source or 'local credential'} "
        f"(value hidden, CLI {found}, models "
        f"{', '.join(available_models)})."
    )
    return _live_zcode_status(key) if live else 0


def _live_zcode_status(key: str) -> int:
    """Check the domestic Coding Plan catalog without starting a paid turn."""

    try:
        response = _provider_httpx_get(
            _ZCODE_MODELS_URL,
            headers={"Authorization": f"Bearer {key}"},
            timeout=10.0,
            follow_redirects=False,
        )
    except httpx.HTTPError as exc:
        print(
            "ZCode live check failed before authentication completed: "
            f"{type(exc).__name__}. Check this machine's network/proxy, then retry."
        )
        return 1
    if response.status_code in {401, 403}:
        print(
            f"ZCode live check rejected this Coding Plan key (HTTP "
            f"{response.status_code}). Run `dradar provider setup zcode` to replace it."
        )
        return 1
    if response.status_code != 200:
        print(
            f"ZCode live check failed (HTTP {response.status_code}); the saved "
            "key was not displayed."
        )
        return 1
    try:
        payload = response.json()
    except ValueError:
        print("ZCode live check returned an invalid models response.")
        return 1
    available = {
        item.get("id")
        for item in payload.get("data", [])
        if isinstance(item, dict)
    } if isinstance(payload, dict) else set()
    missing = sorted(ZCODE_MODELS - available)
    if missing:
        print(
            "ZCode authentication succeeded, but the following models are not "
            f"available: {', '.join(missing)} "
            "to this Coding Plan account."
        )
        return 1
    print(
        "ZCode Coding Plan authentication and model availability verified live: "
        + ", ".join(sorted(ZCODE_MODELS)) + "."
    )
    return 0


def _setup_grok_subscription() -> int:
    """Launch official device OAuth in a DRadar-owned GROK_HOME."""

    executable = _ensure_grok_cli()
    if not executable:
        return 1
    if grok_auth_error() is None:
        live_issue = grok_live_error(executable)
        if live_issue is None:
            print(
                f"Grok subscription provider is already ready (CLI "
                f"{GROK_CLI_VERSION}, {GROK_MODEL} verified)."
            )
            return 0
    if not sys.stdin.isatty():
        print(
            f"Grok CLI {GROK_CLI_VERSION} is ready. OAuth setup needs an "
            "interactive terminal. Run:\n"
            "  dradar provider setup grok\n"
            "This opens the official xAI device OAuth flow; no API key is accepted."
        )
        return 2
    home = grok_home()
    home.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        with tempfile.TemporaryDirectory(
            prefix=".grok-login-", dir=home.parent,
        ) as name:
            native_home = Path(name)
            # Grok is a Rust binary and does not read macOS System
            # Configuration proxies itself.  Preserve explicit shell proxy
            # variables and fill otherwise-missing values from the OS proxy
            # settings, just as the installer and live probe do.
            env = provider_subprocess_env()
            env["HOME"] = str(native_home)
            env.pop("GROK_HOME", None)
            env.pop(GROK_API_KEY_ENV, None)
            print(
                "Starting official Grok device OAuth for the dedicated DRadar slot. "
                "Complete the browser/device prompt shown by Grok."
            )
            proc = subprocess.run(
                [executable, "login", "--device-auth"], env=env,
            )
            if proc.returncode != 0:
                print("Grok OAuth login did not complete successfully.")
                return proc.returncode or 1
            native_auth = native_home / ".grok" / "auth.json"
            try:
                store_grok_auth(native_auth)
            except (OSError, ValueError) as exc:
                print(f"Grok login returned but the credential is not ready: {exc}")
                return 1
    except OSError as exc:
        print(f"could not start Grok login: {exc}")
        return 1
    live_issue = grok_live_error(executable)
    if live_issue is not None:
        print(
            "Grok login completed, but the live subscription check failed: "
            f"{live_issue}. Run `dradar provider setup grok` again after fixing "
            "the account/network issue."
        )
        return 1
    print(
        f"Grok subscription OAuth is ready at {grok_auth_path()} (tokens hidden).\n"
        "The credential stays local and API-key authentication is disabled."
    )
    return 0


def _status_grok_subscription() -> int:
    executable = grok_cli_path()
    if not executable:
        print("Grok subscription provider not ready: official Grok CLI not found.")
        return 1
    found_version = _grok_cli_version(executable)
    if found_version != GROK_CLI_VERSION:
        print(
            f"Grok subscription provider not ready: CLI {GROK_CLI_VERSION} "
            f"required, found {found_version or 'unknown'}. Run "
            "`dradar provider setup grok` to prepare it automatically."
        )
        return 1
    issue = grok_auth_error()
    if issue is not None:
        print(f"Grok subscription provider not ready: {issue}")
        return 1
    live_issue = grok_live_error(executable)
    if live_issue is not None:
        print(f"Grok subscription provider not ready: {live_issue}.")
        return 1
    print(
        f"Grok subscription provider ready via {grok_auth_path()} "
        f"(OAuth tokens hidden, CLI {GROK_CLI_VERSION}, {GROK_MODEL} verified, "
        "API keys disabled)."
    )
    return 0


def _setup_kimi_subscription() -> int:
    """Launch Kimi's device OAuth in a dedicated DRadar data root."""

    executable = _ensure_kimi_cli()
    if not executable:
        return 1
    if kimi_auth_error() is None:
        live_issue = kimi_live_error(executable)
        if live_issue is None:
            print(
                f"Kimi subscription provider is already ready "
                f"(CLI {KIMI_CLI_VERSION}, K3 verified)."
            )
            return 0
    if not sys.stdin.isatty():
        print(
            f"Kimi Code CLI {KIMI_CLI_VERSION} is ready. OAuth setup needs an "
            "interactive terminal. Run:\n"
            "  dradar provider setup kimi\n"
            "This opens the official Kimi device OAuth flow; no API key is accepted."
        )
        return 2
    home = kimi_home()
    home.mkdir(parents=True, exist_ok=True, mode=0o700)
    if os.name != "nt":
        os.chmod(home, 0o700)
    try:
        env = provider_subprocess_env()
        env["KIMI_CODE_HOME"] = str(home)
        env["KIMI_DISABLE_TELEMETRY"] = "1"
        env["KIMI_CODE_NO_AUTO_UPDATE"] = "1"
        for name in KIMI_API_KEY_ENVS:
            env.pop(name, None)
        print(
            "Starting official Kimi device OAuth for the dedicated DRadar slot. "
            "Complete the browser/device prompt shown by Kimi."
        )
        proc = subprocess.run([executable, "login"], env=env)
    except OSError as exc:
        print(f"could not start Kimi login: {exc}")
        return 1
    if proc.returncode != 0:
        print("Kimi OAuth login did not complete successfully.")
        return proc.returncode or 1
    path = kimi_auth_path()
    if os.name != "nt" and path.is_file():
        os.chmod(path, 0o600)
    issue = kimi_auth_error(path)
    if issue is not None:
        print(f"Kimi login returned but the credential is not ready: {issue}")
        return 1
    live_issue = kimi_live_error(executable)
    if live_issue is not None:
        print(
            "Kimi login completed, but the live K3 subscription check failed: "
            f"{live_issue}. Run `dradar provider setup kimi` again after fixing "
            "the account/network issue."
        )
        return 1
    print(
        f"Kimi subscription OAuth is ready at {path} (tokens hidden).\n"
        "The credential stays local and API-key authentication is disabled."
    )
    return 0


def _status_kimi_subscription(*, live: bool = True) -> int:
    executable = kimi_cli_path()
    if not executable:
        print("Kimi subscription provider not ready: official Kimi CLI not found.")
        return 1
    found_version = _kimi_cli_version(executable)
    if found_version != KIMI_CLI_VERSION:
        print(
            f"Kimi subscription provider not ready: CLI {KIMI_CLI_VERSION} "
            f"required, found {found_version or 'unknown'}. Run "
            "`dradar provider setup kimi` to prepare it automatically."
        )
        return 1
    issue = kimi_auth_error()
    if issue is not None:
        print(f"Kimi subscription provider not ready: {issue}")
        return 1
    # Keep the default status strict, matching Grok: a structurally valid but
    # revoked refresh token must not be reported as ready. `live` is accepted
    # for CLI symmetry and future callers; both paths are intentionally live.
    del live
    live_issue = kimi_live_error(executable)
    if live_issue is not None:
        print(f"Kimi subscription provider not ready: {live_issue}.")
        return 1
    print(
        f"Kimi subscription provider ready via {kimi_auth_path()} "
        f"(OAuth tokens hidden, CLI {KIMI_CLI_VERSION}, K3 verified, "
        "API keys disabled)."
    )
    return 0


__all__ = ["cmd_provider_setup", "cmd_provider_status"]
