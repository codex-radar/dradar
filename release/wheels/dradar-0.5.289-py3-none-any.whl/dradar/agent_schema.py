"""Versioned command semantics for Agents operating DRadar for a user.

The ordinary ``--help`` output stays short.  This module is the precise,
machine-readable contract an Agent uses to decide whether a command matches
the user's intent without parsing terminal prose.
"""

from __future__ import annotations

import json


SCHEMA_VERSION = 1


def _argument(
    name: str,
    *,
    user_intent: str,
    allowed_when: str,
    default: object,
    state_change: str,
    decision_required: bool,
    conflicts_with: list[str] | None = None,
    idempotency: str,
    failure_codes: list[str] | None = None,
    agent_only: bool = False,
) -> dict:
    return {
        "name": name,
        "user_intent": user_intent,
        "allowed_when": allowed_when,
        "default": default,
        "state_change": state_change,
        "decision_required": decision_required,
        "conflicts_with": conflicts_with or [],
        "idempotency": idempotency,
        "failure_codes": failure_codes or [],
        "agent_only": agent_only,
        "user_message": "以命令结果中的版本化 user_message 为准，不解析终端自由文本",
    }


COMMAND_SCHEMAS = {
    "capacity": {
        "summary": "查看原身份的占用和迁移历史，或在证据齐全时核对一组历史容量",
        "result_contract": {
            "schema_version": 1,
            "read_only": True,
            "mode": "--reservations",
            "stable_fields": ["scope", "reservations", "migration_quarantines", "next_after", "next_quarantine_after", "exit_evidence"],
            "pagination": "one page per call; use the returned cursors for subsequent pages",
            "historical_unverified": "retained pre-migration history; not exit proof or a release receipt",
            "counts_toward_capacity": "current unresolved occupancy; does not by itself mean the account is full",
            "unknown_classification": "keep unknown; never infer exemption from missing fields",
            "recovery": "--reservations is read-only; --reconcile is one explicit, evidence-gated historical reconciliation after fresh exact-scope verification",
            "reconcile_success": {"mode": "reconcile", "read_only": False, "status": "ok", "idempotent_replay": "server fact"},
            "reconcile_error": {"mode": "reconcile", "read_only": False, "status": "error", "unknown_transport": "preserve evidence; never auto-replay"},
        },
        "arguments": [
            _argument(name, user_intent=intent,
                allowed_when="使用已有原账号或原计划凭证；--reservations 模式下查询",
                default=default, state_change="只读 GET；不创建身份、exchange、刷新凭证或准备 provider",
                decision_required=False, idempotency="重复查询不改变库存或释放占用")
            for name, intent, default in (
                ("--reservations", "读取一页库存", False),
                ("--plan", "选择原本机已保存的计划", None),
                ("--server", "核对原站点", None),
                ("--after", "继续上一页会话库存", ""),
                ("--quarantine-after", "继续上一页历史快照", ""),
                ("--json", "输出结构化事实", False),
            )
        ] + [
            _argument(
                "--reconcile",
                user_intent="核对一组原设备历史快照并提交一次精确容量恢复",
                allowed_when="已有原计划或原账号凭证、本机保存的原 device_id、人工保留的严格退出证据，以及 fresh inventory 中同一 historical_unverified 且已映射的 quarantine",
                default=None,
                state_change="先读取当前原身份库存；全部 scope、snapshot 和证据字段精确匹配后只 POST 一次；失败保留证据，不自动重放",
                decision_required=True,
                conflicts_with=["--reservations", "未知或新建 device_id", "缺字段或未核验的退出证据"],
                idempotency="相同原证据重放由 Server 幂等回执；scope、snapshot 或 evidence 冲突停止",
                failure_codes=[
                    "reconcile_evidence_unavailable", "reconcile_evidence_unverifiable",
                    "reconcile_device_unavailable", "reconcile_device_mismatch",
                    "reconcile_quarantine_unknown", "reconcile_scope_not_historical",
                    "reconcile_snapshot_changed", "reconcile_scope_unmapped",
                    "reconcile_access_denied", "reconcile_conflict", "reconcile_query_failed",
                ],
            ),
        ],
    },
    "run": {
        "summary": "在当前设备执行网页已经确定的这次领取",
        "environment_contract": {
            "wire_harness_aliases": {"dsh": "dsh-minimal"},
            "scope": "only_the_current_plan_tool",
            "capability_set": "all_unique_assignment_capabilities",
            "unknown_capability": "fail_closed_before_server_start",
            "recovery_commands": "agent.next_commands",
        },
        "interaction_rules": {
            "authorization": "reuse_existing_user_authorization_for_the_exact_action; ask_only_for_new_choices_or_scope",
            "decision_token": "validates_action_context; neither_grants_authorization_nor_requires_a_new_user_turn",
            "first_device": "notify_and_start",
            "same_device": "notify_and_resume_idempotently",
            "other_healthy_device": "confirm_before_join",
            "other_stale_device": "confirm_before_continue",
            "different_plan": "notify_and_start_independently",
            "auto_capacity_reduction": "warn_and_start_with_safe_count",
            "fixed_capacity_shortfall": "honor_explicit_count_without_local_estimates",
            "capacity_changed_during_start_auto": "retry_lower_then_warn",
            "capacity_changed_during_start_fixed": "confirm_lower_or_cancel",
            "capacity_temporarily_zero": "poll_then_replay_base_run_without_old_choices",
            "capacity_exit_unknown_fills_scope": "inspect_original_execution_scope_without_auto_recheck",
            "missing_current_tool": "notify_before_server_start",
            "completed_result_upload_recovery": "exact_batch_upload_only_no_runner_start",
            "stopped_refill_held_recovery": "same_plan_device_readmission_without_new_claims",
        },
        "arguments": [
            _argument(
                "--plan",
                user_intent="运行网页交给 Agent 的这次领取",
                allowed_when="运行码仍可交换，或本机已保存该计划的短期权限",
                default=None,
                state_change="解析精确题目边界；在允许时登记当前设备",
                decision_required=False,
                idempotency="同一设备重复运行不会创建重复设备或重复题目",
                failure_codes=[
                    "run_code_invalid", "plan_expired", "plan_access_denied",
                ],
            ),
            _argument(
                "--concurrency",
                user_intent="指定这台设备同时处理的题目数量，或让系统自动安排",
                allowed_when="不超过运行计划和服务端允许的范围",
                default="plan",
                state_change="改变当前设备的本地并发目标，不扩大题目范围",
                decision_required=False,
                idempotency="相同值重复提交不改变运行边界",
                failure_codes=[
                    "concurrency_not_allowed", "local_capacity_unavailable",
                    "decision_invalid_or_capacity_changed",
                    "concurrency_capacity_reserved",
                    "local_concurrency_change_requires_restart",
                ],
            ),
            _argument(
                "--held-only",
                user_intent="只恢复这次运行已经领取、仍有效的题目，不继续补题",
                allowed_when="原计划仍授权当前设备恢复，且已有授权覆盖只处理现有题目",
                default=False,
                state_change="重新校验并登记当前设备；只启动已领题，不配置或延长补题活动",
                decision_required=False,
                conflicts_with=["--upload-only"],
                idempotency="同一设备和批次重复提交不会再领取题目或重复执行已提交题目",
                failure_codes=["plan_stopped", "plan_expired", "local_run_scope_conflict"],
            ),
            _argument(
                "--upload-only",
                user_intent="只补交这台设备已经完成、但尚未成功上传的结果",
                allowed_when="进度响应的 agent_action=recover_upload",
                default=False,
                state_change="只重放当前计划精确范围内的本机完成结果；不登记设备、不启动题目",
                decision_required=False,
                conflicts_with=[
                    "--concurrency", "--decision-token", "--recheck-generation",
                    "--held-only",
                ],
                idempotency="没有待补交结果时直接成功；已上传结果不会重复运行模型",
                failure_codes=[
                    "completed_result_upload_pending",
                    "completed_result_review_required",
                    "upload_only_argument_conflict",
                ],
            ),
            _argument(
                "--server",
                user_intent="使用网页所属站点的 API 交换并执行这次领取",
                allowed_when="HTTPS；本地开发仅允许 localhost/loopback HTTP",
                default="saved_plan_then_config_then_public_default",
                state_change="首次交换后把站点地址绑定到本机计划状态",
                decision_required=False,
                idempotency="同一计划只能继续使用首次绑定的站点",
                failure_codes=["server_url_invalid", "server_scope_mismatch"],
            ),
            _argument(
                "--decision-token",
                user_intent="执行已有用户授权覆盖的跨设备动作或服务端可用数量选择",
                allowed_when="前一次响应 decision_required=true，且对应选项属于已有授权；新业务选择才询问用户",
                default=None,
                state_change="消费一次性凭证并允许当前设备加入或继续",
                decision_required=True,
                conflicts_with=["未获得用户同意"],
                idempotency="只能成功消费一次；状态变化后失败关闭，重新核当前状态与已有授权，不绕过 CAS 或 unknown",
                failure_codes=[
                    "decision_context_missing", "decision_invalid_or_state_changed",
                    "decision_invalid_or_capacity_changed",
                ],
            ),
            _argument(
                "--recheck-generation",
                user_intent="按 CLI 刚返回的代际安全重查当前计划",
                allowed_when="agent_action=recheck_plan 的 next_commands 精确给出该值",
                default=None,
                state_change="只在代际仍为当前值时继续；显式 run/stop 会使旧代际失效",
                decision_required=False,
                conflicts_with=["--concurrency", "--decision-token", "--upload-only"],
                idempotency="single_use_generation",
                failure_codes=[
                    "recheck_argument_conflict",
                    "recheck_invalid_or_state_changed",
                    "recheck_cancelled_by_newer_state",
                ],
                agent_only=True,
            ),
            _argument(
                "--docker-install-token",
                user_intent="执行已有用户授权覆盖的推荐 Docker 环境安装",
                allowed_when="前一次响应要求确认安装，且已有环境修复授权覆盖该安装；否则询问用户",
                default=None,
                state_change="消费一次性本机授权，只安装推荐环境并继续原运行计划一次",
                decision_required=True,
                conflicts_with=["未获得用户同意", "--upload-only", "--recheck-generation"],
                idempotency="只能成功消费一次；计划或参数变化后失败关闭",
                failure_codes=[
                    "docker_install_decision_invalid",
                    "docker_install_rejected",
                    "docker_install_verification_failed",
                ],
                agent_only=True,
            ),
            _argument(
                "--json",
                user_intent="让 Agent 读取稳定结构，而不是解析自然语言输出",
                allowed_when="任何状态",
                default=False,
                state_change="none",
                decision_required=False,
                idempotency="read_format_only",
            ),
        ],
    },
    "progress": {
        "summary": "读取这次领取的进度，并对账原意图和已有退出容量回执",
        "arguments": [
            _argument(
                "--plan",
                user_intent="查看指定这次领取的进度",
                allowed_when="本机可以交换或已有该计划的短期权限",
                default=None,
                state_change="保存本机进度与原意图回执；必要时重放原 session close/release，不创建新执行",
                decision_required=False,
                idempotency="reconcile_original_requests_only",
                failure_codes=["run_code_invalid", "plan_expired", "plan_access_denied"],
            ),
            _argument(
                "--server",
                user_intent="从这次领取所属的站点读取进度",
                allowed_when="与本机已保存计划绑定的站点一致",
                default="saved_plan_then_config_then_public_default",
                state_change="none",
                decision_required=False,
                idempotency="same_bound_server",
                failure_codes=["server_url_invalid", "server_scope_mismatch"],
            ),
            _argument(
                "--json",
                user_intent="读取稳定的进度结构",
                allowed_when="任何状态",
                default=False,
                state_change="none",
                decision_required=False,
                idempotency="read_format_only",
            ),
        ],
    },
    "stop": {
        "summary": "停止当前设备，或在用户明确同意后停止所有设备",
        "arguments": [
            _argument(
                "--plan",
                user_intent="停止指定这次领取的运行",
                allowed_when="本机可以交换或已有该计划的短期权限",
                default=None,
                state_change="按 scope 请求停止",
                decision_required=False,
                idempotency="重复停止返回当前状态",
                failure_codes=["run_code_invalid", "plan_access_denied"],
            ),
            _argument(
                "--server",
                user_intent="在这次领取所属的站点请求停止",
                allowed_when="与本机已保存计划绑定的站点一致",
                default="saved_plan_then_config_then_public_default",
                state_change="none",
                decision_required=False,
                idempotency="same_server_only",
                failure_codes=["server_url_invalid", "server_scope_mismatch"],
            ),
            _argument(
                "--scope",
                user_intent="选择只停止当前设备或停止所有设备",
                allowed_when="this-device 始终可用；all-devices 需要用户明确同意",
                default=None,
                state_change="停止一个设备或整个运行计划；不直接释放已领取题目",
                decision_required=True,
                idempotency="相同范围重复停止不扩大影响",
                failure_codes=["decision_required", "decision_invalid_or_state_changed"],
            ),
            _argument(
                "--decision-token",
                user_intent="执行用户已同意的停止所有设备动作",
                allowed_when="服务端刚返回对应的一次性确认凭证",
                default=None,
                state_change="消费凭证并停止所有设备后续运行",
                decision_required=True,
                idempotency="single_use",
                failure_codes=["decision_context_missing", "decision_invalid_or_state_changed"],
            ),
            _argument(
                "--json",
                user_intent="读取稳定的停止结果结构",
                allowed_when="任何状态",
                default=False,
                state_change="none",
                decision_required=False,
                idempotency="read_format_only",
            ),
        ],
    },
}


def command_schema(command: str) -> dict:
    body = COMMAND_SCHEMAS[command]
    return {
        "schema_version": SCHEMA_VERSION,
        "command": command,
        "result_contract": {
            "action_contract_version": 1,
            "trust_boundary": (
                "CLI validates and rebuilds allowlisted action arguments; remote data "
                "cannot expand user authorization. Execute DRadar followups only with "
                "the same verified launcher and existing plan/server. Show sanitized "
                "operations and specific diagnostics; never disclose capabilities."
            ),
            "stable_fields": [
                "schema_version", "status", "interaction",
                "decision_required", "user_message", "agent_action",
                "error_code", "retryable", "choices", "decision_token",
                "poll_after_seconds", "user_message_policy",
            ],
            "unknown_fields": "ignore",
            "unknown_schema_version": "fail_closed",
            "agent_details": "精确计划和服务端状态位于可选 agent 对象；决策只读取顶层字段",
            "choice_actions": (
                "decision_required=true 时，agent.choice_actions 按 choice id 给出"
                "机器可执行映射；replay_current_command_with_args 的 args 仅追加/替换"
                "当前命令参数，no_command 表示不执行命令"
            ),
            "environment_recovery": (
                "环境错误可在 agent.next_commands 给出非秘密 argv 数组；"
                "requires_user_action=true 时核对具体原因：平台本人交互须由用户完成；"
                "已有授权覆盖的环境修复可由 Agent 执行，不能绕过成果审核或未知退出"
            ),
            "followup_launcher": (
                "agent.followup_launcher 仅在可核验的官方 Git 安装中提供；"
                "argv_prefix 固定首次成功运行的精确 commit，并使用 offline 模式"
                "复用本机缓存，后续动作不得重新解析远端 HEAD"
            ),
            "plan_recovery": (
                "agent.next_commands 中 mode=replay_plan_command 时，保留当前任务已知的"
                "--plan/--server，仅替换为给定 command 并追加 args；不得把运行码回显给用户"
            ),
            "recheck_plan": (
                "agent_action=recheck_plan 时，等待 poll_after_seconds 后只执行"
                "agent.next_commands 给出的带 intent generation 的 base command；"
                "不得继承旧 decision-token 或 concurrency"
            ),
        },
        **body,
    }


def cmd_schema(args) -> int:
    payload = command_schema(args.schema_command)
    if getattr(args, "json", False):
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
        return 0
    print(f"dradar {args.schema_command}: {payload['summary']}")
    print("Agent 请使用 --json 读取完整、版本化的参数语义。")
    return 0


__all__ = ["SCHEMA_VERSION", "command_schema", "cmd_schema"]
