"""HTTP client for the dradar dispatch server."""

import hashlib
import json
import os
import random
import re
import time
import urllib.parse
import uuid
from email.utils import parsedate_to_datetime
from pathlib import Path
from typing import Any

import httpx

from . import __version__
from .providers import advertised_capabilities, normalize_capabilities
from .submission_intent import (
    LEGACY_UPLOAD_INTENT_VERSION,
    UPLOAD_INTENT_VERSION,
)

_RATE_LIMIT_RETRIES = 5
_DEFAULT_RETRY_AFTER_SEC = 1.0
_MAX_RETRY_AFTER_SEC = 60.0
_SUBMISSION_MAINTENANCE_RETRY_BUDGET_SEC = 360.0
_DEFAULT_MAINTENANCE_RETRY_AFTER_SEC = 1.0
_MAX_SUBMISSION_MAINTENANCE_WAIT_SEC = 60.0
CLIENT_VERSION_HEADER = "X-DRadar-Client-Version"
CLIENT_CAPABILITIES_HEADER = "X-DRadar-Capabilities"


def normalize_batch_id(value: str | None) -> str | None:
    """Validate a user-facing claim-batch UUID and normalize it to hex."""
    if value is None:
        return None
    if not isinstance(value, str) or len(value) not in {32, 36}:
        raise ValueError("batch id must be a 32-hex or canonical 36-character UUID")
    lowered = value.lower()
    try:
        parsed = uuid.UUID(lowered)
    except (ValueError, AttributeError) as exc:
        raise ValueError("batch id must be a valid UUID") from exc
    if len(lowered) == 32:
        canonical = parsed.hex
    else:
        canonical = str(parsed)
    if lowered != canonical:
        raise ValueError("batch id must use canonical UUID syntax")
    return parsed.hex


def _wire_string(value: Any, name: str, minimum: int, maximum: int) -> str:
    if not isinstance(value, str) or not minimum <= len(value) <= maximum:
        raise ValueError(f"{name} must be a string of {minimum}-{maximum} characters")
    return value


def _wire_hex(value: Any, name: str, length: int) -> str:
    if not isinstance(value, str) or not re.fullmatch(rf"[0-9a-f]{{{length}}}", value):
        raise ValueError(f"{name} must be {length} lowercase hex characters")
    return value


def _wire_generation(value: Any) -> int:
    if type(value) is not int or value < 0:
        raise ValueError("expected_generation/device_generation must be a nonnegative integer")
    return value


def _run_plan_intent_payload(operation: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Validate the modern wire shape without coercing authority fields.

    Defaults match the Server payload models; the resulting full shape also
    defines the durable request fingerprint. Legacy callers keep their wire.
    """
    common = {"schema_version", "plan_id", "expected_generation",
              "expected_intent_revision", "intent_id", "decision_token"}
    specific = ({"logical_session_id", "concurrency_mode", "concurrency", "decision"}
                if operation == "start" else {"scope"})
    if operation not in {"start", "stop"} or not isinstance(payload, dict) or payload.keys() - common - specific:
        raise ValueError("invalid run plan intent fields")
    checked = dict(schema_version=1, expected_generation=None,
                   expected_intent_revision=None, intent_id=None, decision_token=None)
    if operation == "start":
        checked.update(concurrency_mode=None, concurrency=None, decision=None)
    checked.update(payload)
    if type(checked["schema_version"]) is not int or checked["schema_version"] != 1:
        raise ValueError("intent schema_version must be integer 1")
    _wire_string(checked.get("plan_id"), "plan_id", 16, 64)
    _wire_generation(checked["expected_generation"])
    _wire_generation(checked["expected_intent_revision"])
    _wire_hex(checked["intent_id"], "intent_id", 32)
    token = checked["decision_token"]
    if token is not None and (not isinstance(token, str) or not token):
        raise ValueError("decision_token must be a nonempty string or null")
    if operation == "start":
        _wire_string(checked.get("logical_session_id"), "logical_session_id", 8, 64)
        if checked["concurrency_mode"] not in (None, "auto", "fixed"):
            raise ValueError("invalid concurrency_mode")
        concurrency = checked["concurrency"]
        if concurrency is not None and (type(concurrency) is not int or not 1 <= concurrency <= 40):
            raise ValueError("concurrency must be an integer from 1 to 40 or null")
        if checked["decision"] not in (None, "join_existing", "recover_stale"):
            raise ValueError("invalid start decision")
    elif checked.get("scope") not in ("this_device", "all_devices"):
        raise ValueError("invalid stop scope")
    return checked


def _cleanup_payload(payload: Any, *, legacy: bool = False) -> dict[str, Any]:
    """Validate declarations without inventing exit evidence or evidence IDs."""
    common = {"schema_version", "evidence_id", "execution_manifest_sha256"}
    required = common | ({"quarantine_id", "snapshot_sha256", "managed_process_inventory",
                           "owned_container_inventory", "historical_scope_verified"}
                         if legacy else {"session_id", "batch_id", "device_generation",
                                         "exit_state", "process_tree", "owned_containers"})
    if not isinstance(payload, dict) or not required <= payload.keys() or payload.keys() - required - {"device_id"}:
        raise ValueError("cleanup payload has missing or unknown fields")
    checked = dict(payload)
    if type(checked["schema_version"]) is not int or checked["schema_version"] != 1:
        raise ValueError("cleanup schema_version must be integer 1")
    _wire_hex(checked["evidence_id"], "evidence_id", 32)
    _wire_hex(checked["execution_manifest_sha256"], "execution_manifest_sha256", 64)
    if checked.get("device_id") is not None:
        _wire_string(checked["device_id"], "device_id", 8, 200)
    if legacy:
        _wire_hex(checked["quarantine_id"], "quarantine_id", 64)
        _wire_hex(checked["snapshot_sha256"], "snapshot_sha256", 64)
        if checked["historical_scope_verified"] is not True:
            raise ValueError("historical scope must be explicitly verified")
        confirmations = ("managed_process_inventory", "owned_container_inventory")
    else:
        _wire_string(checked["session_id"], "session_id", 8, 64)
        _wire_string(checked["batch_id"], "batch_id", 16, 64)
        _wire_generation(checked["device_generation"])
        if checked["exit_state"] != "confirmed":
            raise ValueError("exit_state must be confirmed")
        confirmations = ("process_tree", "owned_containers")
    if any(checked[field] != "confirmed_absent" for field in confirmations):
        raise ValueError("cleanup requires explicit confirmed_absent declarations")
    return checked


def _env_proxies_set() -> bool:
    """Any of the proxy env vars httpx honors. Passing ANY explicit transport
    to httpx.Client disables its environment-proxy mounting entirely, so the
    connect-retry transport below must stand aside on proxied machines."""
    return any(os.environ.get(k) for k in (
        "HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "NO_PROXY",
        "http_proxy", "https_proxy", "all_proxy", "no_proxy"))


class ApiError(RuntimeError):
    def __init__(self, message: str, status_code: int | None = None,
                 code: str | None = None, retry_after: float | None = None,
                 required_capability: str | None = None,
                 payload: dict[str, Any] | None = None,
                 transport_phase: str | None = None,
                 transport_kind: str | None = None):
        # None means "never got a real HTTP response" (DNS/connect/timeout) —
        # callers that need to branch on a specific status (e.g. 409 vs 410)
        # must check this instead of grepping the message, which can contain
        # a server URL/port or arbitrary error text that happens to embed the
        # same digits as a status code.
        super().__init__(message)
        self.status_code = status_code
        # Stable application error code from newer servers. ``None`` is
        # expected for transport failures and older deployments; callers must
        # retain a conservative compatibility fallback for those responses.
        self.code = code
        self.retry_after = retry_after
        # A 426 can mean either that the binary is too old or that one local
        # provider is not ready. Preserve the server's exact requirement so
        # run supervision never has to infer the provider from prose.
        self.required_capability = required_capability
        # Versioned endpoints can return a complete Agent-facing envelope.
        # Keep it as structured data so callers never have to parse prose.
        self.payload = payload
        self.transport_phase = transport_phase
        self.transport_kind = transport_kind


class ApiClient:
    def __init__(self, server: str, token: str,
                 transport: httpx.BaseTransport | None = None,
                 capabilities: tuple[str, ...] | list[str] | set[str] | None = None,
                 benchmark_id: str | None = None,
                 batch_id: str | None = None):
        self.server = server.rstrip("/")
        # Stable, non-secret account boundary for local safety latches. Never
        # persist or expose the bearer token itself.
        self.account_scope = (
            hashlib.sha256(
                f"{self.server}\0{token}".encode("utf-8"),
            ).hexdigest()
            if token else None
        )
        self.plan_scoped = token.startswith("drp_")
        self.benchmark_id = benchmark_id
        self.batch_id = normalize_batch_id(batch_id)
        self._explicit_transport = transport
        # write=None: large uploads over a slow tunnel must not hit a write
        # timeout; keep a bounded connect/read so a dead server fails fast.
        # No header at all when tokenless (pre-registration): an empty
        # "Bearer " is an illegal header value.
        # transport is a test seam (httpx.MockTransport); when none is
        # injected, default to connect-phase retries: httpx re-attempts only
        # failed connection ESTABLISHMENT (DNS blip, refused/reset before the
        # request is sent) and never re-sends a request whose bytes went out,
        # so this is safe for the POST claim/submit endpoints (no duplicate
        # side effects). EXCEPT on proxied machines: httpx mounts
        # HTTP(S)_PROXY/ALL_PROXY only when no explicit transport is passed,
        # so there we keep httpx's default transport (proxy correctness
        # beats a connect-retry nicety — a good chunk of the volunteer pool
        # reaches the server only through a proxy).
        headers = {CLIENT_VERSION_HEADER: __version__}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        active_capabilities = normalize_capabilities(
            advertised_capabilities() if capabilities is None else capabilities
        )
        # Worker-pool parents hand this exact, already-evaluated snapshot to
        # their child processes. Re-probing stateful provider runtimes in
        # every child can produce a transiently different header even though
        # the parent just passed the same server gate.
        self.capabilities = active_capabilities
        if active_capabilities:
            headers[CLIENT_CAPABILITIES_HEADER] = ",".join(active_capabilities)
        if transport is None and not _env_proxies_set():
            transport = httpx.HTTPTransport(retries=2)
        self._client = httpx.Client(
            base_url=self.server,
            headers=headers,
            timeout=httpx.Timeout(30.0, write=None, read=120.0),
            transport=transport,
        )
        # Test seams also keep the retry policy deterministic without making
        # ordinary callers care about clocks or jitter.
        self._sleep = time.sleep
        self._jitter = random.uniform
        self._monotonic = time.monotonic
        self._wall_time = time.time
        self._submission_maintenance_retry_budget = (
            _SUBMISSION_MAINTENANCE_RETRY_BUDGET_SEC
        )
        self._submission_maintenance_deadlines: dict[str, float] = {}

    def _get(self, path: str) -> dict[str, Any]:
        return self._check(self._request("GET", path))

    def _post(self, path: str, **kw) -> dict[str, Any]:
        return self._check(self._request("POST", path, **kw))

    def _benchmark_path(self, path: str) -> str:
        if not self.benchmark_id:
            return path
        separator = "&" if "?" in path else "?"
        return (path + separator + "benchmark="
                + urllib.parse.quote(self.benchmark_id, safe=""))

    @staticmethod
    def _query_path(path: str, key: str, value: str | None) -> str:
        if value is None:
            return path
        separator = "&" if "?" in path else "?"
        return path + separator + key + "=" + urllib.parse.quote(value, safe="")

    def set_batch_id(self, batch_id: str | None) -> None:
        self.batch_id = normalize_batch_id(batch_id)

    def _request(
        self, method: str, path: str, *, retry_rate_limit: bool = True, retry_transport: bool = True, **kw,
    ) -> httpx.Response:
        for attempt in range(_RATE_LIMIT_RETRIES + 1):
            try:
                response = self._client.request(method, path, **kw)
            except httpx.HTTPError as exc:  # transport-level: connect/timeout/etc.
                if retry_transport and attempt < 3 and method in {"GET", "HEAD"}:
                    self._sleep(1.0 * (attempt + 1))
                    continue
                # Exception text can contain proxy URLs, headers, or request
                # data. The endpoint family and HTTPX failure class are enough
                # to diagnose the stage without logging those values.
                endpoint = path.split("?", 1)[0]
                phases = {
                    "/api/v1/assignment": "assignment_inventory",
                    "/api/v1/assignment/claim": "assignment_claim",
                    "/api/v1/assignment/checkout": "assignment_checkout",
                    "/api/v1/assignment/started": "assignment_started",
                    "/api/v1/refill-campaign/status": "refill_status",
                    "/api/v1/refill-campaign/configure": "refill_configure",
                    "/api/v1/run-plans/start": "run_plan_start",
                    "/api/v1/run-plans/progress": "run_plan_progress",
                    "/api/v1/run-plans/stop": "run_plan_stop",
                    "/api/v1/runner/heartbeat": "runner_heartbeat",
                    "/api/v1/runner/flight-events": "flight_events",
                    "/api/v1/assignments/cleanup-recovery": "cleanup_recovery",
                    "/api/v1/submissions": "submission_upload",
                    "/api/v1/submission-upload-intents": "upload_intent",
                }
                phase = phases.get(endpoint, "other")
                if re.fullmatch(
                    r"/api/v1/assignments/[0-9a-f]{32}/recovery-status",
                    endpoint,
                ):
                    phase = "assignment_recovery_status"
                kind = next((name for cls, name in (
                    (httpx.ConnectTimeout, "connect_timeout"),
                    (httpx.ReadTimeout, "read_timeout"),
                    (httpx.WriteTimeout, "write_timeout"),
                    (httpx.PoolTimeout, "pool_timeout"),
                    (httpx.ConnectError, "connect_error"),
                    (httpx.ReadError, "read_error"),
                    (httpx.WriteError, "write_error"),
                    (httpx.RemoteProtocolError, "remote_protocol_error"),
                    (httpx.LocalProtocolError, "local_protocol_error"),
                ) if isinstance(exc, cls)), "other_http_error")
                raise ApiError(
                    f"cannot reach DRadar API: phase={phase} "
                    f"transport={kind} method={method}",
                    transport_phase=phase,
                    transport_kind=kind,
                ) from exc
            if (
                response.status_code != 429
                or not retry_rate_limit
                or attempt == _RATE_LIMIT_RETRIES
            ):
                return response
            retry_after = self._retry_after(response)
            # A small independent offset prevents a 20-worker pool from
            # waking on the same token boundary and recreating the 429 herd.
            jitter = self._jitter(0.0, min(1.0, retry_after * 0.1))
            self._sleep(retry_after + jitter)
        raise AssertionError("unreachable")

    @staticmethod
    def _retry_after(resp: httpx.Response) -> float:
        try:
            value = float(resp.headers.get("Retry-After", ""))
        except (TypeError, ValueError):
            value = _DEFAULT_RETRY_AFTER_SEC
        return min(_MAX_RETRY_AFTER_SEC, max(_DEFAULT_RETRY_AFTER_SEC, value))

    def _maintenance_retry_after(self, resp: httpx.Response) -> float:
        """Return the server-directed maintenance delay without shortening it.

        Unlike the ordinary 429 backoff, a deployment fence is a promise that
        submission writes are temporarily unavailable.  Retrying before its
        HTTP ``Retry-After`` would defeat that fence, so a large delay is not
        capped here; the separate total retry budget decides whether it can be
        waited safely.  Both RFC HTTP-date and delta-seconds forms are accepted.
        """
        raw = resp.headers.get("Retry-After", "").strip()
        try:
            value = float(raw)
        except (TypeError, ValueError):
            try:
                retry_at = parsedate_to_datetime(raw)
                value = retry_at.timestamp() - self._wall_time()
            except (TypeError, ValueError, OverflowError):
                value = _DEFAULT_MAINTENANCE_RETRY_AFTER_SEC
        if not value >= 0:  # also rejects NaN without importing math
            value = _DEFAULT_MAINTENANCE_RETRY_AFTER_SEC
        return max(_DEFAULT_MAINTENANCE_RETRY_AFTER_SEC, value)

    @staticmethod
    def _is_deployment_maintenance(exc: ApiError) -> bool:
        return (
            exc.status_code == 503
            and exc.code == "deployment_maintenance"
        )

    def _post_submission_write(
        self,
        path: str,
        *,
        maintenance_key: str | None = None,
        retain_maintenance_deadline: bool = False,
        **kw,
    ) -> dict[str, Any]:
        """Retry only an explicitly fenced submission write.

        The exact form/multipart payload (including session/owner/content
        fences) is replayed; no claim or model execution is reachable from
        this helper.  All other 5xx responses remain single-attempt failures.
        """
        deadline = (
            self._submission_maintenance_deadlines.get(maintenance_key)
            if maintenance_key is not None
            else None
        )
        if deadline is None:
            deadline = (
                self._monotonic()
                + self._submission_maintenance_retry_budget
            )
        while True:
            try:
                if (path in {"/api/v1/submissions", "/api/v1/submission-upload-intents"}
                        and isinstance(maintenance_key, str)
                        and re.fullmatch(r"[0-9a-f]{64}", maintenance_key)):
                    import asyncio
                    from .upload_recovery import replay
                    response = asyncio.run(replay(self, path, maintenance_key, deadline, kw))
                else:
                    response = self._post(path, **kw)
            except ApiError as exc:
                if not self._is_deployment_maintenance(exc):
                    if maintenance_key is not None:
                        self._submission_maintenance_deadlines.pop(
                            maintenance_key, None,
                        )
                    raise
                retry_after = exc.retry_after
                if retry_after is None:
                    # _check supplies this for the structured maintenance
                    # envelope. Fail closed if a synthetic/custom client ever
                    # violates that invariant.
                    if maintenance_key is not None:
                        self._submission_maintenance_deadlines.pop(
                            maintenance_key, None,
                        )
                    raise
                remaining = max(0.0, deadline - self._monotonic())
                if (
                    retry_after > remaining
                    or retry_after > _MAX_SUBMISSION_MAINTENANCE_WAIT_SEC
                ):
                    if maintenance_key is not None:
                        self._submission_maintenance_deadlines.pop(
                            maintenance_key, None,
                        )
                    reason = (
                        "safe single-wait limit exceeded"
                        if retry_after > _MAX_SUBMISSION_MAINTENANCE_WAIT_SEC
                        else "retry budget exhausted"
                    )
                    raise ApiError(
                        f"{exc} (deployment maintenance {reason})",
                        status_code=exc.status_code,
                        code=exc.code,
                        retry_after=retry_after,
                        required_capability=exc.required_capability,
                        payload=exc.payload,
                    ) from exc
                self._sleep(retry_after)
                continue
            if maintenance_key is not None:
                if retain_maintenance_deadline:
                    self._submission_maintenance_deadlines[
                        maintenance_key
                    ] = deadline
                else:
                    self._submission_maintenance_deadlines.pop(
                        maintenance_key, None,
                    )
            return response

    def _check(self, resp: httpx.Response) -> dict[str, Any]:
        if resp.status_code >= 400:
            detail: Any = resp.text
            code = None
            required_capability = None
            payload = None
            try:
                body = resp.json()
                if isinstance(body, dict):
                    payload = body
                    detail = body.get("detail", resp.text)
                    if isinstance(detail, dict):
                        nested_detail = detail
                        detail = (
                            nested_detail.get("message")
                            or nested_detail.get("detail")
                            or resp.text
                        )
                    else:
                        nested_detail = {}
                    raw_code = body.get("code")
                    if not isinstance(raw_code, str):
                        raw_code = nested_detail.get("code")
                    if isinstance(raw_code, str):
                        code = raw_code
                    raw_capability = body.get("required_capability")
                    if isinstance(raw_capability, str):
                        required_capability = raw_capability
            except (json.JSONDecodeError, ValueError):
                pass
            raise ApiError(
                f"server returned {resp.status_code}: {detail}",
                status_code=resp.status_code,
                code=code,
                retry_after=(
                    self._retry_after(resp)
                    if resp.status_code == 429
                    else (
                        self._maintenance_retry_after(resp)
                        if resp.status_code == 503 and code == "deployment_maintenance"
                        else (
                            self._retry_after(resp)
                            if resp.status_code == 503 and code == "mutation_busy"
                            else None
                        )
                    )
                ),
                required_capability=required_capability,
                payload=payload,
            )
        return resp.json()

    def register(self, nickname: str) -> dict[str, Any]:
        """Self-serve signup; returns {nickname, token}. No auth required."""
        return self._post("/api/v1/register", data={"nickname": nickname})

    def rename(self, nickname: str) -> dict[str, Any]:
        return self._post("/api/v1/rename", data={"nickname": nickname})

    def my_submissions(self) -> dict[str, Any]:
        """Returns {nickname, points, submissions: [...]} — the volunteer's
        own recent history including grading status/flags the public pages
        hide. 404 on servers that predate this endpoint."""
        return self._get("/api/v1/my-submissions")

    def github_config(self) -> dict[str, Any]:
        return self._get("/api/v1/github/config")

    def github_link(self, access_token: str) -> dict[str, Any]:
        return self._post("/api/v1/github/link", data={"access_token": access_token})

    def github_whoami(self, access_token: str) -> dict[str, Any]:
        return self._post("/api/v1/github/whoami", data={"access_token": access_token})

    def whoami(self) -> dict[str, Any]:
        if self.plan_scoped:
            return self._get("/api/v1/run-plans/identity")
        return self._get("/api/v1/whoami")

    def run_plan_capabilities(self) -> dict[str, Any]:
        """Read protocol support once; the caller decides how to handle old servers."""
        return self._check(self._request(
            "GET", "/api/v1/run-plans/capabilities", timeout=3.0,
            retry_rate_limit=False, retry_transport=False,
        ))

    def require_runner_reservation_protocol(self) -> None:
        """New local execution requires the server's durable reservation contract."""
        value = self.run_plan_capabilities()
        if (not isinstance(value, dict) or type(value.get("schema_version")) is not int
                or value["schema_version"] != 1
                or not isinstance(value.get("capabilities"), list)
                or "runner-reservation-v1" not in value["capabilities"]
                or value.get("stop_generation_cas") is not True
                or value.get("close_releases_capacity") is not False):
            raise ApiError("Server upgrade required before new execution; saved results and stop remain available.",
                           status_code=426, code="runner_reservation_upgrade_required")

    def claim_request_receipt(
        self, request_id: str, *, expected_fingerprint: str | None = None,
    ) -> dict[str, Any]:
        """Read the saved claim intent; unknown never creates a replacement ID."""
        _wire_string(request_id, "request_id", 16, 64)
        params = {}
        if expected_fingerprint is not None:
            params["expected_fingerprint"] = _wire_hex(
                expected_fingerprint, "expected_fingerprint", 64,
            )
        return self._check(self._request(
            "GET", "/api/v1/claim-requests/" + urllib.parse.quote(request_id, safe=""),
            params=params, timeout=3.0, retry_rate_limit=False, retry_transport=False,
        ))

    def exchange_run_plan(
        self,
        *,
        run_code: str,
        device_id: str,
        device_name: str | None = None,
        locale: str | None = None,
    ) -> dict[str, Any]:
        """Exchange a high-entropy invitation for one plan-scoped token.

        The invitation is deliberately sent in the JSON body so the HTTP
        exchange does not put it in a URL, access log, or Authorization
        header. The initial ``dradar --plan`` invocation may contain it in
        argv; this method never forwards it to a worker process. It is called
        on a tokenless client.
        """
        payload: dict[str, Any] = {
            "schema_version": 1,
            "run_code": run_code,
            "device_id": device_id,
        }
        if device_name:
            payload["device_name"] = device_name
        if locale:
            payload["locale"] = locale
        return self._post(
            "/api/v1/run-plans/exchange", json=payload,
            retry_rate_limit=False,
        )

    def renew_run_plan_access(self) -> dict[str, Any]:
        return self._post(
            "/api/v1/run-plans/renew", json={"schema_version": 1},
            retry_rate_limit=False,
        )

    def start_run_plan(
        self,
        *,
        plan_id: str,
        logical_session_id: str,
        concurrency_mode: str | None = None,
        concurrency: int | None = None,
        decision: str | None = None,
        decision_token: str | None = None,
        expected_generation: int | None = None,
        expected_intent_revision: int | None = None,
        intent_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": 1,
            "plan_id": plan_id,
            "logical_session_id": logical_session_id,
            "concurrency_mode": concurrency_mode,
        }
        if expected_generation is not None:
            payload["expected_generation"] = _wire_generation(expected_generation)
        if (expected_intent_revision is None) != (intent_id is None):
            raise ValueError("intent_id and expected_intent_revision must be provided together")
        if intent_id is not None:
            payload["intent_id"] = _wire_hex(intent_id, "intent_id", 32)
            payload["expected_intent_revision"] = _wire_generation(expected_intent_revision)
        if concurrency is not None:
            payload["concurrency"] = concurrency
        if decision is not None:
            payload["decision"] = decision
        if decision_token is not None:
            payload["decision_token"] = decision_token
        if intent_id is not None:
            payload = _run_plan_intent_payload("start", payload)
        if intent_id is not None:
            import asyncio
            from .plan_intent_recovery import recover
            return asyncio.run(recover(self, "start", payload))
        return self._post(
            "/api/v1/run-plans/start", json=payload,
            retry_rate_limit=False, retry_transport=False,
        )

    def run_plan_progress(self, plan_id: str) -> dict[str, Any]:
        from .plan_observation_recovery import recover
        return recover(self, "plan_progress", {"schema_version": 1, "plan_id": plan_id})

    def heartbeat_run_plan(
        self, *, plan_id: str, current_start_intent_id: str,
        expected_intent_revision: int, expected_generation: int,
    ) -> dict[str, Any]:
        """Touch one exact admission without creating or refreshing authority."""
        payload = {
            "schema_version": 1,
            "plan_id": _wire_string(plan_id, "plan_id", 16, 64),
            "current_start_intent_id": _wire_hex(current_start_intent_id, "current_start_intent_id", 32),
            "expected_intent_revision": _wire_generation(expected_intent_revision),
            "expected_generation": _wire_generation(expected_generation),
        }
        from .plan_observation_recovery import recover
        return recover(self, "plan_heartbeat", payload)

    def stop_run_plan(
        self,
        *,
        plan_id: str,
        scope: str,
        decision_token: str | None = None,
        expected_generation: int | None = None,
        expected_intent_revision: int | None = None,
        intent_id: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "schema_version": 1,
            "plan_id": plan_id,
            "scope": scope,
        }
        if expected_generation is not None:
            payload["expected_generation"] = _wire_generation(expected_generation)
        if (expected_intent_revision is None) != (intent_id is None):
            raise ValueError("intent_id and expected_intent_revision must be provided together")
        if intent_id is not None:
            payload["intent_id"] = _wire_hex(intent_id, "intent_id", 32)
            payload["expected_intent_revision"] = _wire_generation(expected_intent_revision)
        if decision_token is not None:
            payload["decision_token"] = decision_token
        if intent_id is not None:
            payload = _run_plan_intent_payload("stop", payload)
        if intent_id is not None:
            import asyncio
            from .plan_intent_recovery import recover
            return asyncio.run(recover(self, "stop", payload))
        return self._post(
            "/api/v1/run-plans/stop", json=payload,
            retry_rate_limit=False, retry_transport=False,
        )

    def run_plan_intent_receipt(
        self, intent_id: str, *, plan_id: str, expected_fingerprint: str | None = None,
    ) -> dict[str, Any]:
        _wire_hex(intent_id, "intent_id", 32)
        _wire_string(plan_id, "plan_id", 16, 64)
        params = {"plan_id": plan_id}
        if expected_fingerprint is not None:
            params["expected_fingerprint"] = _wire_hex(expected_fingerprint, "expected_fingerprint", 64)
        return self._check(self._request(
            "GET", "/api/v1/run-plans/intents/" + intent_id, params=params,
            timeout=3.0, retry_rate_limit=False, retry_transport=False,
        ))

    def benchmarks(self) -> dict[str, Any]:
        """Public benchmark catalog, including optional task-pack metadata."""
        return self._get("/api/v1/benchmarks")

    def download(self, path: str, destination: Path) -> str | None:
        """Stream one authenticated immutable artifact to ``destination``.

        The caller verifies the advertised digest before using the file.  A
        same-origin relative URL is required so a compromised catalog cannot
        redirect the bearer token to another host.
        """
        parsed = urllib.parse.urlparse(path)
        if parsed.scheme or parsed.netloc or not path.startswith("/"):
            raise ApiError("server advertised an unsafe download URL")
        try:
            with self._client.stream("GET", path) as response:
                if response.status_code >= 400:
                    response.read()
                    self._check(response)
                with destination.open("xb") as output:
                    for chunk in response.iter_bytes(chunk_size=1024 * 1024):
                        output.write(chunk)
                return response.headers.get("X-Content-SHA256")
        except httpx.HTTPError as exc:
            raise ApiError(f"cannot download from {self.server}: {exc}") from exc

    def get_assignment(self) -> dict[str, Any]:
        """Returns {active: [dict, ...], free_pick: bool, menu: list|None, ...}
        — `active` is the whole held batch to run, in claim order. Also carries
        legacy `assignment`/`resumed` (first active lease) for older clients."""
        path = self._benchmark_path("/api/v1/assignment")
        data = self._get(self._query_path(path, "batch_id", self.batch_id))
        self._check_managed_assignments(data)
        if self.batch_id is None:
            return data
        # Compatibility guard during a rolling server deployment: if an old
        # server ignores batch_id, filter its broader inventory locally and
        # fail closed rather than starting another campaign's assignment.
        active = data.get("active")
        if active is None:
            one = data.get("assignment")
            active = [one] if one else []
        matching = []
        for item in active:
            if not item:
                continue
            try:
                item_batch_id = normalize_batch_id(item.get("batch_id"))
            except ValueError:
                continue
            if item_batch_id == self.batch_id:
                matching.append(item)
        if not matching:
            raise ApiError(
                "server returned 404: active claim batch not found",
                status_code=404,
                code="claim_batch_not_found",
            )
        scoped = dict(data)
        scoped["active"] = matching
        scoped["assignment"] = matching[0]
        scoped["resumed"] = True
        return scoped

    def get_assignment_inventory(self) -> dict[str, Any]:
        """Read account inventory without asserting local provider readiness.

        This is only for observational commands such as ``dradar leases``.
        Run, checkout, and start paths continue to use ``get_assignment`` and
        the server's exact per-assignment capability gate.
        """
        path = self._benchmark_path("/api/v1/assignment")
        return self._get(self._query_path(path, "inventory", "true"))

    def assignment_recovery_status(self, assignment_id: str) -> dict[str, Any]:
        """Read one exact owned assignment's durable terminal/submission state."""
        if not isinstance(assignment_id, str) or not re.fullmatch(
            r"[0-9a-f]{32}", assignment_id,
        ):
            raise ValueError("assignment ID must be 32 lowercase hex characters")
        path = f"/api/v1/assignments/{assignment_id}/recovery-status"
        return self._get(self._benchmark_path(path))

    def _negotiate_managed_auth_runtime(self, *, task_id=None, model=None, effort=None, assignment_id=None, expected_cohort_id=None):
        from .managed_auth_selection import load_selection, selection_requested, PROFILE, CAPABILITY, TRIAL_CAPABILITY, trial_platform_ready
        from .auth_refresh import RefreshUnavailable
        if not selection_requested():
            return None
        params = {key: value for key, value in {"task_id":task_id,"model":model,"effort":effort,"assignment_id":assignment_id}.items() if value is not None}
        try:
            result = self._check(self._request("GET", "/api/v1/runner/auth-runtime-capabilities", params=params, timeout=3.0, retry_rate_limit=False, retry_transport=False))
        except ApiError:
            raise ApiError("服务端尚未确认受控模式支持；请检查服务端支持或本地模式，没有自动降级。", status_code=409, code="auth_runtime_unavailable") from None
        if (not isinstance(result, dict) or result.get("schema") != "dradar.auth-runtime.v1"
                or not isinstance(result.get("profiles"), list)):
            raise ApiError("服务端认证能力格式未知，受控操作未继续。", status_code=409, code="auth_runtime_unavailable")
        # A server-confirmed non-Codex cell keeps its own provider contract.
        if params and result.get("applicable") is False:
            return None
        if TRIAL_CAPABILITY not in self.capabilities or not trial_platform_ready():
            raise ApiError("当前平台或 Docker 拓扑未获灰度准入，受控操作未继续。", status_code=409, code="managed_trial_platform_unavailable")
        try:
            selected = load_selection()
        except (OSError, ValueError, TypeError, RefreshUnavailable):
            selected = None
        if selected is None or CAPABILITY not in self.capabilities:
            raise ApiError("受控登录源不可用；请检查状态或恢复，没有自动切换账号。", status_code=409, code="managed_auth_unavailable")
        from .gpt6 import GPT6_MODEL_CAPABILITIES, GPT6_MODEL_VERSIONS
        if model in GPT6_MODEL_CAPABILITIES:
            if GPT6_MODEL_CAPABILITIES[model] not in self.capabilities:
                raise ApiError("客户端不支持该 GPT-6 受控任务。", status_code=409, code="auth_runtime_unavailable")
        expected = {"id":PROFILE,"capability":TRIAL_CAPABILITY,"agent":"codex","provider":"openai","agent_version":GPT6_MODEL_VERSIONS.get(model, "0.154.0")}
        if sum(item == expected for item in result["profiles"]) != 1:
            raise ApiError("服务端未提供匹配的受控运行模式，受控操作未继续。", status_code=409, code="auth_runtime_unavailable")
        if assignment_id is not None:
            binding=result.get('binding')
            if (not isinstance(binding,dict) or set(binding)!={'schema','assignment_id','auth_cohort_id','auth_runtime'}
                    or binding.get('schema')!='dradar.managed_trial_binding.v1'
                    or binding.get('assignment_id')!=assignment_id or binding.get('auth_runtime')!=PROFILE
                    or not self._managed_cohort_id(binding.get('auth_cohort_id'))
                    or (expected_cohort_id is not None and binding['auth_cohort_id']!=expected_cohort_id)):
                raise ApiError('Server did not confirm the exact managed trial binding.',status_code=409,code='auth_runtime_mismatch')
        return PROFILE

    @staticmethod
    def _managed_cohort_id(value):
        return isinstance(value,str) and len(value)==32 and all(c in '0123456789abcdef' for c in value)

    def _check_managed_assignments(self, data):
        from .managed_auth_selection import selection_requested, PROFILE
        if not selection_requested():
            return
        active = data.get("active")
        if active is None:
            active = [data.get("assignment")] if data.get("assignment") else []
        continuation_ids = []
        for item in active:
            if item.get("agent") == "codex" and item.get("provider") in (None, "openai"):
                if item.get("auth_runtime") != PROFILE:
                    raise ApiError("已有任务绑定普通认证；请显式选择兼容模式完成它，或释放后重新领取。", status_code=409, code="auth_runtime_mismatch")
                if not self._managed_cohort_id(item.get('auth_cohort_id')) or not self._managed_cohort_id(item.get('assignment_id')):
                    raise ApiError('Managed assignment lacks a valid cohort binding.',status_code=409,code='auth_runtime_mismatch')
                continuation_ids.append((item['assignment_id'],item['auth_cohort_id'],item.get('model')))
        for assignment_id,cohort_id,model in continuation_ids:
            self._negotiate_managed_auth_runtime(assignment_id=assignment_id,model=model,expected_cohort_id=cohort_id)

    def claim_assignment(
        self,
        task_id: str,
        model: str,
        effort: str,
        *,
        refill_campaign_id: str | None = None,
        tier: str | None = None,
        retry_check=None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """Returns {assignment: dict, resumed: False}. Raises ApiError (409) if
        the cell went stale or the volunteer is already at the concurrent cap."""
        profile = self._negotiate_managed_auth_runtime(task_id=task_id, model=model, effort=effort)
        data = {"task_id": task_id, "model": model, "effort": effort}
        if profile is not None:
            data["auth_runtime"] = profile
        if self.benchmark_id:
            data["benchmark_id"] = self.benchmark_id
        if self.batch_id:
            data["batch_id"] = self.batch_id
        if getattr(self, "new_pick_batch", False):
            data["new_batch"] = "true"
            data["selection_id"] = self.pick_selection_id
            data.pop("batch_id", None)
        if refill_campaign_id:
            data["refill_campaign_id"] = refill_campaign_id
        if tier is not None:
            data["tier"] = tier
        admission_ref = getattr(self, "historical_admission_reference", None)
        if admission_ref is not None:
            data["historical_admission_ref"] = admission_ref
        from .acquisition_recovery import recover
        result = recover(self, 'assignment_claim', data, check=retry_check,
                         request_id=request_id)
        if getattr(self, "new_pick_batch", False):
            assignment = result.get("assignment", {})
            selected = assignment.get("batch_id")
            if (not selected or result.get("selection_batch_created") is not True
                    or result.get("selection_id") != self.pick_selection_id):
                raise ApiError("Server did not confirm the new batch; inspect held leases before retrying.",
                               code="batch_scope_unconfirmed")
        if profile is not None:
            assignment=result.get('assignment') if isinstance(result,dict) else None
            if (not isinstance(assignment,dict) or assignment.get('auth_runtime')!=profile
                    or not self._managed_cohort_id(assignment.get('assignment_id'))
                    or not self._managed_cohort_id(assignment.get('auth_cohort_id'))):
                raise ApiError('Server returned an unbound managed assignment; execution was not started.',status_code=409,code='auth_runtime_mismatch')
        return result

    def configure_refill_campaign(
        self,
        *,
        batch_id: str,
        harness: str,
        model: str,
        effort: str,
        refill_to: int,
        max_tasks: int,
        refill_mode: str | None = None,
    ) -> dict[str, Any]:
        """Idempotently create the server-authoritative multi-machine plan."""
        payload = {
            "batch_id": batch_id,
            "benchmark_id": self.benchmark_id or "deep-swe",
            "harness": harness,
            "model": model,
            "effort": effort,
            "refill_to": refill_to,
            "max_tasks": max_tasks,
        }
        if refill_mode is not None:
            payload["refill_mode"] = refill_mode
        return self._post(
            "/api/v1/refill-campaign/configure",
            json=payload,
        )

    def refill_campaign_capabilities(self) -> dict[str, Any]:
        return self._get("/api/v1/refill-campaign/capabilities")

    def refill_campaign_status(self, batch_id: str) -> dict[str, Any]:
        path = self._query_path(
            "/api/v1/refill-campaign/status", "batch_id", batch_id,
        )
        return self._get(path)

    def stop_refill_campaign(self, batch_id: str, reason: str) -> dict[str, Any]:
        return self._post(
            "/api/v1/refill-campaign/stop",
            json={"batch_id": batch_id, "reason": reason[:300]},
        )

    def suggest(self, n: int) -> dict[str, Any]:
        """Weighted-random candidate cells (server-side balanced_random_cells,
        biased toward least-tested), same primitive behind the web's 雷达随机
        推荐 button — powers `dradar go --auto` so a headless/Agent run doesn't
        need a prior web claim. Returns {cells: [menu-entry dict, ...]};
        candidates only, not yet claimed. The server applies ordinary/super
        account-specific recommendation limits."""
        return self._get(self._benchmark_path(f"/api/v1/suggest?n={n}"))

    def table(self) -> dict[str, Any]:
        """Public full-board snapshot.

        Returns the server's task/config matrix plus the live state and
        coverage metadata for every cell.  Unlike suggest() this is not
        personalized and never claims or reserves work.
        """
        return self._get(self._benchmark_path("/api/v1/table"))

    def mark_started(
        self, assignment_id: str, session_id: str | None = None,
        worker_event_id: str | None = None,
    ) -> dict[str, Any]:
        """Confirms the trial subprocess actually started (see runner.run_trial):
        extends a free-pick claim's short initial lease out to the normal
        window. Best-effort by design — callers should swallow ApiError
        rather than let a heartbeat failure abort a real trial. 404 on
        servers that predate this endpoint or on a menu-style lease
        that never had a short window to extend in the first place."""
        from .managed_auth_selection import selection_requested
        if selection_requested():
            self.get_assignment()
        return self._post(
            "/api/v1/assignment/started",
            data={"assignment_id": assignment_id, "session_id": session_id or "",
                  "worker_event_id": worker_event_id or ""},
        )

    def checkout(
        self,
        exclude_assignment_ids: set[str] | list[str] | None = None,
        session_id: str | None = None,
        retry_check=None,
    ) -> dict[str, Any]:
        """Atomically check out this volunteer's next not-yet-started cell —
        the primitive that makes parallel sessions safe: N concurrent callers
        get N different cells. Returns {assignment: dict|None, held, unstarted};
        assignment None means everything held is already checked out or done.
        exclude_assignment_ids lets one CLI session avoid immediately
        re-checking-out a cell that already failed locally in that session.
        404 on servers that predate the endpoint (caller falls back to the
        legacy whole-batch flow)."""
        from .managed_auth_selection import selection_requested
        if selection_requested():
            self.get_assignment()
        excluded = sorted(set(exclude_assignment_ids or ()))
        data = {"exclude_assignment_ids": ",".join(excluded),
                "session_id": session_id or ""}
        if session_id:
            # Current servers can reserve a free-pick cell for this exact
            # runner while its environment is still building.  Older servers
            # ignore the extra form field and keep their historical
            # checkout-starts-runtime behaviour, so this is rolling-upgrade
            # compatible.
            data["prepare_only"] = "true"
        if self.benchmark_id:
            data["benchmark_id"] = self.benchmark_id
        if self.batch_id:
            data["batch_id"] = self.batch_id
        from .acquisition_recovery import recover
        return recover(self, 'assignment_checkout', data, check=retry_check)

    def release_assignments(
        self,
        assignment_ids: list[str] | None = None,
        *,
        release_all: bool = False,
        force: bool = False,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """Immediately release held cells owned by this volunteer.

        The server requires exactly one target mode: explicit IDs or
        release_all. Running cells are protected unless force=True. The
        operation is idempotent so a lost response can be retried safely.
        """
        ids = list(dict.fromkeys(assignment_ids or ()))
        return self._post(
            "/api/v1/assignments/release",
            data={
                "assignment_ids": ",".join(ids),
                "release_all": str(release_all).lower(),
                "force": str(force).lower(),
                "request_id": request_id or "",
            },
        )

    def runner_heartbeat(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Best-effort lease-observation heartbeat (owner protocol v3).

        It is deliberately JSON-only and bounded; the server stores current
        state plus five-minute aggregates, never prompts, patches or command
        output.  A short timeout keeps telemetry from holding up real work.
        """
        import asyncio
        from .telemetry_recovery import replay
        return asyncio.run(replay(self, "/api/v1/runner/heartbeat", payload))

    def runner_close(self, payload: dict[str, Any], *, explicit_replay_once: bool = False) -> dict[str, Any]:
        """Close a runner session without releasing any held lease."""
        import asyncio
        from .session_exit_recovery import recover
        return asyncio.run(recover(self, "/api/v1/runner/close", payload,
                                   explicit_replay_once=explicit_replay_once))

    def runner_session_receipt(
        self, session_id: str, *, batch_id: str,
    ) -> dict[str, Any]:
        """Read close/release acceptance without inferring physical exit."""
        _wire_string(session_id, "session_id", 8, 64)
        _wire_string(batch_id, "batch_id", 16, 64)
        return self._check(self._request(
            "GET", "/api/v1/runner/sessions/" + urllib.parse.quote(session_id, safe="") + "/receipt",
            params={"batch_id": batch_id}, timeout=3.0,
            retry_rate_limit=False, retry_transport=False,
        ))

    def recover_unsubmitted_cleanup(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Retire one exited, unsubmitted assignment with a durable request ID."""
        return self._check(self._request(
            "POST", "/api/v1/assignments/cleanup-recovery", json=payload,
            timeout=10.0, retry_rate_limit=False, retry_transport=False,
        ))

    def register_completed_cleanup_result_intent(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Register the exited original owner's exact completed upload only."""
        return self._check(self._request(
            "POST", "/api/v1/submission-cleanup-result-recovery/intent",
            json=payload, timeout=10.0, retry_rate_limit=False,
            retry_transport=False,
        ))

    def register_completed_cleanup_result_salvage(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Bind one released original to a current idle upload-only owner."""
        return self._post(
            "/api/v1/submission-upload-salvage/rebind", data=payload,
            timeout=10.0, retry_rate_limit=False, retry_transport=False,
        )

    def release_runner_capacity(self, payload: dict[str, Any], *, explicit_replay_once: bool = False) -> dict[str, Any]:
        """Send retained exact cleanup evidence once; reconcile a lost ACK by GET."""
        import asyncio
        from .session_exit_recovery import recover
        return asyncio.run(recover(self, "/api/v1/runner/release-capacity",
                                   _cleanup_payload(payload),
                                   explicit_replay_once=explicit_replay_once))

    def runner_reservations(
        self, *, limit: int = 100, after: str = "", quarantine_after: str = "",
        batch_id: str | None = None,
    ) -> dict[str, Any]:
        """Read unknown reservations and migration scopes, each with its cursor."""
        if type(limit) is not int or not 1 <= limit <= 200:
            raise ValueError("limit must be an integer between 1 and 200")
        _wire_string(after, "after", 0, 64)
        _wire_string(quarantine_after, "quarantine_after", 0, 64)
        if batch_id is not None and normalize_batch_id(batch_id) != batch_id:
            raise ValueError("batch_id must be a normalized claim-batch UUID")
        params = {"limit": limit, "after": after, "quarantine_after": quarantine_after}
        if batch_id is not None:
            params["batch_id"] = batch_id
        return self._check(self._request(
            "GET", "/api/v1/runner/reservations",
            params=params,
            timeout=3.0, retry_rate_limit=False, retry_transport=False,
        ))

    def reconcile_legacy_runner_capacity(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Declare reviewed historical cleanup; never manufacture a clean baseline."""
        return self._post(
            "/api/v1/runner/reconcile-legacy", json=_cleanup_payload(payload, legacy=True),
            timeout=3.0, retry_rate_limit=False, retry_transport=False,
        )

    def flight_event_capabilities(self) -> dict[str, Any]:
        """Optional, bounded negotiation; callers tolerate old servers."""
        return self._check(self._request("GET", "/api/v1/runner/flight-event-capabilities",
                                         timeout=1.0, retry_rate_limit=False, retry_transport=False))

    def flight_events(self, events: list[dict[str, Any]]) -> dict[str, Any]:
        """Idempotently upload privacy-allowlisted lifecycle events."""
        import asyncio
        from .telemetry_recovery import replay
        return asyncio.run(replay(self, "/api/v1/runner/flight-events", {"events": events}))

    def auth_flight_events(self, events):
        """Optional diagnostics get one bounded attempt, never core retry policy."""
        return self._check(self._request('POST','/api/v1/runner/flight-events',json={'events':events},timeout=3.0,retry_rate_limit=False))

    def mark_stopped(
        self,
        assignment_id: str,
        *,
        defer_seconds: int = 300,
        session_id: str | None = None,
        owner_epoch: int | None = None,
        resume_generation: int | None = None,
        failure_kind: str | None = None,
        failure_diagnostic: dict[str, Any] | None = None,
        request_id: str | None = None,
    ) -> dict[str, Any]:
        """The counterpart of mark_started: this trial died client-side
        (build flake, agent crash, abandonment) with nothing uploaded, so the
        server should stop showing the cell as 解题中. Callers use bounded
        best-effort retries and surface a final failure; current servers also
        reopen session-bound work after its exact runner is stale. New clients
        fence this transition with owner_epoch."""
        data = {
            "assignment_id": assignment_id,
            "defer_seconds": str(defer_seconds),
            "session_id": session_id or "",
        }
        if owner_epoch is not None:
            data["owner_epoch"] = str(owner_epoch)
        if resume_generation is not None:
            data["resume_generation"] = str(resume_generation)
        if failure_kind:
            data["failure_kind"] = failure_kind
        if failure_diagnostic is not None:
            data["failure_diagnostic"] = json.dumps(
                failure_diagnostic, separators=(",", ":"), sort_keys=True,
            )
        import uuid
        from .stop_recovery import recover
        request_id = request_id or uuid.uuid4().hex
        if not re.fullmatch(r"[0-9a-f]{32}", request_id):
            raise ValueError("request_id must be 32 lowercase hex")
        data["request_id"] = request_id
        return recover(self, data)

    def report_runner_failure(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Send one allow-listed incident report; callers own durable retry."""
        return self._post("/api/v1/runner/failures", json=payload, timeout=3.0)

    def runner_failure_reports(self, limit: int = 20) -> dict[str, Any]:
        return self._get(f"/api/v1/runner/failures?limit={limit}")

    def submit(
        self,
        assignment_id: str,
        nonce: str,
        patch: Path,
        trajectory: Path | None,
        result: Path | None,
        client_meta: dict[str, Any],
        outcome: str = "completed",
        session_id: str | None = None,
        owner_epoch: int | None = None,
        resume_generation: int | None = None,
        trajectory_bundle: Path | None = None,
        upload_intent_id: str | None = None,
    ) -> dict[str, Any]:
        files: list[tuple[str, tuple[str, bytes]]] = [
            ("patch", ("model.patch", patch.read_bytes())),
        ]
        if trajectory and trajectory.exists():
            files.append(("trajectory", ("trajectory.json", trajectory.read_bytes())))
        if result and result.exists():
            files.append(("result", ("result.json", result.read_bytes())))
        if trajectory_bundle and trajectory_bundle.exists():
            files.append(("trajectory_bundle", (
                "trajectory_bundle.json", trajectory_bundle.read_bytes())))
        data = {
            "assignment_id": assignment_id,
            "nonce": nonce,
            "outcome": outcome,
            "client_meta": json.dumps(client_meta),
            "session_id": session_id or "",
        }
        if owner_epoch is not None:
            data["owner_epoch"] = str(owner_epoch)
        if resume_generation is not None:
            data["resume_generation"] = str(resume_generation)
        if upload_intent_id is not None:
            data["upload_intent_id"] = upload_intent_id
        return self._post_submission_write(
            "/api/v1/submissions",
            maintenance_key=upload_intent_id,
            data=data,
            files=files,
        )

    def register_submission_upload_intent(
        self,
        assignment_id: str,
        nonce: str,
        session_id: str,
        owner_epoch: int | None,
        upload_intent_id: str,
        *,
        resume_generation: int | None = None,
        intent_version: str = UPLOAD_INTENT_VERSION,
    ) -> str:
        """Precommit one exact payload before the potentially large POST."""
        data = {
            "assignment_id": assignment_id,
            "nonce": nonce,
            "session_id": session_id,
            "upload_intent_id": upload_intent_id,
            "intent_version": intent_version,
        }
        if owner_epoch is not None:
            data["owner_epoch"] = str(owner_epoch)
        if resume_generation is not None:
            data["resume_generation"] = str(resume_generation)
        self._post_submission_write(
            "/api/v1/submission-upload-intents",
            maintenance_key=upload_intent_id,
            retain_maintenance_deadline=True,
            data=data,
        )
        return upload_intent_id

    def rebind_submission_upload_salvage(
        self,
        assignment_id: str,
        nonce: str,
        source_session_id: str,
        source_owner_epoch: int,
        expected_owner_epoch: int,
        salvage_session_id: str,
    ) -> dict[str, Any]:
        """Explicitly bind one saved completed result to an upload-only owner.

        This endpoint never starts the model.  It only succeeds after the
        server proves the source runner owned this assignment and the current
        assignment has no live runner.
        """
        return self._post(
            "/api/v1/submission-upload-salvage/rebind",
            data={
                "assignment_id": assignment_id,
                "nonce": nonce,
                "source_session_id": source_session_id,
                "source_owner_epoch": str(source_owner_epoch),
                "expected_owner_epoch": str(expected_owner_epoch),
                "salvage_session_id": salvage_session_id,
            },
        )
