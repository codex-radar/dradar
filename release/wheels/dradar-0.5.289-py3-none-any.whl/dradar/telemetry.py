"""Low-bandwidth runner heartbeat lifecycle.

One session reports regardless of how many cells it holds.  Payloads contain
only lifecycle metadata; never task text, prompts, trajectories, patches,
commands, hostname, username, IP or hardware details.
"""

from __future__ import annotations

import random
import os
import sys
import threading
import time
import uuid
from pathlib import Path

from . import __version__
from .api_client import ApiClient, ApiError
from . import capacity_journal, cancellation
from .flight_recorder import FlightRecorder, _checked_lock


def platform_family() -> str:
    if sys.platform == "darwin":
        return "macos"
    if sys.platform.startswith("win"):
        return "windows"
    if sys.platform.startswith("linux"):
        if os.environ.get("WSL_DISTRO_NAME") or os.environ.get("WSL_INTEROP"):
            return "wsl"
        return "linux"
    return "other"


PREPARATION_HEARTBEAT_SEC = 30


class RunnerTelemetry:
    """A daemon heartbeat with a fast preparation cadence.

    Background telemetry is best effort and can never abort a running trial.
    The synchronous pre-checkout registration path is strict because checkout
    cannot safely bind a session the server rejected. Three consecutive
    background failures produce one warning; recovery produces one notice.
    """

    def __init__(
        self,
        client: ApiClient,
        *,
        jitter: bool = True,
        target_workers: int = 1,
        home: Path | None = None,
    ):
        if not 1 <= target_workers <= 40:
            raise ValueError("target_workers must be between 1 and 40")
        self.client = client
        self.target_workers = target_workers
        self.session_id = uuid.uuid4().hex
        self._lock = threading.Lock()
        self._send_lock = threading.Lock()
        self._registration_diagnostic_local = threading.local()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._phase = "preparing"
        self._active_assignment_id: str | None = None
        self._owner_epoch: int | None = None
        self._batch_id: str | None = None
        self._seq = 0
        # A successful heartbeat is the only server-verifiable registration
        # acknowledgement available to the local coordinator.  Keep this
        # separate from the generic sequence counter: an offline/legacy
        # server must never be mistaken for a registered worker.
        self._last_heartbeat_accepted = False
        self._last_flight_events_acked = 0
        self._progress_counter = 0
        # The first heartbeat is sent immediately by ``start``.  Keep the
        # fallback short while cloning/building/queuing so a stalled setup is
        # noticed quickly even when the server response is unavailable.
        self._interval = PREPARATION_HEARTBEAT_SEC
        self._failures = 0
        self._warned = False
        self._disabled = False
        self._jitter = jitter
        self._shown_notice_ids: set[str] = set()
        self._stop_requested = False
        self._session_started_recorded = False
        self.flight_recorder = FlightRecorder(home, client) if home is not None else None
        server = getattr(client, "server", None)
        self.capacity_journal = (
            capacity_journal.CapacityJournal(home, session_id=self.session_id, server=server)
            if home is not None and isinstance(server, str) and server else None
        )
        generation = getattr(client, "credential_generation", None)
        if self.capacity_journal is not None and generation is not None:
            # This exact credential already pins new session admission. Save
            # that authority before the first heartbeat or recovery receipt.
            self.capacity_journal.bind_generation(generation)

    @property
    def stop_requested(self) -> bool:
        return self._stop_requested

    @staticmethod
    def _publish_stop_marker() -> None:
        raw = os.environ.get("DRADAR_POOL_ABORT_FILE")
        if not raw:
            return
        path = Path(raw)
        temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}")
        try:
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            temporary.write_text(
                "drain:the server asked this device to stop", encoding="utf-8",
            )
            os.replace(temporary, path)
        except OSError:
            pass
        finally:
            temporary.unlink(missing_ok=True)

    def _show_notices(self, response: dict) -> None:
        """Print each bounded server notice at most once per runner process."""
        notices = response.get("notices")
        if not isinstance(notices, list):
            return
        for value in notices[:10]:
            if not isinstance(value, dict):
                continue
            notice_id = value.get("id")
            message = value.get("message")
            severity = value.get("severity", "info")
            if (
                not isinstance(notice_id, str)
                or not 1 <= len(notice_id) <= 100
                or not isinstance(message, str)
                or not 1 <= len(message) <= 1000
                or severity not in {"info", "warning", "critical"}
                or notice_id in self._shown_notice_ids
            ):
                continue
            self._shown_notice_ids.add(notice_id)
            clean = " ".join(message.splitlines())
            print(f"server notice [{severity}]: {clean}", file=sys.stderr)

    def start(self) -> None:
        if self._thread is not None:
            return
        self._thread = threading.Thread(
            target=self._loop, name="dradar-heartbeat", daemon=True)
        self._thread.start()

    def bind_batch(self, batch_id: str | None) -> None:
        if not batch_id:
            return
        if self.capacity_journal is not None:
            self.capacity_journal.bind(batch_id)
        with self._lock:
            changed = self._batch_id != batch_id
            self._batch_id = batch_id
            record_session_started = changed and not self._session_started_recorded
            if record_session_started:
                # Set the guard while holding the state lock so concurrent
                # heartbeat responses cannot enqueue this lifecycle event twice.
                self._session_started_recorded = True
            if changed:
                self._progress_counter += 1
        if record_session_started:
            # Every server flight event must carry a batch identity. Defer
            # session_started until this first bind so legacy heartbeats that
            # receive the batch from the server cannot enqueue batch_id=null.
            self.record_event(
                "session_started", component="cli",
                attributes={"target_workers": self.target_workers},
            )
        if changed:
            self._wake.set()

    def record_event(self, event_type: str, *, component: str, **kwargs) -> dict | None:
        if self.flight_recorder is None:
            return None
        with self._lock:
            batch_id = self._batch_id
        # ``session_started`` is accepted by the server only after a batch is
        # known. Drop accidental pre-bind calls instead of persisting a null
        # identity that can never be uploaded or reconciled.
        if event_type == "session_started" and not batch_id:
            return None
        kwargs.setdefault("batch_id", batch_id)
        kwargs.setdefault("session_id", self.session_id)
        return self.flight_recorder.try_record(event_type, component=component, **kwargs)

    def _flush_flight_events(
        self, *, required_event_id: str | None = None,
        diagnostic_out: dict[str, object] | None = None,
    ) -> int:
        """Flush only this runner's bound batch/session evidence.

        The recorder queue is shared across plans and processes.  Do not let a
        stale event from another token or device session enter this heartbeat's
        atomic upload.  A runner without a server-assigned batch has no safe
        flight-event scope yet, so its pending evidence remains local until a
        later bind.
        """
        recorder = self.flight_recorder
        if recorder is None:
            return 0
        with self._lock:
            batch_id = self._batch_id
            session_id = self.session_id
        if not batch_id:
            if diagnostic_out is not None:
                diagnostic_out["registration_result"] = "flight_no_scope"
            return 0
        return recorder.flush(
            batch_id=batch_id,
            session_id=session_id,
            required_event_id=required_event_id,
            diagnostic_out=diagnostic_out,
        )

    def set_phase(
        self,
        phase: str,
        assignment_id: str | None = None,
        owner_epoch: int | None = None,
    ) -> None:
        if phase not in {"preparing", "building", "queued", "running", "uploading", "paused"}:
            raise ValueError(f"unknown runner phase {phase!r}")
        if owner_epoch is not None and owner_epoch < 0:
            raise ValueError("owner_epoch must be non-negative")
        if assignment_id is None:
            owner_epoch = None
        with self._lock:
            previous_phase = self._phase
            changed = (
                self._phase, self._active_assignment_id, self._owner_epoch,
            ) != (phase, assignment_id, owner_epoch)
            self._phase = phase
            self._active_assignment_id = assignment_id
            self._owner_epoch = owner_epoch
            if changed:
                self._progress_counter += 1
        if changed:
            self.record_event(
                "phase_changed", component="heartbeat",
                assignment_id=assignment_id,
                attributes={"previous_phase": previous_phase, "phase": phase},
            )
            self._wake.set()

    def _payload(self, *, registration_check=None) -> dict:
        with _checked_lock(self._lock, registration_check):
            if self._stop.is_set():
                raise capacity_journal.CapacityEvidenceError("This runner is sealed; no new heartbeat can register it.")
            self._seq += 1
            return {
                "protocol_version": 3,
                "client_version": __version__,
                "session_id": self.session_id,
                "batch_id": self._batch_id,
                "seq": self._seq,
                "phase": self._phase,
                "active_assignment_id": self._active_assignment_id,
                "owner_epoch": self._owner_epoch,
                "client_monotonic_ms": int(time.monotonic() * 1000),
                "progress_counter": self._progress_counter,
                "platform": platform_family(),
                "target_workers": self.target_workers,
            }

    def _send_once(
        self,
        *,
        propagate_errors: bool = False,
        required_event_id: str | None = None,
        diagnostic_out: dict[str, object] | None = None,
    ) -> int:
        """Send once and return the server-selected next interval."""
        with self._send_lock:
            if getattr(self, "require_explicit_batch", False) and not self._batch_id:
                return self._interval
            rejected = getattr(self, "_registration_error", None)
            if rejected is not None:
                if propagate_errors:
                    raise rejected
                return self._interval
            if self._disabled:
                if diagnostic_out is not None:
                    diagnostic_out["registration_result"] = "heartbeat_disabled"
                return self._interval
            try:
                self.record_event("heartbeat_sent", component="heartbeat")
                payload = self._payload()
                if self.capacity_journal is not None and not self._last_heartbeat_accepted:
                    self.capacity_journal.record_registration_request(payload)
                response = self.client.runner_heartbeat(payload)
            except ApiError as exc:
                if exc.code in {"runner_session_capacity_reached", "runner_reservation_capacity_reached", "runner_registration_rejected"}:
                    self._registration_error = exc
                # Older servers have no endpoint. Silence and disable rather than
                # alarming users or producing a 404 every two minutes forever.
                if exc.status_code == 404:
                    self._disabled = True
                    with self._lock:
                        self._last_heartbeat_accepted = False
                    if diagnostic_out is not None:
                        diagnostic_out["registration_result"] = "heartbeat_disabled"
                    return self._interval
                if diagnostic_out is not None:
                    diagnostic_out["registration_result"] = (
                        "heartbeat_http_error" if type(exc.status_code) is int
                        else "heartbeat_transport_error"
                    )
                    if type(exc.status_code) is int and 100 <= exc.status_code <= 599:
                        diagnostic_out["ack_http_status"] = exc.status_code
                self._failures += 1
                self.record_event(
                    "heartbeat_failed", component="heartbeat",
                    reason_code="api_error",
                    attributes={"http_status": exc.status_code or 0},
                )
                if self._failures >= 3 and not self._warned:
                    print("warning: the server cannot see this runner's heartbeat; "
                          "work continues and your leases are not auto-released",
                          file=sys.stderr)
                    self._warned = True
                if propagate_errors:
                    raise
                return self._interval
            except Exception:
                if diagnostic_out is not None:
                    diagnostic_out["registration_result"] = "heartbeat_transport_error"
                self._failures += 1
                self.record_event(
                    "heartbeat_failed", component="heartbeat",
                    reason_code="transport_error",
                )
                if self._failures >= 3 and not self._warned:
                    print("warning: runner heartbeat is unavailable; work continues and "
                          "your leases are not auto-released", file=sys.stderr)
                    self._warned = True
                if propagate_errors:
                    raise
                return self._interval

            if self._warned:
                print("runner heartbeat recovered", file=sys.stderr)
            self._failures = 0
            self._warned = False
            with self._lock:
                self._last_heartbeat_accepted = response.get("accepted") is True
            if response.get("batch_id"):
                # Legacy/super-account heartbeat may be the first place the
                # server assigns a batch. Bind before flushing pending events.
                self.bind_batch(response["batch_id"])
            # Optional OTA snapshot stays in this authenticated session scope.
            # It is not a replay of pre-login download history.
            try:
                from .ota.discovery import runtime_observation
                from .local_config import HOME
                observation = runtime_observation(HOME)
                if observation != getattr(self, "_last_ota_observation", None):
                    self.record_event("update_observed", component="ota", attributes=observation)
                    self._last_ota_observation = observation
            except Exception:
                pass
            self.record_event("heartbeat_acknowledged", component="heartbeat")
            self._last_flight_events_acked = self._flush_flight_events(
                required_event_id=required_event_id,
                diagnostic_out=diagnostic_out,
            )
            if diagnostic_out is not None and not self._last_heartbeat_accepted:
                diagnostic_out["registration_result"] = "heartbeat_rejected"
            self._show_notices(response)
            if response.get("stop_requested") is True:
                self._stop_requested = True
                self._publish_stop_marker()
            requested = response.get("next_heartbeat_sec", self._interval)
            try:
                requested_interval = min(600, max(30, int(requested)))
                with self._lock:
                    phase = self._phase
                if phase in {"preparing", "building", "queued"}:
                    # Preparation has no model output to act as a liveness
                    # signal. Do not let an adaptive server interval stretch
                    # this phase beyond the operator-visible 30s cadence.
                    self._interval = PREPARATION_HEARTBEAT_SEC
                else:
                    self._interval = requested_interval
            except (TypeError, ValueError):
                pass
            return self._interval

    def flush(self) -> None:
        """Best-effort synchronous update while work is already recoverable."""
        self._send_once()

    def flush_for_checkout(self) -> bool:
        """Register synchronously or expose the error before session checkout.

        A 404 keeps the legacy compatibility path: old servers did not require
        session registration. Every other failure must stop checkout instead
        of converting the real heartbeat error into a misleading downstream
        ``runner session is not registered`` response.
        """
        self._send_once(propagate_errors=True)
        return self._stop_requested

    def flush_for_worker_registration(self, required_event_id: str | None = None) -> bool:
        """Perform a strict worker-registration handshake.

        ``subprocess.Popen`` only proves that the local Pier parent was
        created; it says nothing about the server seeing this exact worker.
        The caller sets ``active_assignment_id`` and ``phase=building`` first,
        then uses this synchronous heartbeat.  A 200 response with
        ``accepted=true`` plus an acknowledged ``worker_registered`` flight
        event is the protocol's registration acknowledgement.
        Legacy/disabled heartbeat endpoints fail closed and return ``False``;
        the caller must not charge the execution lease in that case.
        """
        diagnostic: dict[str, object] = {"session_id": self.session_id}
        if required_event_id is not None:
            diagnostic["worker_event_id"] = required_event_id
        self._registration_diagnostic_local.value = diagnostic
        if self._disabled:
            diagnostic["registration_result"] = "heartbeat_disabled"
            return False
        self._send_once(
            propagate_errors=True,
            required_event_id=required_event_id,
            diagnostic_out=diagnostic,
        )
        with self._lock:
            if not self._last_heartbeat_accepted:
                diagnostic.setdefault("registration_result", "heartbeat_rejected")
                return False
            if self.flight_recorder is None:
                diagnostic["registration_result"] = "recorder_missing"
                return required_event_id is None
            if required_event_id is not None:
                acknowledged = required_event_id in self.flight_recorder.last_acknowledged_event_ids
                if not acknowledged and diagnostic.get("registration_result") == "flight_target_acknowledged":
                    diagnostic["registration_result"] = "flight_ack_cache_missing"
                elif not acknowledged:
                    diagnostic.setdefault("registration_result", "flight_unknown")
                return acknowledged
            # A production recorder must always bind the exact lifecycle event;
            # an unspecified ID would silently downgrade to heartbeat-only.
            return False

    @property
    def worker_registration_diagnostic(self) -> dict[str, object]:
        """Only facts from this worker thread's latest strict handshake."""
        return dict(getattr(self._registration_diagnostic_local, "value", {}))

    def _loop(self) -> None:
        while not self._stop.is_set():
            interval = self._send_once()
            # Optional auth upload uses a separate recorder instance, so its
            # network wait never owns the core recorder's in-process lock.
            # File updates still share the existing cross-process file lock.
            if self.flight_recorder is not None and not self._stop.is_set():
                with self._lock:
                    auth_batch = self._batch_id
                if auth_batch:
                    try:
                        optional = FlightRecorder(self.flight_recorder.home, self.client)
                        optional.flush_auth(batch_id=auth_batch, session_id=self.session_id)
                    except Exception:
                        pass
            if self._jitter:
                interval *= random.uniform(0.9, 1.1)
            self._wake.wait(interval)
            self._wake.clear()

    @cancellation.scoped
    def close(self, reason: str) -> None:
        cancellation.protect_finalization()
        if reason not in {"completed", "paused", "interrupted", "error"}:
            raise ValueError(f"unknown close reason {reason!r}")
        self._stop.set()
        self._wake.set()
        with self._lock:
            self._seq += 1
            close_seq = self._seq
        # Seal local execution before waiting for a heartbeat/network lock.
        # Incomplete attempts stay reserved even when logical close succeeds.
        can_release = False
        if self.capacity_journal is not None:
            try:
                can_release = self.capacity_journal.seal(close_seq=close_seq, reason=reason)
            except (capacity_journal.CapacityEvidenceError, OSError):
                print("runner exit evidence needs review; capacity remains reserved", file=sys.stderr)
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        if not self._disabled:
            with self._lock:
                payload = {
                    "session_id": self.session_id,
                    "batch_id": self._batch_id,
                    "seq": close_seq,
                    "reason": reason,
                }
            with self._send_lock:
                try:
                    self.client.runner_close(payload)
                except Exception:
                    pass
        if can_release:
            try:
                capacity_journal.reconcile_file(self.capacity_journal.path, self.client)
            except (ApiError, capacity_journal.CapacityEvidenceError, OSError):
                print("runner capacity receipt is unresolved; saved evidence will be retried", file=sys.stderr)
        self.record_event(
            "session_closed", component="cli", reason_code=reason,
            assignment_id=self._active_assignment_id,
        )
        self._flush_flight_events()
        # Drain terminal optional evidence after core close, using the separate
        # bounded/no-retry sender. Failure never changes the task outcome.
        if self.flight_recorder is not None and self._batch_id:
            try:
                FlightRecorder(self.flight_recorder.home,self.client).flush_auth(batch_id=self._batch_id,session_id=self.session_id)
            except Exception:
                pass
