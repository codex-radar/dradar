"""Credential-isolated Pier adapter for the official Grok Build CLI.

This module deliberately supports only grok.com's OAuth subscription session.
It never accepts an xAI API key.  DRadar exposes this single file to Pier's
isolated Python environment through ``--agent-import-path``.
"""

from __future__ import annotations

import json
import math
import os
import shlex
import uuid
from pathlib import Path, PurePosixPath
from typing import Any

from pier.agents.installed.base import BaseInstalledAgent, with_prompt_template
from pier.environments.base import BaseEnvironment
from pier.models.agent.context import AgentContext
from pier.models.agent.install import AgentInstallSpec, InstallStep
from pier.models.agent.network import NetworkAllowlist
from pier.models.trajectories import Agent, FinalMetrics, Step, Trajectory
from pier.utils.trajectory_metrics import populate_context_from_final_metrics
try:
    from _dradar_pier_credential_delivery import inject_private_files
except ModuleNotFoundError as exc:
    if exc.name != "_dradar_pier_credential_delivery":
        raise
    from dradar.pier_credential_delivery import inject_private_files

try:
    from _dradar_worker_events import register_worker, verify_task_baseline
except ModuleNotFoundError:
    from dradar.worker_events import register_worker, verify_task_baseline

from _dradar_grok_recovery import (
    grok_provider_stream_is_retryable,
    pier_exit_code,
    run_with_grok_resume,
    validated_session_id,
)


GROK_CLI_VERSION = "1.0.40"
GROK_VERSION_PATTERN = GROK_CLI_VERSION.replace(".", r"\.")
# Must stay equal to dradar.providers.GROK_MODELS; this module runs inside
# Pier and cannot import the CLI package.
GROK_MODELS = frozenset({"grok-4.6", "grok-4.7"})
GROK_LINUX_SHA256 = {
    "x86_64": "92c997dfd109c0672d40d5ae6fbd15835d53ffaf12cf9ea124d22aaef3ff23fc",
    "aarch64": "a16d26cf06892ebb3eca9a702c65e031a053431ed4dde3b23bebc58a92b6117f",
}


def _grok_auth_command(command: str, user_home: str, auth_path: str) -> str:
    """Fix native auth at exec time, including ENV baked into task images."""
    return "bash -o pipefail -c " + shlex.quote(
        "unset GROK_HOME GROK_AUTH XAI_API_KEY GROK_CODE_XAI_API_KEY; "
        f"export HOME={shlex.quote(user_home)}; "
        f"export GROK_AUTH_PATH={shlex.quote(auth_path)}; " + command
    )


def _grok_model_preflight_command(remote_cli: str, model: str) -> str:
    """Return a fail-closed model probe that emits only a safe category."""

    if model not in GROK_MODELS:
        raise ValueError(f"unsupported Grok model {model!r}")

    catalog_pattern = (
        "(^|[^[:alnum:]_.-])" + model.replace(".", "[.]")
        + "($|[^[:alnum:]_.-])"
    )

    return (
        "umask 077; "
        f"models_output=$({shlex.quote(remote_cli)} models 2>&1); "
        "models_rc=$?; "
        "if [ \"$models_rc\" -ne 0 ]; then "
        "  models_lower=$(printf '%s' \"$models_output\" "
        "    | tr '[:upper:]' '[:lower:]'); "
        "  case \"$models_lower\" in "
        "    *'not authenticated'*|*'unauthorized'*|*'forbidden'*|"
        "*'authentication failed'*|*'token expired'*) "
        "      preflight_kind=auth ;; "
        "    *'settings fetch failed'*|*'connection error'*|"
        "*'connection refused'*|*'connection reset'*|*'timed out'*|"
        "*'network'*|*'dns'*|*'tls'*) preflight_kind=network ;; "
        "    *) preflight_kind=unknown ;; "
        "  esac; "
        "  printf 'DRADAR_GROK_PREFLIGHT_FAILURE=%s\\n' "
        "    \"$preflight_kind\"; "
        "  exit 78; "
        "fi; "
        # Do not pipe the Rust CLI directly into grep -q. grep exits on the
        # first match and some Grok releases then panic on EPIPE.
        "if ! printf '%s\\n' \"$models_output\" "
        f"  | grep -Eq {shlex.quote(catalog_pattern)}; then "
        "  printf 'DRADAR_GROK_PREFLIGHT_FAILURE=catalog\\n'; "
        "  exit 78; "
        "fi"
    )


def _grok_prompt_command(
    remote_cli: str, flags: list[str], instruction: str, stream: str,
    *, session_id: str | None = None, append: bool = False,
) -> str:
    """Build an option-safe Grok invocation for an arbitrary task prompt.

    ``--single`` is Grok's non-interactive mode.  Use its ``--option=value``
    form so the complete untrusted prompt is exactly one argv item and a
    leading dash can never be reinterpreted as another CLI option.
    """

    invocation = [remote_cli, *flags]
    if session_id is not None:
        invocation.append(f"--resume={session_id}")
    cli = " ".join(shlex.quote(part) for part in invocation)
    single = shlex.quote(f"--single={instruction}")
    tee = "tee -a" if append else "tee"
    return "bash -o pipefail -c " + shlex.quote(
        f"{cli} {single} 2>&1 </dev/null | {tee} {shlex.quote(stream)}"
    )


def _grok_usage_facts(events: list[dict], model: str) -> dict:
    """Cross-check Grok's official per-response and terminal token ledgers."""

    names = (
        "input_tokens", "cache_read_input_tokens",
        "cache_creation_input_tokens", "output_tokens",
    )
    terminals = [
        event for event in events
        if isinstance(event, dict)
        and event.get("type") == "result"
        and isinstance(event.get("usage"), dict)
    ]
    terminal = terminals[0] if len(terminals) == 1 else None
    usage = terminal.get("usage") if terminal is not None else None
    values = {
        name: usage.get(name)
        if (isinstance(usage, dict)
            and isinstance(usage.get(name), int)
            and not isinstance(usage.get(name), bool)
            and usage[name] >= 0)
        else None
        for name in names
    }
    valid = terminal is not None and all(value is not None for value in values.values())
    current = {
        name: int(value) if value is not None else 0
        for name, value in values.items()
    }
    response_totals = {name: 0 for name in names}
    response_count = 0
    token_usage_events = []
    response_ledger_valid = True
    seen_response_ids: set[str] = set()
    for event in events:
        if not isinstance(event, dict) or event.get("type") != "assistant":
            continue
        message = event.get("message")
        message_id = message.get("id") if isinstance(message, dict) else None
        if isinstance(message_id, str) and message_id:
            if message_id in seen_response_ids:
                continue
            seen_response_ids.add(message_id)
        response_usage = message.get("usage") if isinstance(message, dict) else None
        if not isinstance(response_usage, dict):
            valid = False
            response_ledger_valid = False
            continue
        response_count += 1
        response_values = {}
        for name in names:
            value = response_usage.get(name)
            if (not isinstance(value, int) or isinstance(value, bool) or value < 0):
                valid = False
                response_ledger_valid = False
                continue
            response_values[name] = value
            response_totals[name] += value
        if len(response_values) == len(names):
            token_usage_events.append({
                "n_input_tokens": (
                    response_values["input_tokens"]
                    + response_values["cache_read_input_tokens"]
                    + response_values["cache_creation_input_tokens"]
                ),
                "n_cache_tokens": response_values["cache_read_input_tokens"],
                "n_output_tokens": response_values["output_tokens"],
            })
    terminal_prompt = (
        current["input_tokens"] + current["cache_read_input_tokens"]
        + current["cache_creation_input_tokens"]
    )
    expected_total = terminal_prompt + current["output_tokens"]
    reported_total = usage.get("total_tokens") if isinstance(usage, dict) else None
    if (reported_total is not None
            and (not isinstance(reported_total, int)
                 or isinstance(reported_total, bool)
                 or reported_total != expected_total)):
        valid = False
    if terminal is not None and (
        terminal.get("usage_is_incomplete") is True
        or terminal.get("subtype") not in {"success", None}
    ):
        valid = False
    request_count = terminal.get("num_turns") if terminal is not None else None
    if (not isinstance(request_count, int) or isinstance(request_count, bool)
            or request_count < 1):
        valid = False
        request_count = 0
    if response_count != request_count or response_totals != current:
        valid = False
    complete = valid and expected_total > 0
    observed = (
        not complete
        and response_ledger_valid
        and bool(token_usage_events)
        and response_count == len(token_usage_events)
    )
    selected = current if complete else response_totals if observed else {
        name: 0 for name in names
    }
    prompt = (
        selected["input_tokens"] + selected["cache_read_input_tokens"]
        + selected["cache_creation_input_tokens"]
    )
    selected_request_count = request_count if complete else response_count if observed else 0
    reported_cost = None
    if terminal is not None and terminal.get("cost_is_partial") is not True:
        value = terminal.get("total_cost_usd")
        try:
            candidate = float(value)
        except (TypeError, ValueError):
            candidate = None
        if candidate is not None and math.isfinite(candidate) and candidate >= 0:
            reported_cost = candidate
    return {
        "schema": "dradar-subscription-provider-usage-v1",
        "provider": "grok",
        "model": model,
        "complete": complete,
        "request_count": selected_request_count,
        "n_input_tokens": prompt,
        "n_cache_tokens": selected["cache_read_input_tokens"],
        "n_output_tokens": selected["output_tokens"],
        "cache_creation_tokens": selected["cache_creation_input_tokens"],
        "subscription_reported_cost_usd": reported_cost,
        "subscription_reported_cost_basis": "official-grok-cli",
        # Grok's official stream exposes one usage object per response.  It
        # does not expose a trustworthy request timestamp, but Grok's API
        # tariff is context-banded rather than time-banded, so the complete
        # per-request token ledger is still sufficient for server repricing.
        "token_usage_events": token_usage_events if (complete or observed) else [],
        "request_usage_complete": complete,
        "request_usage_observed": complete or observed,
        "timed_usage_complete": False,
        "usage_incomplete_reason": (
            None if complete else
            "terminal_aggregate_missing_or_inconsistent" if observed else
            "request_ledger_unavailable_or_invalid"
        ),
        "usage_evidence_tier": (
            "complete_reconciled" if complete
            else "observed_unreconciled" if observed
            else "unavailable"
        ),
    }


def _download_command() -> str:
    """Resume only this installation's private file within one wall-clock budget."""
    return (
        'set -euo pipefail; grok_tmp=$1; grok_url=$2; grok_sha=$3; '
        'grok_attempt=1; '
        'while true; do '
        '  if curl --fail --silent --show-error --location --continue-at - '
        '      --connect-timeout 15 --max-time 120 '
        '      --output "${grok_tmp}" "${grok_url}"; then break; fi; '
        # A complete pinned file may already exist after a late disconnect or
        # an HTTP 416 response to a request beyond its last byte.
        '  if printf "%s  %s\\n" "${grok_sha}" "${grok_tmp}" '
        '      | sha256sum --check --strict --status -; then break; fi; '
        '  echo "Grok download attempt ${grok_attempt} failed; '
        'retained $(wc -c < "${grok_tmp}") bytes for resume" >&2; '
        '  if [ "${grok_attempt}" -ge 3 ]; then '
        "    echo 'Grok download failed: exhausted 3 attempts' >&2; exit 1; fi; "
        '  grok_attempt=$((grok_attempt + 1)); sleep 2; '
        'done'
    )


def _install_command() -> str:
    return (
        "set -euo pipefail; "
        "if [ -f /etc/alpine-release ] || ldd --version 2>&1 | grep -qi musl; then "
        "  echo 'Grok Build requires a glibc task image' >&2; exit 1; "
        "elif command -v apt-get >/dev/null 2>&1; then "
        "  apt-get update && DEBIAN_FRONTEND=noninteractive "
        "  apt-get install -y --no-install-recommends ca-certificates curl coreutils; "
        "elif command -v dnf >/dev/null 2>&1; then "
        "  dnf install -y ca-certificates curl coreutils; "
        "elif command -v yum >/dev/null 2>&1; then "
        "  yum install -y ca-certificates curl coreutils; "
        "else echo 'No supported package manager found' >&2; exit 1; fi; "
        'case "$(uname -m)" in '
        f"  x86_64) grok_arch=x86_64; grok_sha={GROK_LINUX_SHA256['x86_64']} ;; "
        f"  aarch64|arm64) grok_arch=aarch64; grok_sha={GROK_LINUX_SHA256['aarch64']} ;; "
        "  *) echo 'Unsupported CPU architecture' >&2; exit 1 ;; "
        "esac; "
        "mkdir -p /opt/grok-runtime/bin; "
        f"grok_url=https://storage.googleapis.com/grok-build-public-artifacts/cli/"
        f"grok-{GROK_CLI_VERSION}-linux-${{grok_arch}}; "
        # The watchdog includes retries, pauses and intermediate hash checks.
        # Keep it in its own process group and forward cancellation before
        # cleaning up: a retry must never recreate an already removed file.
        'grok_tmp=$(mktemp /opt/grok-runtime/bin/.grok.XXXXXXXX); '
        'grok_download_pid=; '
        'grok_stop_download() { '
        '  if [ -n "${grok_download_pid}" ]; then '
        '    kill -KILL -- "-${grok_download_pid}" 2>/dev/null || true; '
        '    kill -KILL "${grok_download_pid}" 2>/dev/null || true; '
        '    wait "${grok_download_pid}" 2>/dev/null || true; '
        # Cover cancellation before timeout has created its process group.
        '    kill -KILL -- "-${grok_download_pid}" 2>/dev/null || true; '
        '    grok_download_pid=; '
        '  fi; '
        '}; '
        "trap 'grok_stop_download; rm -f -- \"${grok_tmp}\"' EXIT; "
        # $! also covers a signal between spawning timeout and assigning pid.
        "trap 'grok_download_pid=${grok_download_pid:-${!:-}}; exit 1' HUP INT TERM; "
        "timeout --kill-after=5s 364s bash -c "
        + shlex.quote(_download_command())
        + ' -- "${grok_tmp}" "${grok_url}" "${grok_sha}" & '
        'grok_download_pid=$!; '
        'if wait "${grok_download_pid}"; then grok_stop_download; else '
        "  echo 'Grok download failed: attempts or 364s wall-clock budget exhausted' >&2; "
        '  exit 1; fi; '
        "trap 'exit 1' HUP INT TERM; "
        "printf '%s  %s\\n' \"${grok_sha}\" \"${grok_tmp}\" "
        "  | sha256sum --check --strict -; "
        'chmod 0755 "${grok_tmp}"; '
        'timeout --kill-after=5s 15s "${grok_tmp}" --version '
        f"  | grep -Eq '(^| ){GROK_VERSION_PATTERN}( |$)'; "
        'mv -fT -- "${grok_tmp}" /opt/grok-runtime/bin/grok'
    )


try:
    from _dradar_artifact_boundary import private_post_run
except ModuleNotFoundError:
    from dradar.artifact_boundary import private_post_run


class GrokBuild(BaseInstalledAgent):
    """Run the official Grok CLI headlessly with an isolated OAuth home."""

    SUPPORTS_ATIF = True
    # Grok resolves credentials from ``$HOME/.grok/auth.json``. Its
    # GROK_HOME setting controls selected configuration paths but is not the
    # credential-home override, so using it alone silently falls back to an
    # unauthenticated 4.5 catalog.
    _REMOTE_USER_HOME = PurePosixPath("/tmp/dradar-grok-user")
    _REMOTE_HOME = _REMOTE_USER_HOME / ".grok"
    _REMOTE_AUTH = _REMOTE_HOME / "auth.json"
    _REMOTE_CLI = PurePosixPath("/opt/grok-runtime/bin/grok")
    _STREAM_FILE = "grok-build.jsonl"
    _USAGE_FILE = "provider-usage.json"
    _TOOLS = "read_file,grep,list_dir,search_replace,run_terminal_cmd,todo_write"

    @staticmethod
    def name() -> str:
        return "grok-build"

    def __init__(
        self,
        *args: Any,
        auth_json_file: str,
        grok_cli_file: str,
        reasoning_effort: str,
        shared_oauth: bool = False,
        **kwargs: Any,
    ):
        auth = Path(auth_json_file)
        if not auth.is_file():
            raise ValueError("Grok OAuth run credential is missing")
        cli = Path(grok_cli_file)
        if not cli.is_file():
            raise ValueError("Verified host Grok CLI executable is missing")
        if reasoning_effort not in {"low", "medium", "high", "xhigh"}:
            raise ValueError(
                "Grok reasoning_effort must be low, medium, high, or xhigh"
            )
        if not isinstance(shared_oauth, bool):
            raise ValueError("Grok shared_oauth must be a boolean")
        self._auth_json_file = auth
        self._shared_oauth = shared_oauth
        self._reasoning_effort = reasoning_effort
        self._resume_attempts = 0
        self._session_id: str | None = None
        super().__init__(*args, **kwargs)

    def _model(self) -> str:
        # Unset only for legacy callers that predate multi-model Grok Build.
        model = self.model_name or "grok-4.6"
        if model not in GROK_MODELS:
            raise ValueError(f"unsupported Grok model {model!r}")
        return model

    def get_version_command(self) -> str:
        return f"{self._REMOTE_CLI.as_posix()} --version"

    def install_spec(self) -> AgentInstallSpec:
        version = self._version or GROK_CLI_VERSION
        return AgentInstallSpec(
            agent_name=self.name(),
            version=version,
            steps=[InstallStep(user="root", run=_install_command())],
            verification_command=(
                f"{self._REMOTE_CLI.as_posix()} --version "
                f"| grep -Eq '(^| ){GROK_VERSION_PATTERN}( |$)'"
            ),
            cache_key=f"dradar-grok-subscription-{version}-linux-runtime-v5",
        )

    def network_allowlist(self) -> NetworkAllowlist:
        # Runtime model traffic and silent OAuth refresh only.  Web search and
        # fetch are also removed at the CLI layer below.
        return NetworkAllowlist(
            domains=[
                "auth.x.ai",
                "cli-chat-proxy.grok.com",
                # Grok Build loads the subscription settings and
                # dynamic model catalog from the Code control plane before
                # opening the chat stream.  The proxy treats allowlist hosts
                # as exact names, so the apex entry does not cover this host.
                "code.grok.com",
                "grok.com",
            ]
        )

    @with_prompt_template
    async def run(
        self,
        instruction: str,
        environment: BaseEnvironment,
        context: AgentContext,
    ) -> None:
        await verify_task_baseline(environment)
        await register_worker(runtime="pier", context="agent", profile="grok")
        del context
        remote_user_home = self._REMOTE_USER_HOME.as_posix()
        remote_home = self._REMOTE_HOME.as_posix()
        remote_auth = self._REMOTE_AUTH.as_posix()
        remote_cli = self._REMOTE_CLI.as_posix()
        env = self.build_process_env({
            "HOME": remote_user_home,
            "GROK_AUTH_PATH": remote_auth,
            "GROK_TELEMETRY_ENABLED": "0",
            "GROK_TELEMETRY_MIXPANEL_ENABLED": "0",
            "GROK_TELEMETRY_TRACE_UPLOAD": "0",
        })
        # BaseInstalledAgent merges _extra_env after defaults. Pin these only
        # after the merge, then also enforce them inside every native command.
        env.update({"HOME": remote_user_home, "GROK_AUTH_PATH": remote_auth})
        env.pop("GROK_HOME", None)
        env.pop("GROK_AUTH", None)
        # API keys are intentionally unsupported, including accidental ambient
        # keys baked into a task image or injected by a caller.
        env.pop("XAI_API_KEY", None)
        env.pop("GROK_CODE_XAI_API_KEY", None)
        await self.exec_as_agent(
            environment,
            command=(
                f"mkdir -p {shlex.quote(remote_home)} "
                f"&& chmod 700 {shlex.quote(remote_home)}"
            ),
            env=env,
        )
        if not self._shared_oauth:
            await inject_private_files(self, environment, [(self._auth_json_file, remote_auth)])
        else:
            await self.exec_as_agent(
                environment,
                command=(
                    f"test -r {shlex.quote(remote_auth)} "
                    f"&& test -w {shlex.quote(remote_auth)}"
                ),
                env=env,
            )
        if environment.default_user is not None and not self._shared_oauth:
            await self.exec_as_root(
                environment,
                command=(
                    f"chown {shlex.quote(str(environment.default_user))} "
                    f"{shlex.quote(remote_auth)} "
                    f"&& chmod 600 {shlex.quote(remote_auth)}"
                ),
                env=env,
            )
        elif not self._shared_oauth:
            await self.exec_as_agent(
                environment,
                command=f"chmod 600 {shlex.quote(remote_auth)}",
                env=env,
            )
        version = self._version or GROK_CLI_VERSION
        version_pattern = version.replace(".", r"\.")
        await self.exec_as_agent(
            environment,
            command=_grok_auth_command(
                f"{shlex.quote(remote_cli)} --version "
                f"| grep -Eq '(^| ){version_pattern}( |$)'",
                remote_user_home, remote_auth,
            ),
            env=env,
        )
        # Grok discovers subscription models dynamically.  A fresh,
        # auth-only GROK_HOME otherwise retains the bundled 4.5 fallback and
        # rejects 4.6 before making a model request.  Populate the isolated
        # model cache and fail closed if this OAuth slot cannot see 4.6. Do
        # not expose raw provider diagnostics: emit one bounded category so
        # the outer run loop can defer this unspent assignment instead of
        # manufacturing a zero-token invalid submission.
        await self.exec_as_agent(
            environment,
            command=_grok_auth_command(
                _grok_model_preflight_command(remote_cli, self._model()),
                remote_user_home, remote_auth,
            ),
            env=env,
        )

        stream = f"/logs/agent/{self._STREAM_FILE}"
        model = self._model()
        # The path rules are defense in depth around the credential file.  The
        # Docker/Pier egress allowlist remains the primary data-exfiltration
        # boundary for untrusted benchmark instructions.
        flags = [
            "--model", model,
            "--reasoning-effort", self._reasoning_effort,
            "--output-format", "streaming-messages-json",
            "--always-approve",
            "--disable-web-search",
            "--no-subagents",
            "--no-memory",
            "--no-plan",
            "--tools", self._TOOLS,
            "--deny", f"Read({remote_home}/**)",
            "--deny", f"Grep({remote_home}/**)",
            "--deny", f"Edit({remote_home}/**)",
            "--deny", f"Write({remote_home}/**)",
            "--deny", "Bash(*auth.json*)",
            "--deny", "Bash(*.grok*)",
            "--deny", "Bash(*GROK_HOME*)",
            "--deny", f"Bash(*{remote_user_home}*)",
        ]
        async def remote_session_id() -> str | None:
            result = await self.exec_as_agent(
                environment,
                command=(
                    "sed -n 's/.*\"session_id\":\"\\([^\"]*\\)\".*/\\1/p' "
                    f"{shlex.quote(stream)} | head -n 1"
                ),
                env=env,
            )
            return validated_session_id(result.stdout)

        async def run_initial() -> None:
            await self.exec_as_agent(
                environment,
                command=_grok_auth_command(
                    _grok_prompt_command(remote_cli, flags, instruction, stream),
                    remote_user_home, remote_auth,
                ),
                env=env,
            )

        async def run_resume(session_id: str, prompt: str) -> None:
            await self.exec_as_agent(
                environment,
                command=_grok_auth_command(
                    _grok_prompt_command(remote_cli, flags, prompt, stream,
                        session_id=session_id, append=True),
                    remote_user_home, remote_auth,
                ),
                env=env,
            )

        async def classify_retryable_error(error: BaseException) -> bool:
            if pier_exit_code(error) != 1:
                return False
            try:
                result = await self.exec_as_agent(
                    environment,
                    command=f"tail -c 8192 {shlex.quote(stream)}",
                    env=env,
                )
            except Exception:
                return False
            return grok_provider_stream_is_retryable(result.stdout)

        def announce_retry(attempt: int, delay: float, session_id: str) -> None:
            self.logger.warning(
                "Grok temporary provider stream failure; resuming session %s "
                "in %ss (attempt %s/2)",
                session_id,
                int(delay),
                attempt,
            )

        try:
            self._resume_attempts, self._session_id = await run_with_grok_resume(
                run_initial=run_initial,
                find_session_id=remote_session_id,
                run_resume=run_resume,
                classify_retryable_error=classify_retryable_error,
                on_retry=announce_retry,
            )
        finally:
            # Silent refresh mutates auth.json.  Return that mutation to the
            # locked host run-copy even when the model command fails.
            if not self._shared_oauth:
                try:
                    await environment.download_file(remote_auth, self._auth_json_file)
                    if os.name != "nt":
                        os.chmod(self._auth_json_file, 0o600)
                except Exception as exc:
                    self.logger.warning(
                        "Could not recover refreshed Grok OAuth state: %s", exc
                    )

    @staticmethod
    def _content_text(content: Any) -> str:
        if isinstance(content, str):
            return content
        parts: list[str] = []
        if isinstance(content, list):
            for block in content:
                if isinstance(block, dict) and isinstance(block.get("text"), str):
                    parts.append(block["text"])
        return "\n\n".join(part for part in parts if part)

    @private_post_run
    def populate_context_post_run(self, context: AgentContext) -> None:
        """Create a conservative ATIF transcript from the Messages NDJSON.

        Subscription usage is not API billing, so cost deliberately remains
        unknown instead of being reported as zero dollars.
        """

        path = self.logs_dir / self._STREAM_FILE
        try:
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        except OSError:
            return
        steps: list[Step] = []
        session_id: str | None = None
        parsed_events = []
        seen_messages: set[str] = set()
        for line in lines:
            try:
                event = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(event, dict):
                continue
            parsed_events.append(event)
            session_id = event.get("session_id") or event.get("sessionId") or session_id
            message = event.get("message") if isinstance(event.get("message"), dict) else event
            message_id = message.get("id")
            if isinstance(message_id, str) and message_id:
                if message_id in seen_messages:
                    continue
                seen_messages.add(message_id)
            role = message.get("role")
            text = self._content_text(message.get("content"))
            if not text or role not in {"user", "assistant"}:
                continue
            steps.append(
                Step(
                    step_id=len(steps) + 1,
                    source="agent" if role == "assistant" else "user",
                    message=text,
                    model_name=(self.model_name if role == "assistant" else None),
                    reasoning_effort=(self._reasoning_effort if role == "assistant" else None),
                    llm_call_count=(1 if role == "assistant" else None),
                )
            )
        if not steps:
            return
        usage_facts = _grok_usage_facts(parsed_events, self._model())
        usage_facts["resume_attempts"] = self._resume_attempts
        input_tokens = usage_facts["n_input_tokens"] if usage_facts["complete"] else 0
        cached_tokens = usage_facts["n_cache_tokens"] if usage_facts["complete"] else 0
        output_tokens = usage_facts["n_output_tokens"] if usage_facts["complete"] else 0
        created_tokens = usage_facts["cache_creation_tokens"] if usage_facts["complete"] else 0
        try:
            (self.logs_dir / self._USAGE_FILE).write_text(
                json.dumps(usage_facts, ensure_ascii=False, separators=(",", ":")),
                encoding="utf-8",
            )
        except OSError:
            pass
        metrics = FinalMetrics(
            total_prompt_tokens=input_tokens or None,
            total_completion_tokens=output_tokens or None,
            total_cached_tokens=cached_tokens or None,
            total_cost_usd=None,
            total_steps=len(steps),
            extra={
                "billing_basis": "subscription",
                "cost_not_reported": True,
                "cache_creation_tokens": created_tokens,
            },
        )
        trajectory = Trajectory(
            schema_version="ATIF-v1.7",
            session_id=session_id or str(uuid.uuid4()),
            agent=Agent(
                name=self.name(),
                version=self._version or "unknown",
                model_name=self.model_name,
                extra={"provider": "xai-subscription", "oauth": True},
            ),
            steps=steps,
            final_metrics=metrics,
        )
        try:
            (self.logs_dir / "trajectory.json").write_text(
                json.dumps(trajectory.to_json_dict(), indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
        except OSError:
            return
        populate_context_from_final_metrics(context, metrics)


__all__ = ["GrokBuild"]
