"""Privacy-minimized, offline-capable lifecycle flight recorder.

The recorder intentionally accepts a small allowlist rather than trying to
redact arbitrary dictionaries after the fact.  It never records request
bodies, prompts, source code, commands, host/user names, credentials, proxy
configuration, or model output.
"""

from __future__ import annotations

import json
import os
import threading
import time
import uuid
import zipfile
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator


SCHEMA_VERSION = "dradar.flight_event.v1"
MAX_EVENT_BYTES = 4096
MAX_LOG_BYTES = 4 * 1024 * 1024
MAX_LOG_EVENTS = 5000
UPLOAD_BATCH_SIZE = 100
_LOCK_FILENAME = "recorder.lock"
_ACKNOWLEDGED_FILENAME = "acknowledged.jsonl"
_FLUSH_STATUS_FILENAME = "flush-status.json"
_FLUSH_STATUS_SCHEMA = "dradar.flight_flush_status.v1"
_FLUSH_FAILURE_REASONS = frozenset({
    "endpoint_unavailable", "http_error", "transport_error",
    "invalid_response", "unacknowledged_response", "local_storage_error",
})

# ``FlightRecorder`` is instantiated once by the fleet supervisor and once by
# every worker child.  A Python lock only coordinates threads in one process;
# keep a small in-process guard as well so Windows' byte-range locking does not
# trip over two handles opened by sibling objects in the same process.
_PROCESS_LOCK = threading.Lock()


@contextmanager
def _checked_lock(lock, check=None):
    """Registration alone polls a deadline; ordinary recorder calls are unchanged."""
    if check is None:
        with lock:
            yield
        return
    while True:
        check()
        if lock.acquire(blocking=False):
            break
        time.sleep(0.01)
    try:
        check()
        yield
    finally:
        lock.release()


@contextmanager
def _exclusive_file_lock(path: Path, *, check=None) -> Iterator[None]:
    """Serialize recorder read/modify/write cycles across processes.

    The lock is deliberately a separate, never-replaced file.  The JSONL files
    themselves are atomically replaced by :meth:`FlightRecorder._write`, so a
    reader from an older CLI still sees a complete old or new snapshot.  Both
    POSIX ``flock`` and Windows ``msvcrt`` are used without adding a runtime
    dependency; a crashed process releases either kernel lock automatically.
    """
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    locked = False
    windows_lock = False
    with _checked_lock(_PROCESS_LOCK, check):
        fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            if os.fstat(fd).st_size == 0:
                os.write(fd, b"\0")
            os.lseek(fd, 0, os.SEEK_SET)
            try:
                import fcntl

                while True:
                    if check is not None:
                        check()
                    try:
                        fcntl.flock(fd, fcntl.LOCK_EX | (fcntl.LOCK_NB if check else 0))
                        break
                    except BlockingIOError:
                        time.sleep(0.01)
            except ImportError:  # pragma: no cover - Windows CI
                import msvcrt

                while True:
                    if check is not None:
                        check()
                    try:
                        msvcrt.locking(fd, msvcrt.LK_NBLCK if check else msvcrt.LK_LOCK, 1)
                        break
                    except OSError:
                        if check is None:
                            raise
                        time.sleep(0.01)
                windows_lock = True
            locked = True
            yield
        finally:
            if locked:
                try:
                    if windows_lock:  # pragma: no cover - Windows CI
                        import msvcrt

                        os.lseek(fd, 0, os.SEEK_SET)
                        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl

                        fcntl.flock(fd, fcntl.LOCK_UN)
                except (ImportError, OSError):
                    pass
            os.close(fd)


EVENT_TYPES = frozenset({
    "auth_observed", "auth_observed_v2",
    "session_started", "session_closed", "phase_changed",
    "claim_requested", "claim_accepted", "claim_failed",
    "assignment_checked_out", "assignment_stopped",
    "build_started", "build_completed", "build_failed",
    "worker_registered",
    "provider_started", "provider_completed", "provider_failed",
    "heartbeat_sent", "heartbeat_acknowledged", "heartbeat_failed",
    "checkpoint_saved", "checkpoint_replayed", "checkpoint_failed",
    "release_requested", "release_completed", "release_failed",
    "upload_started", "upload_completed", "upload_failed",
    "request_started", "request_completed", "request_failed",
    "update_observed", "update_policy_rejected", "update_detected", "update_downloaded",
    "update_verified", "update_staged", "update_waiting_safe_point",
    "update_paused", "update_activated", "update_self_testing",
    "update_committed", "update_rollback_pending", "update_rolled_back",
    "update_failed",
    "supervisor_spawned", "child_ready", "precheckout_exit",
    "startup_failed", "probe_start", "probe_progress", "probe_timeout",
    "probe_ready",
})
COMPONENTS = frozenset({
    "cli", "claim", "build", "provider", "heartbeat", "checkpoint",
    "release", "upload", "api", "ota",
})
EVENT_KEYS = frozenset({
    "schema_version", "event_id", "client_id", "occurred_at", "seq",
    "event_type", "component", "actor", "batch_id", "session_id",
    "assignment_id", "request_id", "reason_code", "attributes",
})
ATTRIBUTE_KEYS = frozenset({
    "auth_stage", "auth_status", "auth_delivery",
    "execution_id", "owner_epoch", "auth_chain_tag", "auth_generation_tag", "auth_transaction_id", "auth_action", "auth_seq", "auth_events_emitted", "auth_events_dropped",
    "attempt", "elapsed_ms", "force", "http_status", "offline_replay",
    "outcome", "phase", "previous_phase", "provider", "release_count",
    "target_workers", "was_running", "worker_slot",
    "update_eligible", "update_sequence", "update_state", "update_enabled", "launch_method",
})
REASON_CODES = frozenset({
    "api_error", "transport_error", "completed", "paused", "interrupted",
    "error", "explicit_force", "explicit_safe", "user_force", "user",
    "build_flake", "codex_install_failed", "provider_failed", "submitted", "artifact-staging-failed",
    "upload-blocked", "upload-failed", "upload-unresolved", "pending_upload", "not-uploaded",
    "assignment-reopened", "expired", "rejected",
    "update_manifest_invalid", "update_policy_rejected",
    "update_download_failed", "update_verification_failed",
    "update_stage_failed", "update_safe_point_blocked",
    "update_self_test_failed", "update_crash_recovery", "candidate_failed",
    "update_state_corrupt", "update_state_incompatible",
    "precheckout-exit", "startup-timeout", "startup-failed",
    "worker-entrypoint-failed", "startup-dependency-missing",
    "startup-permission-denied", "startup-local-storage-error",
    "startup-network-unavailable", "startup-environment-not-ready",
    "startup-runtime-not-ready", "startup-state-changed",
    "startup-retry-cooldown",
    "startup-unknown", "startup-mixed",
    "runner_session_capacity_reached", "provider_capability_required",
})
OUTCOMES = frozenset({
    "completed", "interrupted", "submitted", "artifact-staging-failed",
    "upload-blocked", "upload-failed", "upload-unresolved", "not-uploaded",
    "assignment-reopened", "expired", "rejected",
})
PHASES = frozenset({
    "preparing", "building", "queued", "running", "uploading", "paused",
})
PROVIDERS = frozenset({
    "codex", "claude-code", "dsh-minimal", "grok-build", "kimi-code",
    "zcode", "antigravity", "codebuddy", "kiro",
})
UPDATE_STATES = frozenset({
    "detected", "downloaded", "verified", "staged", "waiting_safe_point",
    "paused", "activated", "self_testing", "committed",
    "rollback_pending", "rolled_back", "failed",
})
ATTRIBUTE_RULES = {
    "execution_id": (str, "hex32", None),
    "owner_epoch": (int, 0, 2_147_483_647),
    "auth_chain_tag": (str, "hex32", None),
    "auth_generation_tag": (str, "hex32", None),
    "auth_transaction_id": (str, "hex32", None),
    "auth_action": (str, {"start", "end", "ready", "waiting"}, None),
    "auth_seq": (int, 1, 2_147_483_647),
    "auth_events_emitted": (int, 0, 2_147_483_647),
    "auth_events_dropped": (int, 0, 2_147_483_647),

    "auth_stage": (str, {"selection", "refresh", "delivery", "adoption", "request", "recovery", "execution", "coverage"}, None),
    "auth_status": (str, {"unknown", "confirmed", "rejected", "waiting", "unsupported"}, None),
    "auth_delivery": (str, {"unknown", "file-copy", "shared-directory", "process-token", "host-at"}, None),
    "attempt": (int, 1, 100),
    "elapsed_ms": (int, 0, 2_147_483_647),
    "force": (bool, None, None),
    "http_status": (int, 0, 599),
    "offline_replay": (bool, None, None),
    "outcome": (str, OUTCOMES, None),
    "phase": (str, PHASES, None),
    "previous_phase": (str, PHASES, None),
    "provider": (str, PROVIDERS, None),
    "release_count": (int, 0, 40),
    "target_workers": (int, 1, 40),
    "was_running": (bool, None, None),
    "worker_slot": (int, 1, 40),
    "update_enabled": (bool, None, None),
    "launch_method": (str, {"launcher", "verified_child", "unknown"}, None),
    "update_eligible": (bool, None, None),
    "update_sequence": (int, 1, 2_147_483_647),
    "update_state": (str, UPDATE_STATES, None),
}


def _optional_id(value: Any, *, field: str) -> str | None:
    if value is None:
        return None
    if (
        not isinstance(value, str) or len(value) != 32
        or any(char not in "0123456789abcdef" for char in value)
    ):
        raise ValueError(f"{field} must be 32 lowercase hex characters")
    return value


def _safe_attributes(attributes: dict[str, Any] | None) -> dict[str, Any]:
    if attributes is None:
        values = {}
    elif isinstance(attributes, dict):
        values = dict(attributes)
    else:
        raise ValueError("flight-event attributes must be an object")
    unknown = set(values) - ATTRIBUTE_KEYS
    if unknown:
        raise ValueError(f"unsupported flight-event attributes: {sorted(unknown)}")
    safe: dict[str, Any] = {}
    for key, value in values.items():
        expected, allowed_or_min, maximum = ATTRIBUTE_RULES[key]
        if expected is bool:
            if type(value) is not bool:
                raise ValueError(f"flight-event attribute {key} must be boolean")
        elif expected is int:
            if type(value) is not int or not allowed_or_min <= value <= maximum:
                raise ValueError(f"flight-event attribute {key} is out of range")
        elif allowed_or_min == "hex32":
            _optional_id(value, field=key)
            if value is None:raise ValueError('missing observation id')
        elif type(value) is not str or value not in allowed_or_min:
            raise ValueError(f"flight-event attribute {key} is not an allowed value")
        safe[key] = value
    return safe


def validate_event(value: Any) -> dict[str, Any]:
    """Return one canonical event or reject it at every persistence boundary."""
    if not isinstance(value, dict) or set(value) != EVENT_KEYS:
        raise ValueError("flight event must contain exactly the versioned envelope")
    if value.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("unsupported flight event schema")
    for field in ("event_id", "client_id"):
        candidate = value.get(field)
        if (
            not isinstance(candidate, str) or len(candidate) != 32
            or any(char not in "0123456789abcdef" for char in candidate)
        ):
            raise ValueError(f"{field} must be 32 lowercase hex characters")
    occurred_at = value.get("occurred_at")
    if not isinstance(occurred_at, str):
        raise ValueError("occurred_at must be a timezone-aware ISO timestamp")
    try:
        parsed_at = datetime.fromisoformat(occurred_at)
    except ValueError as exc:
        raise ValueError("occurred_at must be a timezone-aware ISO timestamp") from exc
    if parsed_at.tzinfo is None:
        raise ValueError("occurred_at must include a timezone")
    seq = value.get("seq")
    if isinstance(seq, bool) or not isinstance(seq, int) or not 1 <= seq <= 2_147_483_647:
        raise ValueError("seq is out of range")
    if value.get("event_type") not in EVENT_TYPES:
        raise ValueError("unsupported flight event type")
    if value.get("component") not in COMPONENTS:
        raise ValueError("unsupported flight event component")
    if value.get("actor") != "cli":
        raise ValueError("client flight event actor must be cli")
    for field in ("batch_id", "session_id", "assignment_id", "request_id"):
        _optional_id(value.get(field), field=field)
    reason_code = value.get("reason_code")
    if reason_code is not None and reason_code not in REASON_CODES:
        raise ValueError("flight event reason_code is not an allowed value")
    attributes = _safe_attributes(value.get("attributes"))
    auth_keys = {key for key in attributes if key.startswith("auth_")}
    if value.get("event_type") in {"auth_observed","auth_observed_v2"}:
        if (not {"auth_stage", "auth_status", "provider"} <= set(attributes)
                or value.get("component") != "provider"):
            raise ValueError("authentication evidence requires fixed metadata")
    elif auth_keys:
        raise ValueError("authentication metadata requires its optional event")
    v2_keys={"execution_id","owner_epoch","auth_chain_tag","auth_generation_tag","auth_transaction_id","auth_action","auth_seq","auth_events_emitted","auth_events_dropped"}
    if value.get('event_type')=='auth_observed_v2':
        if not {'execution_id','owner_epoch','attempt','auth_seq'}<=set(attributes):raise ValueError('missing v2 identity')
    elif set(attributes)&v2_keys:raise ValueError('v2 metadata requires negotiated v2 event')
    canonical = dict(value)
    canonical["attributes"] = attributes
    if len(json.dumps(canonical, separators=(",", ":")).encode("utf-8")) > MAX_EVENT_BYTES:
        raise ValueError("flight event exceeds the local size limit")
    return canonical


class FlightRecorder:
    """Append a bounded local history and replay an independent pending queue."""

    def __init__(self, home: Path, client=None):
        self.home = Path(home)
        self.client = client
        self.root = self.home / "flight-recorder"
        self.events_path = self.root / "events.jsonl"
        self.pending_path = self.root / "pending.jsonl"
        self.retry_reservations_path = self.root / "retry-reservations.json"
        self.client_id_path = self.root / "client_id"
        self.lock_path = self.root / _LOCK_FILENAME
        self.acknowledged_path = self.root / _ACKNOWLEDGED_FILENAME
        self.flush_status_path = self.root / _FLUSH_STATUS_FILENAME
        self._lock = threading.Lock()
        self._seq = 0
        self._remote_disabled = False
        self._last_acknowledged_event_ids: set[str] = set()
        self.client_id = self._load_client_id()

    def _load_client_id(self) -> str:
        # Re-read after taking the inter-process lock.  Without this, two
        # freshly-started fleet children can each mint a client ID and the last
        # atomic replace wins on disk while the other process keeps a different
        # in-memory identity.
        try:
            with _exclusive_file_lock(self.lock_path):
                return self._load_or_create_client_id()
        except OSError:
            # Diagnostics and best-effort telemetry must still work on a
            # read-only/misconfigured home.  There is no durable cross-process
            # guarantee in this fallback, but callers already treat the local
            # recorder as optional in that environment.
            return self._load_or_create_client_id()

    def _load_or_create_client_id(self) -> str:
        try:
            value = self.client_id_path.read_text(encoding="ascii").strip()
            if len(value) == 32 and all(c in "0123456789abcdef" for c in value):
                return value
        except OSError:
            pass
        value = uuid.uuid4().hex
        try:
            self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
            temporary = self.client_id_path.with_name(
                f".{self.client_id_path.name}.{os.getpid()}.{time.time_ns()}"
            )
            temporary.write_text(value, encoding="ascii")
            os.chmod(temporary, 0o600)
            os.replace(temporary, self.client_id_path)
        except OSError:
            pass
        return value

    @staticmethod
    def _load(path: Path) -> list[dict[str, Any]]:
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except OSError:
            return []
        events = []
        for line in lines[-MAX_LOG_EVENTS:]:
            try:
                value = json.loads(line)
            except (TypeError, json.JSONDecodeError):
                continue
            try:
                events.append(validate_event(value))
            except ValueError:
                continue
        return events

    @staticmethod
    def _write(path: Path, events: list[dict[str, Any]]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        checked = [validate_event(event) for event in events]
        auth_indices = [i for i, event in enumerate(checked) if (event["event_type"] in {"auth_observed","auth_observed_v2"} or event["event_type"].startswith("update_"))]
        drop = set(auth_indices[:-100])
        checked = [event for i, event in enumerate(checked) if i not in drop]
        encoded = [json.dumps(event, sort_keys=True, separators=(",", ":")) for event in checked]
        while encoded and (
            len(encoded) > MAX_LOG_EVENTS
            or sum(len(line.encode("utf-8")) + 1 for line in encoded) > MAX_LOG_BYTES
        ):
            optional = next((i for i, event in enumerate(checked)
                             if (event["event_type"] in {"auth_observed","auth_observed_v2"} or event["event_type"].startswith("update_"))), None)
            if optional is not None:
                del encoded[optional]
                del checked[optional]
            else:
                count = max(1, len(encoded) // 4)
                del encoded[:count]
                del checked[:count]
        temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}")
        temporary.write_text("".join(line + "\n" for line in encoded), encoding="utf-8")
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)

    @staticmethod
    def _valid_event_id(value: Any) -> bool:
        return (
            isinstance(value, str)
            and len(value) == 32
            and all(char in "0123456789abcdef" for char in value)
        )

    def _reserve_event_recovery_unlocked(self, pending, events):
        """Give each pending identity one bounded sender, across processes.

        The caller holds the recorder file lock. Reserve the entire helper's
        attempt allowance before network I/O: a crash may leave unused
        attempts, but cannot give another automatic flush a fresh allowance.
        The event itself stays in pending until its exact receipt is saved.
        """
        from .acquisition_recovery import _save
        try:
            saved = json.loads(self.retry_reservations_path.read_text())
        except FileNotFoundError:
            saved = {"schema_version": 1, "event_ids": []}
        except (ValueError, TypeError) as exc:
            raise OSError("flight retry budget is unreadable") from exc
        if (not isinstance(saved, dict) or saved.get("schema_version") != 1
                or not isinstance(saved.get("event_ids"), list)
                or not all(self._valid_event_id(value) for value in saved["event_ids"])):
            raise OSError("flight retry budget is invalid")
        pending_ids = {event["event_id"] for event in pending}
        reserved = set(saved["event_ids"]) & pending_ids
        selected = [event for event in events if event["event_id"] not in reserved]
        reserved.update(event["event_id"] for event in selected)
        _save(self.retry_reservations_path,
              {"schema_version": 1, "event_ids": sorted(reserved)})
        return selected

    def _load_acknowledged_ids_unlocked(self) -> list[str]:
        try:
            lines = self.acknowledged_path.read_text(encoding="ascii").splitlines()
        except OSError:
            return []
        values: list[str] = []
        seen: set[str] = set()
        for value in lines[-MAX_LOG_EVENTS:]:
            if self._valid_event_id(value) and value not in seen:
                values.append(value)
                seen.add(value)
        return values

    def _write_acknowledged_ids_unlocked(self, event_ids: set[str]) -> None:
        """Persist a bounded shared receipt set under the recorder lock."""
        if not event_ids:
            return
        values = self._load_acknowledged_ids_unlocked()
        seen = set(values)
        for event_id in event_ids:
            if self._valid_event_id(event_id) and event_id not in seen:
                values.append(event_id)
                seen.add(event_id)
        values = values[-MAX_LOG_EVENTS:]
        self.acknowledged_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        temporary = self.acknowledged_path.with_name(
            f".{self.acknowledged_path.name}.{os.getpid()}.{time.time_ns()}"
        )
        temporary.write_text("".join(value + "\n" for value in values), encoding="ascii")
        os.chmod(temporary, 0o600)
        os.replace(temporary, self.acknowledged_path)

    def _load_flush_status_unlocked(self) -> dict[str, Any] | None:
        try:
            value = json.loads(self.flush_status_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        total = value.get("total_failures") if isinstance(value, dict) else None
        consecutive = (
            value.get("consecutive_failures") if isinstance(value, dict) else None
        )
        pending_count = (
            value.get("last_pending_count") if isinstance(value, dict) else None
        )
        http_status = value.get("last_http_status") if isinstance(value, dict) else None

        def safe_timestamp(field: str, *, optional: bool = False) -> str | None:
            candidate = value.get(field)
            if optional and candidate is None:
                return None
            if not isinstance(candidate, str):
                raise ValueError("invalid flight flush timestamp")
            parsed = datetime.fromisoformat(candidate)
            if parsed.tzinfo is None:
                raise ValueError("flight flush timestamp requires timezone")
            return candidate

        if (
            not isinstance(value, dict)
            or value.get("schema_version") != _FLUSH_STATUS_SCHEMA
            or type(total) is not int or not 0 <= total <= 2_147_483_647
            or type(consecutive) is not int or not 0 <= consecutive <= total
            or type(pending_count) is not int
            or not 0 <= pending_count <= MAX_LOG_EVENTS
            or not (
                http_status is None
                or type(http_status) is int and 100 <= http_status <= 599
            )
            or value.get("last_reason") not in _FLUSH_FAILURE_REASONS
        ):
            return None
        try:
            last_failure_at = safe_timestamp("last_failure_at")
            last_success_at = safe_timestamp("last_success_at", optional=True)
        except ValueError:
            return None
        # Reconstruct the strict allowlist. A locally tampered status file
        # must not smuggle arbitrary keys or strings into a diagnostic bundle.
        return {
            "schema_version": _FLUSH_STATUS_SCHEMA,
            "total_failures": total,
            "consecutive_failures": consecutive,
            "last_failure_at": last_failure_at,
            "last_reason": value["last_reason"],
            "last_http_status": http_status,
            "last_pending_count": pending_count,
            "last_success_at": last_success_at,
        }

    def _write_flush_status_unlocked(self, value: dict[str, Any]) -> None:
        self.flush_status_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        temporary = self.flush_status_path.with_name(
            f".{self.flush_status_path.name}.{os.getpid()}.{time.time_ns()}"
        )
        temporary.write_text(
            json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n",
            encoding="utf-8",
        )
        os.chmod(temporary, 0o600)
        os.replace(temporary, self.flush_status_path)

    def _record_flush_failure(
        self, reason: str, pending_count: int, *, http_status: int | None = None,
    ) -> None:
        """Persist a bounded, content-free reason for an upload evidence gap."""
        if reason not in _FLUSH_FAILURE_REASONS:
            return
        try:
            # flush() already owns the per-instance lock; take only the
            # cross-process lock here to avoid recursively acquiring a plain
            # threading.Lock while still serializing sibling recorder objects.
            with _exclusive_file_lock(self.lock_path):
                previous = self._load_flush_status_unlocked() or {}
                value = {
                    "schema_version": _FLUSH_STATUS_SCHEMA,
                    "total_failures": min(
                        int(previous.get("total_failures") or 0) + 1,
                        2_147_483_647,
                    ),
                    "consecutive_failures": min(
                        int(previous.get("consecutive_failures") or 0) + 1,
                        2_147_483_647,
                    ),
                    "last_failure_at": datetime.now(timezone.utc).isoformat(),
                    "last_reason": reason,
                    "last_http_status": (
                        http_status
                        if type(http_status) is int and 100 <= http_status <= 599
                        else None
                    ),
                    "last_pending_count": max(
                        0, min(int(pending_count), MAX_LOG_EVENTS),
                    ),
                    "last_success_at": previous.get("last_success_at"),
                }
                self._write_flush_status_unlocked(value)
        except (OSError, TypeError, ValueError):
            # The recorder remains best effort. A read-only home cannot safely
            # host either the pending queue or its failure status.
            pass

    def _record_flush_success(self) -> None:
        """Mark recovery only when a prior failure status already exists."""
        try:
            with _exclusive_file_lock(self.lock_path):
                value = self._load_flush_status_unlocked()
                if value is None:
                    return
                value["consecutive_failures"] = 0
                value["last_success_at"] = datetime.now(timezone.utc).isoformat()
                self._write_flush_status_unlocked(value)
        except OSError:
            pass

    def record(
        self,
        event_type: str,
        *,
        component: str,
        batch_id: str | None = None,
        session_id: str | None = None,
        assignment_id: str | None = None,
        request_id: str | None = None,
        reason_code: str | None = None,
        attributes: dict[str, Any] | None = None,
        occurred_at: str | None = None,
        _registration_check=None,
    ) -> dict[str, Any]:
        with _checked_lock(self._lock, _registration_check):
            with _exclusive_file_lock(self.lock_path, check=_registration_check):
                self._seq += 1
                event = {
                    "schema_version": SCHEMA_VERSION,
                    "event_id": uuid.uuid4().hex,
                    "client_id": self.client_id,
                    "occurred_at": occurred_at or datetime.now(timezone.utc).isoformat(),
                    "seq": self._seq,
                    "event_type": event_type,
                    "component": component,
                    "actor": "cli",
                    "batch_id": batch_id,
                    "session_id": session_id,
                    "assignment_id": assignment_id,
                    "request_id": request_id,
                    "reason_code": reason_code,
                    "attributes": attributes or {},
                }
                event = validate_event(event)
                history = self._load(self.events_path)
                pending = self._load(self.pending_path)
                self._write(self.events_path, [*history, event])
                self._write(self.pending_path, [*pending, event])
                if _registration_check is not None:
                    _registration_check()
                return event

    def try_record(self, event_type: str, **kwargs) -> dict[str, Any] | None:
        """Record best-effort evidence without affecting the primary workflow.

        ``record`` remains the strict persistence boundary used by tests and
        diagnostic tooling. Runtime integrations use this wrapper so a legacy
        or malformed identifier, or an unavailable local disk, drops only the
        diagnostic event instead of interrupting a claim, run, or release.
        """
        try:
            return self.record(event_type, **kwargs)
        except (OSError, ValueError):
            return None

    def flush_auth(self, *, batch_id=None, session_id=None):
        """Each optional schema is negotiated and flushed independently of core."""
        if self.client is None:return 0
        total=0
        try:
            with self._lock:
                with _exclusive_file_lock(self.lock_path):
                    present={event['event_type'] for event in self._load(self.pending_path)
                             if (batch_id is None or event.get('batch_id')==batch_id)
                             and (session_id is None or event.get('session_id')==session_id)}
            if not present & {'auth_observed','auth_observed_v2'} and not any(x.startswith('update_') for x in present):return 0
            caps=self.client.flight_event_capabilities()
            if not isinstance(caps,dict) or caps.get('schema_version')!=SCHEMA_VERSION:return 0
            for version,name in ((1,'auth_observed_v1'),(2,'auth_observed_v2')):
                event_type='auth_observed' if version==1 else 'auth_observed_v2'
                if event_type in present and caps.get(name) is True:
                    total+=self.flush(batch_id=batch_id,session_id=session_id,_auth_only=True,_auth_version=version)
            if caps.get("ota_update_v1") is True:
                total+=self.flush(batch_id=batch_id,session_id=session_id,_auth_only=True,_auth_version=3)
        except Exception:return total
        return total

    def flush(
        self,
        *,
        batch_id: str | None = None,
        session_id: str | None = None,
        required_event_id: str | None = None,
        diagnostic_out: dict[str, object] | None = None,
        _auth_only: bool = False,
        _auth_version: int = 1,
    ) -> int:
        """Upload pending events, optionally restricted to one lifecycle scope.

        ``pending.jsonl`` is intentionally shared by the CLI's lightweight
        recorder instances.  A run-plan token can therefore leave events from
        another plan, account, or device session in the same file.  The
        server's flight-event endpoint validates the whole request atomically;
        sending that mixed prefix would make an otherwise valid
        ``worker_registered`` event unacknowledgeable.  Callers that know the
        active scope should provide its batch and session IDs.  ``None`` keeps
        the historical unscoped replay behavior for diagnostics and legacy
        integrations.

        ``required_event_id`` is used by the synchronous worker-registration
        handshake.  When present, the matching event is moved to the front of
        the selected scope so an unrelated backlog cannot hide the receipt
        behind the 100-event upload limit.  It is never selected when it falls
        outside the requested scope.
        """
        def note(result: str, status: object = None) -> None:
            if diagnostic_out is not None:
                diagnostic_out["registration_result"] = result
                if type(status) is int and 100 <= status <= 599:
                    diagnostic_out["ack_http_status"] = status

        if self.client is None:
            note("flight_no_client")
            return 0
        if self._remote_disabled:
            note("flight_remote_disabled")
            return 0
        # A session-only (or required-event-only) scope cannot prove the plan
        # or account boundary.  In particular, never replay a legacy
        # ``batch_id=null`` event under a newly authenticated session; retain
        # it for explicit diagnostics or a future, manually selected replay.
        if batch_id is None and (
            session_id is not None or required_event_id is not None
        ):
            note("flight_no_scope")
            return 0
        record_failure = (lambda *args, **kwargs: None) if _auth_only else self._record_flush_failure
        with self._lock:
            try:
                with _exclusive_file_lock(self.lock_path):
                    pending = self._load(self.pending_path)
                    if not pending:
                        note("flight_no_pending")
                        return 0
                    scoped = [
                        event for event in pending
                        if (batch_id is None or event.get("batch_id") == batch_id)
                        and (session_id is None or event.get("session_id") == session_id)
                    ]
                    scoped = [event for event in scoped
                              if ((event.get("event_type") == "update_observed" if _auth_version==3 else event.get("event_type") == ("auth_observed_v2" if _auth_version==2 else "auth_observed")) if _auth_only else (event.get("event_type") not in {"auth_observed","auth_observed_v2"} and not event.get("event_type", "").startswith("update_")))]
                    if not scoped:
                        note("flight_target_not_pending")
                        return 0
                    if not _auth_only:
                        from .telemetry_recovery import eligible_events, retain_pending_event_budgets
                        retain_pending_event_budgets(self.client, pending)
                        scoped = eligible_events(self.client, scoped)
                        if not scoped:
                            note("flight_retry_exhausted")
                            return 0
                    if required_event_id is not None:
                        required = next(
                            (
                                event for event in scoped
                                if event.get("event_id") == required_event_id
                            ),
                            None,
                        )
                        if required is not None:
                            scoped = [
                                required,
                                *(
                                    event for event in scoped
                                    if event.get("event_id") != required_event_id
                                ),
                            ]
                    batch = [
                        validate_event(event) for event in scoped[:UPLOAD_BATCH_SIZE]
                    ]
                    if not _auth_only:
                        batch = self._reserve_event_recovery_unlocked(pending, batch)
                        if not batch:
                            note("flight_retry_exhausted")
                            return 0
            except OSError:
                # Flight evidence is best effort.  A locked/read-only home
                # must never turn a heartbeat into a worker crash; strict
                # worker registration will fail closed when no receipt exists.
                record_failure("local_storage_error", 0)
                note("flight_local_read_error")
                return 0
            try:
                sender=getattr(self.client,"auth_flight_events",self.client.flight_events) if _auth_only else self.client.flight_events
                response = sender(batch)
            except Exception as exc:
                status = getattr(exc, "status_code", None)
                reason = (
                    "endpoint_unavailable" if status == 404 else
                    "http_error" if type(status) is int else
                    "transport_error"
                )
                record_failure(
                    reason, len(pending), http_status=status,
                )
                note(
                    "flight_http_error" if type(status) is int else "flight_transport_error",
                    status,
                )
                if status == 404 and not _auth_only:
                    self._remote_disabled = True
                return 0
            sent_ids = {event["event_id"] for event in batch}
            try:
                raw_acknowledged = response.get("acknowledged_event_ids")
                # The server contract is a JSON array.  Treat every other
                # shape (including a dict whose keys happen to be event IDs,
                # a string, or a custom iterable) as malformed evidence; a
                # malformed response must never delete durable pending data or
                # satisfy the strict worker-registration handshake.
                if not isinstance(raw_acknowledged, list):
                    record_failure("invalid_response", len(pending))
                    note("flight_invalid_response")
                    return 0
                if any(
                    not self._valid_event_id(event_id)
                    for event_id in raw_acknowledged
                ):
                    record_failure("invalid_response", len(pending))
                    note("flight_invalid_response")
                    return 0
                acknowledged = {
                    event_id for event_id in raw_acknowledged
                    if event_id in sent_ids
                }
            except (AttributeError, TypeError):
                # A malformed response is not evidence of acceptance.  Keep
                # the durable pending event and let a later retry reconcile it.
                record_failure("invalid_response", len(pending))
                note("flight_invalid_response")
                return 0
            if not acknowledged:
                record_failure(
                    "unacknowledged_response", len(pending),
                )
                note("flight_target_not_acknowledged")
                return 0
            if required_event_id is not None and required_event_id not in acknowledged:
                note("flight_target_not_acknowledged")
            try:
                with _exclusive_file_lock(self.lock_path):
                    # Another process may have recorded or flushed events while
                    # the request was in flight.  Re-read before removing only
                    # the IDs this response actually acknowledged.
                    current_pending = self._load(self.pending_path)
                    self._write_acknowledged_ids_unlocked(acknowledged)
                    self._write(
                        self.pending_path,
                        [
                            event for event in current_pending
                            if event.get("event_id") not in acknowledged
                        ],
                    )
            except OSError:
                record_failure(
                    "local_storage_error", len(pending),
                )
                note("flight_ack_persist_error")
                return 0
            # Keep the local cache for callers that inspect this recorder, and
            # also persist receipts so a sibling process can prove that its
            # exact worker_registered event was accepted.
            self._last_acknowledged_event_ids.update(acknowledged)
            if required_event_id is None or required_event_id in acknowledged:
                note("flight_target_acknowledged")
            if not _auth_only:
                self._record_flush_success()
            return len(acknowledged)

    @property
    def last_acknowledged_event_ids(self) -> frozenset[str]:
        with self._lock:
            try:
                with _exclusive_file_lock(self.lock_path):
                    shared = self._load_acknowledged_ids_unlocked()
            except OSError:
                shared = []
            return frozenset((*self._last_acknowledged_event_ids, *shared))

    def export_diagnostic_bundle(self, destination: Path) -> Path:
        """Create a local-only ZIP containing allowlisted events and a manifest."""
        destination = Path(destination).expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        with self._lock:
            try:
                with _exclusive_file_lock(self.lock_path):
                    events = self._load(self.events_path)
                    pending = self._load(self.pending_path)
                    flush_status = self._load_flush_status_unlocked()
                    events = [validate_event(event) for event in events]
                    pending = [validate_event(event) for event in pending]
            except OSError:
                events = []
                pending = []
                flush_status = None
        manifest = {
            "schema_version": "dradar.flight_diagnostics.v1",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "event_count": len(events),
            "pending_count": len(pending),
            "flush_status": flush_status,
            "privacy_policy": "strict_allowlist_no_content_or_credentials",
        }
        with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
            bundle.writestr(
                "manifest.json", json.dumps(manifest, sort_keys=True, indent=2) + "\n"
            )
            bundle.writestr(
                "events.jsonl",
                "".join(
                    json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n"
                    for event in events
                ),
            )
        return destination


def cmd_diagnostics(args) -> int:
    from .local_config import HOME

    output = FlightRecorder(HOME).export_diagnostic_bundle(Path(args.output))
    print(f"diagnostic bundle written: {output}")
    return 0
