"""Standalone stdlib execution-image binding; no client package or model calls."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile

SCHEMA='dradar.execution-environment/1'
MAP_SCHEMA='dradar.execution-environment-map/1'
EVIDENCE_ROOT=Path('/dradar-evidence')

def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)

def strict_json(raw):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError('Duplicate JSON key')
            result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))

def read(path,limit=4*1024*1024):
    path=Path(path).absolute()
    if '..' in path.parts:raise ValueError('Read path traversal')
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    with os.fdopen(fd,'rb') as stream:
        before=os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or before.st_size>limit:
            raise ValueError('Bounded original regular file required')
        raw=stream.read(limit+1);after=os.fstat(stream.fileno());current=os.lstat(path)
    fields=('st_dev','st_ino','st_mode','st_nlink','st_size','st_mtime_ns','st_ctime_ns')
    if len(raw)!=before.st_size or any(getattr(before,k)!=getattr(after,k) or getattr(before,k)!=getattr(current,k) for k in fields):
        raise ValueError('Original resource changed during read')
    return raw

def verify_tools(root,expected):
    raw=read(root/'MANIFEST.json');manifest=strict_json(raw)
    if sha256(raw).hexdigest()!=expected or manifest.get('schema')!='dradar.execution-companion/1':
        raise ValueError('Execution companion manifest differs')
    for item in manifest['files']:
        if not re.fullmatch('[A-Za-z0-9_.-]+',item['name']):raise ValueError('Unsafe companion member')
        data=read(root/item['name'])
        if sha256(data).hexdigest()!=item['sha256'] or len(data)!=item['size_bytes']:
            raise ValueError('Execution companion bytes differ')
    return manifest

def fixed_entry(recommendation,mapping_raw):
    descriptor=recommendation['execution_environment'];task=recommendation['task']
    revision=sha256(mapping_raw).hexdigest();mapping=strict_json(mapping_raw)
    if (descriptor['schema']!=SCHEMA or descriptor['revision']!=revision
            or descriptor['mapping']['sha256']!=revision or descriptor['mapping']['size_bytes']!=len(mapping_raw)
            or mapping['schema']!=MAP_SCHEMA):raise ValueError('Immutable execution map differs')
    entries=[x for x in mapping['rows'] if x['task']==task]
    if len(entries)!=1:raise ValueError('Original task identity is not in this execution map')
    row=entries[0]
    if descriptor['source_image']!=task['image'] or any(descriptor[k]!=row[k] for k in ('image','image_id','runtime','architecture','os')):
        raise ValueError('Source identity or actual execution image differs')
    if descriptor['tool']['sha256']!=mapping['companion_sha256']:
        raise ValueError('Fixed execution companion differs from this version')
    return descriptor,row

def inspect_binding(row,inspection_raw,expected):
    if sha256(inspection_raw).hexdigest()!=expected:raise ValueError('Outer image-inspection receipt differs')
    value=strict_json(inspection_raw)
    if not isinstance(value,list) or len(value)!=1 or not isinstance(value[0],dict):
        raise ValueError('Original docker image inspect array required; never use credential-bearing container inspect')
    image=value[0]
    if (image.get('Id')!=row['image_id'] or row['image'] not in image.get('RepoDigests',[])
            or image.get('Architecture')!=row['architecture'] or image.get('Os')!=row['os']):
        raise ValueError('Pulled immutable image/config/architecture differs')

def writable(directory):
    with tempfile.TemporaryFile(dir=directory,prefix='.dradar-environment-') as stream:stream.write(b'probe')
    return True

def version(name):
    path=shutil.which(name)
    if path is None:raise ValueError('Required dependency missing: '+name)
    result=subprocess.run([path,'--version'],stdin=subprocess.DEVNULL,capture_output=True,text=True,timeout=10)
    if result.returncode:raise ValueError('Required dependency does not start: '+name)
    value=result.stdout.strip()
    if not value or len(value)>256:raise ValueError('Dependency version is not bounded')
    if name=='node':
        match=re.fullmatch(r'v(\d+)\.(\d+)\.(\d+)',value)
        if match is None or int(match[1])<16:raise ValueError('Installed model-tool package requires Node >=16')
    return value

def observe(recommendation,mapping_raw,inspection_raw,inspection_sha,evidence_directory,execution_id):
    if not re.fullmatch(r'[0-9a-f]{12}4[0-9a-f]{3}[89ab][0-9a-f]{15}',execution_id):
        raise ValueError('Original per-execution UUID4 identity required')
    if not sys.platform.startswith('linux'):
        raise ValueError('Run execution preparation inside the declared Linux task container')
    descriptor,row=fixed_entry(recommendation,mapping_raw)
    inspect_binding(row,inspection_raw,inspection_sha)
    actual={'uid':os.getuid(),'gid':os.getgid(),'cwd':os.getcwd(),'home':os.environ.get('HOME')}
    if actual!=row['runtime']:raise ValueError('Actual UID/GID/HOME/cwd differs; do not change execution identity')
    if sys.version_info<(3,10):raise ValueError('Python >=3.10 required')
    context=ssl.create_default_context()
    if not context.check_hostname or context.verify_mode!=ssl.CERT_REQUIRED:
        raise ValueError('Strict default certificate verification required')
    roots=len(context.get_ca_certs())
    if roots<=0:raise ValueError('System default roots are unavailable; preserve the first error')
    spec={k:descriptor[k] for k in ('schema','revision','image','source_image')}
    # Only selected image facts enter this receipt. Never copy image Env or any
    # container inspection, credentials, auth, answers or model logs into it.
    return {'schema':'dradar.execution-observation/1','execution_id':execution_id,'task':recommendation['task'],
        'execution_environment':spec,'image_id':row['image_id'],'runtime':actual,
        'architecture':row['architecture'],'os':row['os'],'inspection_sha256':inspection_sha,
        'dependencies':{'python':list(sys.version_info[:3]),'python_path':sys.executable,
            'node':version('node'),'npm':version('npm'),'root_count':roots,
            'project_writable':writable(actual['cwd']),'home_writable':writable(actual['home']),
            'evidence_writable':writable(evidence_directory)}}

def write_receipt(path,data):
    path=Path(path).absolute()
    if not path.is_relative_to(EVIDENCE_ROOT) or '..' in path.parts:
        raise ValueError('Execution receipts belong in the dedicated /dradar-evidence mount, outside answers')
    directory=os.open('/',os.O_RDONLY|os.O_DIRECTORY)
    try:
        for component in path.parts[1:-1]:
            next_fd=os.open(component,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=directory)
            os.close(directory);directory=next_fd
        fd=os.open(path.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=directory)
        with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.fsync(directory)
    finally:os.close(directory)

def main():
    parser=argparse.ArgumentParser();commands=parser.add_subparsers(dest='command',required=True)
    verify=commands.add_parser('verify-tools');verify.add_argument('--manifest-sha256',required=True)
    prepare=commands.add_parser('prepare');prepare.add_argument('--manifest-sha256',required=True)
    for name in ('execution-id','recommendation','mapping','image-inspect','image-inspect-sha256','output'):
        prepare.add_argument('--'+name,required=True)
    args=parser.parse_args();verify_tools(Path(__file__).resolve().parent,args.manifest_sha256)
    if args.command=='verify-tools':
        print(canonical({'verified':True,'model_calls':0,'API_POSTs':0}));return
    target=Path(args.output).absolute()
    if not target.is_relative_to(EVIDENCE_ROOT) or '..' in target.parts or target.exists() or target.is_symlink():
        raise ValueError('New execution receipt outside answers required; preserve existing receipts')
    for directory in target.parents:
        info=os.lstat(directory)
        if not stat.S_ISDIR(info.st_mode) or stat.S_ISLNK(info.st_mode):
            raise ValueError('Execution evidence parents must be actual directories')
    observation=observe(strict_json(read(args.recommendation)),read(args.mapping),
        read(args.image_inspect),args.image_inspect_sha256,target.parent,args.execution_id)
    raw=(canonical(observation)+'\n').encode();write_receipt(target,raw)
    envelope={**observation['execution_environment'],'evidence_sha256':sha256(raw).hexdigest()}
    print(canonical({'schema':'dradar.execution-preparation/1','execution_environment':envelope,
        'evidence':{'name':'runtime/execution-environment.json','role':'other','path':str(target)},
        'model_calls':0,'API_POSTs':0,'packages_installed':False}))

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,TypeError,subprocess.SubprocessError) as exc:
        print(canonical({'schema':'dradar.execution-preparation/1','status':'blocked',
            'error_type':type(exc).__name__,'detail':str(exc),'model_calls':0,'API_POSTs':0,
            'original_files_preserved':True}))
        raise SystemExit(1)
